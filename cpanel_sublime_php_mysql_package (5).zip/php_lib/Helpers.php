<?php
/**
 * Print Sublime ERP - PHP Business Logic Helpers
 * Mengimplementasikan helper stok kain, kertas, timeline tracking,
 * agregasi pelanggan/piutang, snapshot backup 3 lapis, dan export SQL.
 */

class ErpHelpers {
    public static function nowIso() {
        return gmdate('Y-m-d\TH:i:s.000\Z');
    }

    public static function todayYmd() {
        $dt = new DateTime('now', new DateTimeZone('Asia/Jakarta'));
        return $dt->format('Y-m-d');
    }

    public static function formatWIB($dateOrIso = null) {
        if (empty($dateOrIso)) return 'Belum pernah';
        try {
            if (is_numeric($dateOrIso)) {
                $dt = new DateTime('@' . intval(floatval($dateOrIso) / 1000));
            } else {
                $dt = new DateTime(strval($dateOrIso));
            }
            $dt->setTimezone(new DateTimeZone('Asia/Jakarta'));
            return $dt->format('d/m/Y, H.i.s') . ' WIB';
        } catch (Exception $e) {
            $s = strval($dateOrIso);
            return (strpos($s, 'WIB') !== false) ? $s : ($s . ' WIB');
        }
    }

    public static function fmtRp($val) {
        return number_format(floatval($val), 0, ',', '.');
    }

    public static function parsePaperWidthInMeters($paperSizeStr = null) {
        if (empty($paperSizeStr)) return 1.6;
        if (preg_match('/(\d+(?:\.\d+)?)/', strval($paperSizeStr), $m)) {
            $val = floatval($m[1]);
            if ($val >= 30) return round($val / 100, 2);
            return round($val, 2);
        }
        return 1.6;
    }

    public static function getHeader($headers, $key) {
        $lower = strtolower($key);
        foreach ($headers as $k => $v) {
            if (strtolower($k) === $lower) return $v;
        }
        return null;
    }

    public static function getAppOrigin() {
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO'])) {
            $scheme = $_SERVER['HTTP_X_FORWARDED_PROTO'];
        }
        $host = !empty($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
        return $scheme . '://' . $host;
    }

    public static function checkCanEditPrices($state, $headers, $body, $query) {
        $role = self::getHeader($headers, 'x-user-role');
        if (!$role && isset($body['userRole'])) $role = $body['userRole'];
        if (!$role && isset($query['userRole'])) $role = $query['userRole'];

        if (empty($role) || $role === 'undefined' || $role === 'null') {
            return true;
        }
        if (in_array($role, ['Super Admin', 'Admin', 'Supervisor', 'Koord', 'SPV', 'Koordinator'])) {
            return true;
        }
        if (self::getHeader($headers, 'x-user-can-edit-settings') === 'true' || (!empty($body['canEditSettings']) && $body['canEditSettings'] === true)) {
            return true;
        }
        if (!empty($state['rolePermissions'][$role]['canEditSettings'])) {
            return true;
        }
        $userId = self::getHeader($headers, 'x-user-id') ?: (isset($body['userId']) ? $body['userId'] : null);
        $username = self::getHeader($headers, 'x-user-username') ?: (isset($body['username']) ? $body['username'] : null);
        if ($userId || $username) {
            foreach ($state['users'] as $u) {
                if (($userId && isset($u['id']) && $u['id'] === $userId) ||
                    ($username && isset($u['username']) && strtolower($u['username']) === strtolower($username))) {
                    if (!empty($u['permissions']['canEditSettings'])) return true;
                    $ur = isset($u['role']) ? $u['role'] : '';
                    if ($ur && !empty($state['rolePermissions'][$ur]['canEditSettings'])) return true;
                }
            }
        }
        return false;
    }

    public static function addLog(&$state, $userId, $userNama, $action, $description) {
        if (!isset($state['logs']) || !is_array($state['logs'])) $state['logs'] = [];
        $now = self::nowIso();
        if (count($state['logs']) > 0) {
            $last = $state['logs'][0];
            if (isset($last['Action']) && $last['Action'] === $action && isset($last['Description']) && $last['Description'] === $description) {
                $diffMs = (microtime(true) * 1000) - (strtotime(isset($last['Timestamp']) ? $last['Timestamp'] : 'now') * 1000);
                if ($diffMs < 5000) {
                    $state['logs'][0]['Timestamp'] = $now;
                    return;
                }
            }
        }
        $resolvedName = ($userNama === 'Admin') ? 'Super Admin' : ($userNama ?: 'Super Admin');
        $newLog = [
            'ID' => 'LOG-' . intval(microtime(true) * 1000) . '-' . mt_rand(100, 999),
            'UserID' => $userId ?: 'USR-000',
            'UserNama' => $resolvedName,
            'Action' => $action,
            'Description' => $description,
            'Timestamp' => $now
        ];
        array_unshift($state['logs'], $newLog);
        if (count($state['logs']) > 300) {
            $state['logs'] = array_slice($state['logs'], 0, 300);
        }
    }

    public static function broadcastNotification(&$state, $title, $message, $type = 'info', $orderId = null, $customId = null, $senderClientId = null) {
        if (!isset($state['notifications']) || !is_array($state['notifications'])) $state['notifications'] = [];
        $notif = [
            'id' => $customId ?: ('notif-' . intval(microtime(true) * 1000) . '-' . substr(md5(mt_rand()), 0, 4)),
            'title' => $title,
            'message' => $message,
            'type' => $type,
            'timestamp' => self::nowIso(),
            'read' => false,
            'orderId' => $orderId,
            'senderClientId' => $senderClientId
        ];
        array_unshift($state['notifications'], $notif);
        if (count($state['notifications']) > 250) {
            $state['notifications'] = array_slice($state['notifications'], 0, 250);
        }
        return $notif;
    }

    public static function generateNextMaterialId($materials) {
        $maxId = 0;
        foreach ($materials as $m) {
            if (!empty($m['ID']) && preg_match('/^MAT-(\d+)$/i', $m['ID'], $match)) {
                $num = intval($match[1]);
                if ($num > $maxId) $maxId = $num;
            }
        }
        return 'MAT-' . str_pad(strval($maxId + 1), 3, '0', STR_PAD_LEFT);
    }

    public static function ensurePaperMaterialsSynced(&$state) {
        $changed = false;
        $standardWidths = ['160 cm', '125 cm', '110 cm', '90 cm'];
        if (empty($state['paperSettings']['widths']) || !is_array($state['paperSettings']['widths'])) {
            $state['paperSettings']['widths'] = $standardWidths;
            $changed = true;
        } else {
            foreach ($standardWidths as $w) {
                if (!in_array($w, $state['paperSettings']['widths'])) {
                    $state['paperSettings']['widths'][] = $w;
                    $changed = true;
                }
            }
        }

        if (!empty($state['paperSettings']['types']) && is_array($state['paperSettings']['types'])) {
            $cleanTypes = [];
            foreach ($state['paperSettings']['types'] as $t) {
                if (is_string($t) && $t !== '' &&
                    stripos($t, 'kertas sublim') === false &&
                    stripos($t, 'sticky 160') === false &&
                    !preg_match('/\d+\s*cm/i', $t)) {
                    $cleanTypes[] = $t;
                }
            }
            if (count($cleanTypes) !== count($state['paperSettings']['types'])) {
                $state['paperSettings']['types'] = count($cleanTypes) > 0 ? $cleanTypes : ['Sticky', 'Fastdry'];
                $changed = true;
            }
        } else {
            $state['paperSettings']['types'] = ['Sticky', 'Fastdry'];
            $changed = true;
        }

        foreach ($state['materials'] as &$m) {
            if (isset($m['Kategori']) && $m['Kategori'] === 'Paper') {
                $lowerName = strtolower(isset($m['NamaMaterial']) ? $m['NamaMaterial'] : '');
                if (empty($m['TipePaper'])) {
                    if (strpos($lowerName, 'protection') !== false) $m['TipePaper'] = 'Protection';
                    elseif (strpos($lowerName, 'fastdry') !== false) $m['TipePaper'] = 'Fastdry';
                    else $m['TipePaper'] = 'Sticky';
                    $changed = true;
                }
                if (empty($m['LebarPaper'])) {
                    $m['LebarPaper'] = preg_match('/(\d+\s*cm)/i', $m['NamaMaterial'], $mm) ? $mm[1] : '160 cm';
                    $changed = true;
                }
                if (!isset($m['MeterPerRoll'])) {
                    $m['MeterPerRoll'] = (strpos($lowerName, 'protection') !== false) ? 200 : 100;
                    $changed = true;
                }
                if (!isset($m['RollCount'])) {
                    $m['RollCount'] = isset($m['Stok']) ? $m['Stok'] : 0;
                    $changed = true;
                }
            }
        }
        unset($m);
        return $changed;
    }

    public static function getOrderActiveStages($order) {
        $stages = [];
        if (!empty($order['TahapanPekerjaan']) && is_array($order['TahapanPekerjaan'])) {
            $stages = $order['TahapanPekerjaan'];
        } else {
            $jenisOrder = isset($order['JenisOrder']) ? $order['JenisOrder'] : '';
            $jenis = strtolower($jenisOrder);
            if ($jenisOrder === 'Print Saja') {
                $stages = ['Print', 'QC'];
            } elseif ($jenisOrder === 'Press Saja') {
                $stages = ['Press', 'QC'];
            } elseif ($jenisOrder === 'Print & Press' || $jenisOrder === 'Print + Press') {
                $stages = ['Print', 'Press', 'QC'];
            } elseif ($jenisOrder === 'Jahit Jersey' || $jenisOrder === 'Jahit Kolor') {
                $stages = ['Cutting', 'Jahit', 'QC', 'Packing'];
            } elseif (strpos($jenis, '+') !== false || strpos($jenis, '&') !== false ||
                      strpos($jenis, 'cutting') !== false || strpos($jenis, 'jahit') !== false ||
                      strpos($jenis, 'press') !== false || strpos($jenis, 'print') !== false) {
                if (strpos($jenis, 'print') !== false) $stages[] = 'Print';
                if (strpos($jenis, 'press') !== false) $stages[] = 'Press';
                if (strpos($jenis, 'cutting') !== false || strpos($jenis, 'potong') !== false) $stages[] = 'Cutting';
                if (strpos($jenis, 'jahit') !== false || strpos($jenis, 'sewing') !== false || strpos($jenis, 'jersey') !== false || strpos($jenis, 'kolor') !== false) $stages[] = 'Jahit';
                if (strpos($jenis, 'pack') !== false) $stages[] = 'Packing';
                if (empty($stages)) $stages = ['Print', 'Press', 'Cutting', 'Jahit', 'QC', 'Packing'];
            } else {
                $stages = ['Print', 'Press', 'Cutting', 'Jahit', 'QC', 'Packing'];
            }
        }
        if (!in_array('QC', $stages)) {
            $stages[] = 'QC';
        }
        return $stages;
    }

    public static function getNextStageAfter($order, $currentStage) {
        $activeStages = self::getOrderActiveStages($order);
        $allStagesOrdered = ['Print', 'Press', 'Cutting', 'Jahit', 'QC'];
        $map = ['print' => 'Print', 'press' => 'Press', 'cutting' => 'Cutting', 'jahit' => 'Jahit', 'qc' => 'QC'];
        $currentCap = isset($map[$currentStage]) ? $map[$currentStage] : 'QC';
        $idx = array_search($currentCap, $allStagesOrdered);
        if ($idx === false) $idx = -1;
        for ($i = $idx + 1; $i < count($allStagesOrdered); $i++) {
            $st = $allStagesOrdered[$i];
            if (in_array($st, $activeStages)) {
                if ($st === 'Print') return 'Antri Print';
                if ($st === 'Press') return 'Antri Press';
                if ($st === 'Cutting') return 'Antri Cutting';
                if ($st === 'Jahit') return 'Antri Jahit';
                if ($st === 'QC') return 'Antri QC';
                return $st;
            }
        }
        return 'Selesai';
    }

    public static function &findFabricMaterial(&$materials, $fabricName) {
        $null = null;
        if (empty($fabricName)) return $null;
        $lower = strtolower(trim($fabricName));
        foreach ($materials as &$m) {
            if (strtolower(trim(isset($m['NamaMaterial']) ? $m['NamaMaterial'] : '')) === $lower) return $m;
        }
        foreach ($materials as &$m) {
            $mn = strtolower(isset($m['NamaMaterial']) ? $m['NamaMaterial'] : '');
            if ($mn !== '' && (strpos($mn, $lower) !== false || strpos($lower, $mn) !== false)) return $m;
        }
        $keywords = ['dryfit', 'milano', 'serena', 'hyget', 'paragon', 'sublim', 'spandek', 'lycra', 'titik'];
        foreach ($keywords as $kw) {
            if (strpos($lower, $kw) !== false) {
                foreach ($materials as &$m) {
                    if (isset($m['Kategori']) && $m['Kategori'] === 'Fabric' && stripos($m['NamaMaterial'], $kw) !== false) {
                        return $m;
                    }
                }
            }
        }
        foreach ($materials as &$m) {
            if (isset($m['Kategori']) && $m['Kategori'] === 'Fabric') return $m;
        }
        return $null;
    }

    public static function syncFabricStockDeduction(&$state, $orderId, $fabricName, $targetQty, $source) {
        if (empty($orderId)) return ['success' => false, 'deducted' => 0];

        $spkIdx = -1;
        foreach ($state['spkList'] as $i => $s) {
            if ((isset($s['OrderID']) && $s['OrderID'] === $orderId) || (isset($s['ID']) && $s['ID'] === $orderId)) {
                $spkIdx = $i; break;
            }
        }
        $ordIdx = -1;
        foreach ($state['orders'] as $i => $o) {
            if (isset($o['ID']) && $o['ID'] === $orderId) {
                $ordIdx = $i; break;
            }
        }

        $prevDeducted = 0;
        if ($spkIdx !== -1 && isset($state['spkList'][$spkIdx]['DeductedFabricQty'])) {
            $prevDeducted = floatval($state['spkList'][$spkIdx]['DeductedFabricQty']);
        } elseif ($ordIdx !== -1 && isset($state['orders'][$ordIdx]['DeductedFabricQty'])) {
            $prevDeducted = floatval($state['orders'][$ordIdx]['DeductedFabricQty']);
        }

        $cleanTargetQty = max(0, floatval($targetQty));
        $delta = round($cleanTargetQty - $prevDeducted, 1);
        if ($delta == 0.0) return ['success' => true, 'deducted' => 0];

        $resolvedName = $fabricName;
        if (!$resolvedName && $spkIdx !== -1 && !empty($state['spkList'][$spkIdx]['MaterialPress'])) $resolvedName = $state['spkList'][$spkIdx]['MaterialPress'];
        if (!$resolvedName && $ordIdx !== -1 && !empty($state['orders'][$ordIdx]['MaterialPress'])) $resolvedName = $state['orders'][$ordIdx]['MaterialPress'];
        if (!$resolvedName && $ordIdx !== -1 && !empty($state['orders'][$ordIdx]['MaterialType'])) $resolvedName = $state['orders'][$ordIdx]['MaterialType'];
        if (!$resolvedName) $resolvedName = 'Kain Dryfit Titik';

        $fabricMat =& self::findFabricMaterial($state['materials'], $resolvedName);
        if ($fabricMat === null) {
            $newId = self::generateNextMaterialId($state['materials']);
            $state['materials'][] = [
                'ID' => $newId,
                'NamaMaterial' => $resolvedName,
                'Kategori' => 'Fabric',
                'Satuan' => 'Kg',
                'Stok' => max(0, 100 - ($delta > 0 ? $delta : 0)),
                'MinStok' => 20,
                'Harga' => 85000
            ];
            $fabricMat =& $state['materials'][count($state['materials']) - 1];
        }

        $avgWeight = (!empty($fabricMat['AvgWeightPerRoll']) && $fabricMat['AvgWeightPerRoll'] > 0) ? floatval($fabricMat['AvgWeightPerRoll']) : 25;

        if ($delta > 0) {
            $fabricMat['Stok'] = max(0, round(floatval($fabricMat['Stok']) - $delta, 1));
            $fabricMat['RollCount'] = round($fabricMat['Stok'] / $avgWeight, 1);
            $newTotal = round($prevDeducted + $delta, 1);

            if ($spkIdx !== -1) {
                $state['spkList'][$spkIdx]['DeductedFabricQty'] = $newTotal;
                $state['spkList'][$spkIdx]['FabricStockDeducted'] = true;
            }
            if ($ordIdx !== -1) {
                $state['orders'][$ordIdx]['DeductedFabricQty'] = $newTotal;
                $state['orders'][$ordIdx]['FabricStockDeducted'] = true;
            }

            self::addLog($state, 'SYSTEM_SYNC', 'AutoMaterialSync', 'SYNC_STOCK',
                "Pengurangan stok otomatis pemakaian kain [{$source}] Order {$orderId}: {$fabricMat['NamaMaterial']} (-{$delta} {$fabricMat['Satuan']}), Sisa Stok Gudang: {$fabricMat['Stok']} {$fabricMat['Satuan']} (~{$fabricMat['RollCount']} Roll)");

            self::broadcastNotification($state, 'Stok Kain Gudang Berkurang',
                "Pemakaian kain {$orderId} ({$resolvedName}): stok {$fabricMat['NamaMaterial']} berkurang {$delta} {$fabricMat['Satuan']}. Sisa stok: {$fabricMat['Stok']} {$fabricMat['Satuan']}.",
                'info', $orderId);

            return ['success' => true, 'deducted' => $delta, 'remainingStock' => $fabricMat['Stok'], 'materialName' => $fabricMat['NamaMaterial']];
        } else {
            $refund = abs($delta);
            $fabricMat['Stok'] = round(floatval($fabricMat['Stok']) + $refund, 1);
            $fabricMat['RollCount'] = round($fabricMat['Stok'] / $avgWeight, 1);
            $newTotal = max(0, round($prevDeducted - $refund, 1));

            if ($spkIdx !== -1) {
                $state['spkList'][$spkIdx]['DeductedFabricQty'] = $newTotal;
                if ($newTotal == 0) $state['spkList'][$spkIdx]['FabricStockDeducted'] = false;
            }
            if ($ordIdx !== -1) {
                $state['orders'][$ordIdx]['DeductedFabricQty'] = $newTotal;
                if ($newTotal == 0) $state['orders'][$ordIdx]['FabricStockDeducted'] = false;
            }

            self::addLog($state, 'SYSTEM_SYNC', 'AutoMaterialSync', 'SYNC_STOCK',
                "Penyesuaian stok kain [{$source}] Order {$orderId}: {$fabricMat['NamaMaterial']} (+{$refund} {$fabricMat['Satuan']}), Stok Sekarang: {$fabricMat['Stok']} {$fabricMat['Satuan']}");

            return ['success' => true, 'deducted' => $delta, 'remainingStock' => $fabricMat['Stok'], 'materialName' => $fabricMat['NamaMaterial']];
        }
    }

    public static function &findPaperMaterial(&$materials, $paperSize = null, $paperType = null, $customName = null, $targetMeterPerRoll = null) {
        $null = null;
        $paperIndices = [];
        foreach ($materials as $idx => $m) {
            if (isset($m['Kategori']) && $m['Kategori'] === 'Paper') $paperIndices[] = $idx;
        }
        if (empty($paperIndices)) return $null;

        if (!empty($customName)) {
            $cLower = strtolower(trim($customName));
            foreach ($paperIndices as $idx) {
                $mn = strtolower(trim($materials[$idx]['NamaMaterial']));
                if ($mn === $cLower || strpos($mn, $cLower) !== false) return $materials[$idx];
            }
        }

        $widthDigits = preg_replace('/[^0-9]/', '', strval($paperSize));
        $typeStr = strtolower(trim(strval($paperType)));

        if (!empty($targetMeterPerRoll)) {
            $isJumbo = intval($targetMeterPerRoll) === 300;
            foreach ($paperIndices as $idx) {
                $m = $materials[$idx];
                $mn = strtolower($m['NamaMaterial']);
                if (strpos($mn, 'protection') !== false) continue;
                $matchW = !$widthDigits || (strpos($mn, $widthDigits) !== false || (!empty($m['LebarPaper']) && strpos($m['LebarPaper'], $widthDigits) !== false));
                $matchT = !$typeStr || (strpos($mn, $typeStr) !== false || (!empty($m['TipePaper']) && stripos($m['TipePaper'], $typeStr) !== false));
                $matchR = (isset($m['MeterPerRoll']) && intval($m['MeterPerRoll']) === intval($targetMeterPerRoll)) || ($isJumbo ? strpos($mn, '300') !== false : strpos($mn, '300') === false);
                if ($matchW && $matchT && $matchR) return $materials[$idx];
            }
        }

        if ($widthDigits && $typeStr) {
            foreach ($paperIndices as $idx) {
                $m = $materials[$idx];
                $mn = strtolower($m['NamaMaterial']);
                if (strpos($mn, 'protection') !== false) continue;
                if ((strpos($mn, $widthDigits) !== false || (!empty($m['LebarPaper']) && strpos($m['LebarPaper'], $widthDigits) !== false)) &&
                    (strpos($mn, $typeStr) !== false || (!empty($m['TipePaper']) && stripos($m['TipePaper'], $typeStr) !== false))) {
                    return $materials[$idx];
                }
            }
        }

        if ($widthDigits) {
            foreach ($paperIndices as $idx) {
                $m = $materials[$idx];
                $mn = strtolower($m['NamaMaterial']);
                if (strpos($mn, 'protection') !== false) continue;
                if (strpos($mn, $widthDigits) !== false || (!empty($m['LebarPaper']) && strpos($m['LebarPaper'], $widthDigits) !== false)) {
                    return $materials[$idx];
                }
            }
        }

        if ($typeStr) {
            foreach ($paperIndices as $idx) {
                $m = $materials[$idx];
                $mn = strtolower($m['NamaMaterial']);
                if (strpos($mn, 'protection') !== false) continue;
                if (strpos($mn, $typeStr) !== false || (!empty($m['TipePaper']) && stripos($m['TipePaper'], $typeStr) !== false)) {
                    return $materials[$idx];
                }
            }
        }

        foreach ($paperIndices as $idx) {
            $m = $materials[$idx];
            $mn = strtolower($m['NamaMaterial']);
            if (strpos($mn, 'protection') === false) return $materials[$idx];
        }
        return $materials[$paperIndices[0]];
    }

    public static function syncPaperStockDeduction(&$state, $orderId, $targetMeters, $paperSize = null, $paperType = null, $source = 'SPK Print', $meterPerRollParam = null) {
        if (empty($orderId)) return ['success' => false, 'deductedRolls' => 0, 'deductedMeters' => 0];

        $spkIdx = -1;
        foreach ($state['spkList'] as $i => $s) {
            if ((isset($s['OrderID']) && $s['OrderID'] === $orderId) || (isset($s['ID']) && $s['ID'] === $orderId)) {
                $spkIdx = $i; break;
            }
        }
        $ordIdx = -1;
        foreach ($state['orders'] as $i => $o) {
            if (isset($o['ID']) && $o['ID'] === $orderId) {
                $ordIdx = $i; break;
            }
        }

        $prevDeductedMeters = 0;
        if ($spkIdx !== -1 && isset($state['spkList'][$spkIdx]['DeductedPaperMeters'])) {
            $prevDeductedMeters = floatval($state['spkList'][$spkIdx]['DeductedPaperMeters']);
        } elseif ($ordIdx !== -1 && isset($state['orders'][$ordIdx]['DeductedPaperMeters'])) {
            $prevDeductedMeters = floatval($state['orders'][$ordIdx]['DeductedPaperMeters']);
        }

        $cleanTargetMeters = max(0, floatval($targetMeters));
        $deltaMeters = round($cleanTargetMeters - $prevDeductedMeters, 1);
        if ($deltaMeters == 0.0) return ['success' => true, 'deductedRolls' => 0, 'deductedMeters' => 0];

        $effectiveWidth = $paperSize
            ?: ($spkIdx !== -1 ? (!empty($state['spkList'][$spkIdx]['PaperSize']) ? $state['spkList'][$spkIdx]['PaperSize'] : (!empty($state['spkList'][$spkIdx]['LayoutLebarKertas']) ? $state['spkList'][$spkIdx]['LayoutLebarKertas'] : null)) : null)
            ?: ($ordIdx !== -1 ? (!empty($state['orders'][$ordIdx]['LayoutLebarKertas']) ? $state['orders'][$ordIdx]['LayoutLebarKertas'] : (!empty($state['orders'][$ordIdx]['PaperSize']) ? $state['orders'][$ordIdx]['PaperSize'] : null)) : null)
            ?: '160 cm';

        $effectiveType = $paperType
            ?: ($spkIdx !== -1 ? (!empty($state['spkList'][$spkIdx]['PaperType']) ? $state['spkList'][$spkIdx]['PaperType'] : (!empty($state['spkList'][$spkIdx]['LayoutPaperType']) ? $state['spkList'][$spkIdx]['LayoutPaperType'] : null)) : null)
            ?: ($ordIdx !== -1 ? (!empty($state['orders'][$ordIdx]['PaperType']) ? $state['orders'][$ordIdx]['PaperType'] : null) : null)
            ?: 'Sticky';

        $effectiveRoll = $meterPerRollParam ?: 100;
        if (!$meterPerRollParam) {
            foreach (['PaperMeterPerRoll', 'LayoutPaperMeterPerRoll', 'MeterPerRoll'] as $rk) {
                if ($spkIdx !== -1 && !empty($state['spkList'][$spkIdx][$rk])) { $effectiveRoll = intval($state['spkList'][$spkIdx][$rk]); break; }
                if ($ordIdx !== -1 && !empty($state['orders'][$ordIdx][$rk])) { $effectiveRoll = intval($state['orders'][$ordIdx][$rk]); break; }
            }
        }

        $paperMat =& self::findPaperMaterial($state['materials'], $effectiveWidth, $effectiveType, null, $effectiveRoll);
        if ($paperMat === null) {
            $cleanW = $effectiveWidth ?: '160 cm';
            $mRoll = ($effectiveRoll == 300) ? 300 : 100;
            $newId = self::generateNextMaterialId($state['materials']);
            $state['materials'][] = [
                'ID' => $newId,
                'NamaMaterial' => "Kertas Sublim Roll {$cleanW} ({$mRoll}m" . ($mRoll === 300 ? ' Jumbo' : '') . ')',
                'Kategori' => 'Paper',
                'Satuan' => 'roll',
                'Stok' => 20,
                'MinStok' => 5,
                'Harga' => $mRoll === 300 ? 700000 : 250000,
                'LebarPaper' => $cleanW,
                'MeterPerRoll' => $mRoll
            ];
            $paperMat =& $state['materials'][count($state['materials']) - 1];
        }

        $meterPerRoll = !empty($paperMat['MeterPerRoll']) ? floatval($paperMat['MeterPerRoll']) : ($effectiveRoll ?: 100);
        $isRoll = strtolower(isset($paperMat['Satuan']) ? $paperMat['Satuan'] : 'roll') === 'roll';
        $deltaStock = $isRoll ? round($deltaMeters / $meterPerRoll, 2) : $deltaMeters;

        if ($deltaStock > 0) {
            $paperMat['Stok'] = max(0, round(floatval($paperMat['Stok']) - $deltaStock, 2));
            $newTotal = round($prevDeductedMeters + $deltaMeters, 1);

            if ($spkIdx !== -1) {
                $state['spkList'][$spkIdx]['DeductedPaperMeters'] = $newTotal;
                $state['spkList'][$spkIdx]['PaperStockDeducted'] = true;
                $state['spkList'][$spkIdx]['DeductedPaperSKU'] = $paperMat['ID'];
                $state['spkList'][$spkIdx]['DeductedPaperName'] = $paperMat['NamaMaterial'];
            }
            if ($ordIdx !== -1) {
                $state['orders'][$ordIdx]['DeductedPaperMeters'] = $newTotal;
                $state['orders'][$ordIdx]['PaperStockDeducted'] = true;
                $state['orders'][$ordIdx]['DeductedPaperSKU'] = $paperMat['ID'];
                $state['orders'][$ordIdx]['DeductedPaperName'] = $paperMat['NamaMaterial'];
            }

            $totalLeft = round($paperMat['Stok'] * $meterPerRoll);
            self::addLog($state, 'SYSTEM_SYNC', 'AutoMaterialSync', 'SYNC_STOCK',
                "Pengurangan stok otomatis kertas sublim [{$source}] Order {$orderId}: {$paperMat['NamaMaterial']} (-{$deltaStock} {$paperMat['Satuan']} / {$deltaMeters}m), Sisa Stok: {$paperMat['Stok']} {$paperMat['Satuan']} (~{$totalLeft} Meter)");

            self::broadcastNotification($state, 'Stok Kertas Sublim Berkurang',
                "Pemakaian cetak {$orderId} ({$deltaMeters}m): stok {$paperMat['NamaMaterial']} berkurang {$deltaStock} {$paperMat['Satuan']}. Sisa stok: {$paperMat['Stok']} {$paperMat['Satuan']} (~{$totalLeft}m).",
                'info', $orderId);

            return [
                'success' => true,
                'deductedRolls' => $deltaStock,
                'deductedMeters' => $deltaMeters,
                'remainingStock' => $paperMat['Stok'],
                'materialName' => $paperMat['NamaMaterial']
            ];
        } else {
            $refundStock = abs($deltaStock);
            $paperMat['Stok'] = round(floatval($paperMat['Stok']) + $refundStock, 2);
            $newTotal = max(0, round($prevDeductedMeters - abs($deltaMeters), 1));

            if ($spkIdx !== -1) {
                $state['spkList'][$spkIdx]['DeductedPaperMeters'] = $newTotal;
                if ($newTotal == 0) $state['spkList'][$spkIdx]['PaperStockDeducted'] = false;
                $state['spkList'][$spkIdx]['DeductedPaperSKU'] = $paperMat['ID'];
                $state['spkList'][$spkIdx]['DeductedPaperName'] = $paperMat['NamaMaterial'];
            }
            if ($ordIdx !== -1) {
                $state['orders'][$ordIdx]['DeductedPaperMeters'] = $newTotal;
                if ($newTotal == 0) $state['orders'][$ordIdx]['PaperStockDeducted'] = false;
                $state['orders'][$ordIdx]['DeductedPaperSKU'] = $paperMat['ID'];
                $state['orders'][$ordIdx]['DeductedPaperName'] = $paperMat['NamaMaterial'];
            }

            $totalLeft = round($paperMat['Stok'] * $meterPerRoll);
            self::addLog($state, 'SYSTEM_SYNC', 'AutoMaterialSync', 'SYNC_STOCK',
                "Penyesuaian stok kertas sublim [{$source}] Order {$orderId}: {$paperMat['NamaMaterial']} (+{$refundStock} {$paperMat['Satuan']}), Stok Sekarang: {$paperMat['Stok']} {$paperMat['Satuan']} (~{$totalLeft} Meter)");

            return [
                'success' => true,
                'deductedRolls' => $deltaStock,
                'deductedMeters' => $deltaMeters,
                'remainingStock' => $paperMat['Stok'],
                'materialName' => $paperMat['NamaMaterial']
            ];
        }
    }

    public static function getAggregatedCustomers($state) {
        $deletedKeys = array_map('strtolower', isset($state['deletedCustomerKeys']) ? $state['deletedCustomerKeys'] : []);
        $customerMap = [];

        foreach ((isset($state['customerProfiles']) ? $state['customerProfiles'] : []) as $prof) {
            $key = strtolower(trim(isset($prof['nama']) ? $prof['nama'] : ''));
            if (!$key || in_array($key, $deletedKeys)) continue;
            $customerMap[$key] = $prof;
        }

        $shortHash = function ($str) {
            $h = 0;
            $len = strlen($str);
            for ($i = 0; $i < $len; $i++) {
                $h = (($h << 5) - $h) + ord($str[$i]);
                $h = $h & 0x7FFFFFFF;
            }
            return strtoupper(base_convert(strval(abs($h)), 10, 36)) ?: '01';
        };

        foreach ((isset($state['orders']) ? $state['orders'] : []) as $ord) {
            if (empty($ord['NamaKonsumen'])) continue;
            $key = strtolower(trim($ord['NamaKonsumen']));
            if (in_array($key, $deletedKeys)) continue;
            if (!isset($customerMap[$key])) {
                $customerMap[$key] = [
                    'id' => 'CUST-' . $shortHash($key),
                    'nama' => trim($ord['NamaKonsumen']),
                    'noTelp' => isset($ord['NoTelpKonsumen']) ? $ord['NoTelpKonsumen'] : '',
                    'email' => isset($ord['EmailKonsumen']) ? $ord['EmailKonsumen'] : '',
                    'alamat' => isset($ord['AlamatPengiriman']) ? $ord['AlamatPengiriman'] : '',
                    'catatan' => '',
                    'createdAt' => isset($ord['CreatedAt']) ? $ord['CreatedAt'] : self::nowIso()
                ];
            } else {
                if (empty($customerMap[$key]['noTelp']) && !empty($ord['NoTelpKonsumen'])) $customerMap[$key]['noTelp'] = $ord['NoTelpKonsumen'];
                if (empty($customerMap[$key]['email']) && !empty($ord['EmailKonsumen'])) $customerMap[$key]['email'] = $ord['EmailKonsumen'];
                if (empty($customerMap[$key]['alamat']) && !empty($ord['AlamatPengiriman'])) $customerMap[$key]['alamat'] = $ord['AlamatPengiriman'];
            }
        }

        foreach ((isset($state['invoices']) ? $state['invoices'] : []) as $inv) {
            if (empty($inv['NamaKonsumen'])) continue;
            $key = strtolower(trim($inv['NamaKonsumen']));
            if (in_array($key, $deletedKeys)) continue;
            if (!isset($customerMap[$key])) {
                $customerMap[$key] = [
                    'id' => 'CUST-' . $shortHash($key),
                    'nama' => trim($inv['NamaKonsumen']),
                    'noTelp' => '', 'email' => '', 'alamat' => '', 'catatan' => '',
                    'createdAt' => isset($inv['TanggalInvoice']) ? $inv['TanggalInvoice'] : self::nowIso()
                ];
            }
        }

        foreach ((isset($state['piutangs']) ? $state['piutangs'] : []) as $pit) {
            if (empty($pit['NamaKonsumen'])) continue;
            $key = strtolower(trim($pit['NamaKonsumen']));
            if (in_array($key, $deletedKeys)) continue;
            if (!isset($customerMap[$key])) {
                $customerMap[$key] = [
                    'id' => 'CUST-' . $shortHash($key),
                    'nama' => trim($pit['NamaKonsumen']),
                    'noTelp' => '', 'email' => '', 'alamat' => '', 'catatan' => '',
                    'createdAt' => isset($pit['TanggalJatuhTempo']) ? $pit['TanggalJatuhTempo'] : self::nowIso()
                ];
            }
        }

        $todayStr = self::todayYmd();
        $result = [];

        foreach ($customerMap as $key => $base) {
            $custOrders = [];
            foreach ($state['orders'] as $o) {
                if (!empty($o['NamaKonsumen']) && strtolower(trim($o['NamaKonsumen'])) === $key) $custOrders[] = $o;
            }
            $custInvoices = [];
            foreach ($state['invoices'] as $i) {
                if (!empty($i['NamaKonsumen']) && strtolower(trim($i['NamaKonsumen'])) === $key) $custInvoices[] = $i;
            }
            $custPiutangs = [];
            foreach ($state['piutangs'] as $p) {
                if (!empty($p['NamaKonsumen']) && strtolower(trim($p['NamaKonsumen'])) === $key) $custPiutangs[] = $p;
            }

            $totalOmset = 0;
            $totalTerbayar = 0;
            $totalPiutang = 0;
            $unpaidInvoicesCount = 0;
            $hasOverdue = false;
            $nearestDueDate = null;
            $lastTransactionDate = null;

            foreach ($custInvoices as $inv) {
                $amt = floatval(isset($inv['TotalAmount']) ? $inv['TotalAmount'] : 0);
                $paid = isset($inv['PaidAmount']) && $inv['PaidAmount'] !== null ? floatval($inv['PaidAmount']) : ((isset($inv['Status']) && $inv['Status'] === 'Paid') ? $amt : 0);
                $sisa = max(0, $amt - $paid);
                $totalOmset += $amt;
                $totalTerbayar += $paid;
                $totalPiutang += $sisa;
                if ($sisa > 0) {
                    $unpaidInvoicesCount++;
                    if (!empty($inv['DueDate'])) {
                        if ($inv['DueDate'] < $todayStr) $hasOverdue = true;
                        if ($nearestDueDate === null || $inv['DueDate'] < $nearestDueDate) $nearestDueDate = $inv['DueDate'];
                    }
                }
                if (!empty($inv['TanggalInvoice']) && ($lastTransactionDate === null || $inv['TanggalInvoice'] > $lastTransactionDate)) {
                    $lastTransactionDate = $inv['TanggalInvoice'];
                }
            }

            foreach ($custPiutangs as $pit) {
                $matched = false;
                foreach ($custInvoices as $ci) {
                    if ($ci['ID'] === $pit['InvoiceID']) { $matched = true; break; }
                }
                if (!$matched) {
                    $sisa = floatval(isset($pit['Sisa']) ? $pit['Sisa'] : 0);
                    if ($sisa > 0 && (isset($pit['Status']) ? $pit['Status'] : '') !== 'Lunas') {
                        $totalPiutang += $sisa;
                        $unpaidInvoicesCount++;
                        if (!empty($pit['TanggalJatuhTempo'])) {
                            if ($pit['TanggalJatuhTempo'] < $todayStr) $hasOverdue = true;
                            if ($nearestDueDate === null || $pit['TanggalJatuhTempo'] < $nearestDueDate) $nearestDueDate = $pit['TanggalJatuhTempo'];
                        }
                    }
                }
            }

            foreach ($custOrders as $ord) {
                $od = !empty($ord['CreatedAt']) ? substr($ord['CreatedAt'], 0, 10) : '';
                if ($od && ($lastTransactionDate === null || $od > $lastTransactionDate)) $lastTransactionDate = $od;
            }

            $result[] = [
                'id' => $base['id'],
                'nama' => $base['nama'],
                'noTelp' => isset($base['noTelp']) ? $base['noTelp'] : '',
                'email' => isset($base['email']) ? $base['email'] : '',
                'alamat' => isset($base['alamat']) ? $base['alamat'] : '',
                'catatan' => isset($base['catatan']) ? $base['catatan'] : '',
                'createdAt' => isset($base['createdAt']) ? $base['createdAt'] : '',
                'totalOrders' => count($custOrders),
                'totalInvoices' => count($custInvoices),
                'totalOmset' => $totalOmset,
                'totalTerbayar' => $totalTerbayar,
                'totalPiutang' => $totalPiutang,
                'unpaidInvoicesCount' => $unpaidInvoicesCount,
                'hasOverdue' => $hasOverdue,
                'nearestDueDate' => $nearestDueDate,
                'lastTransactionDate' => $lastTransactionDate,
                'invoices' => $custInvoices,
                'orders' => $custOrders
            ];
        }

        usort($result, function ($a, $b) {
            if ($b['totalPiutang'] != $a['totalPiutang']) {
                return ($b['totalPiutang'] > $a['totalPiutang']) ? 1 : -1;
            }
            return strcmp($a['nama'], $b['nama']);
        });
        return $result;
    }

    public static function buildTrackingData($state, $order, $spk = null) {
        $activeStages = self::getOrderActiveStages($order);
        $jenisOrder = isset($order['JenisOrder']) ? $order['JenisOrder'] : '';
        $lowerJenis = strtolower($jenisOrder);
        $status = isset($order['Status']) ? $order['Status'] : 'Pending';

        $hasPrint = in_array('Print', $activeStages) || in_array($jenisOrder, ['Print Saja', 'Print & Press', 'Full Order']) || strpos($lowerJenis, 'print') !== false;
        $hasPress = in_array('Press', $activeStages) || in_array($jenisOrder, ['Press Saja', 'Print & Press', 'Full Order']) || strpos($lowerJenis, 'press') !== false;
        $hasCutting = in_array('Cutting', $activeStages) || in_array($jenisOrder, ['Full Order', 'Jahit Jersey', 'Jahit Kolor']) || strpos($lowerJenis, 'cutting') !== false || strpos($lowerJenis, 'potong') !== false;
        $hasJahit = in_array('Jahit', $activeStages) || in_array($jenisOrder, ['Full Order', 'Jahit Jersey', 'Jahit Kolor']) || strpos($lowerJenis, 'jahit') !== false || strpos($lowerJenis, 'sewing') !== false;

        $testStatus = isset($order['TestPrintStatus']) ? $order['TestPrintStatus'] : '';
        $isTestPrintActive = ($status === 'Test Print' || $status === 'Layout' || in_array($testStatus, ['Menunggu ACC', 'Menunggu Uji', 'Perlu Penyesuaian']));
        $isPastTestPrint = in_array($status, ['Antri Print', 'Print', 'Press', 'Cutting', 'Jahit', 'QC', 'Selesai']) || in_array($testStatus, ['Disetujui', 'Warna sudah ACC']);
        $isOrderCsCurrent = ($status === 'Pending' && !$isTestPrintActive && empty($order['TestPrintDate']));
        $isTestPrintCurrent = !$isPastTestPrint && ($isTestPrintActive || ($status === 'Pending' && (!empty($order['TestPrintDate']) || !empty($testStatus))));

        $priceTotal = isset($order['PriceTotal']) ? floatval($order['PriceTotal']) : 0;
        $timeline = [];

        $timeline[] = [
            'key' => 'order_cs',
            'division' => 'Customer Service',
            'status' => 'Order Diterima CS',
            'title' => 'Penerimaan Order & Validasi Berkas',
            'date' => !empty($order['TanggalOrder']) ? $order['TanggalOrder'] : (isset($order['CreatedAt']) ? $order['CreatedAt'] : null),
            'icon' => 'cart',
            'done' => !$isOrderCsCurrent,
            'isCurrent' => $isOrderCsCurrent,
            'desc' => 'Petugas CS: ' . (!empty($order['CreatedBy']) ? $order['CreatedBy'] : 'Customer Service'),
            'operator' => !empty($order['CreatedBy']) ? $order['CreatedBy'] : 'Customer Service',
            'specs' => [
                'Kriteria' => isset($order['Kriteria']) ? $order['Kriteria'] : 'Normal',
                'Jenis Order' => $jenisOrder,
                'Total Biaya' => $priceTotal > 0 ? 'Rp ' . self::fmtRp($priceTotal) : 'Belum Dihitung (Menunggu Data SPK)'
            ]
        ];

        $tpTitle = ($testStatus === 'Menunggu ACC') ? 'Uji Cetak Warna: Menunggu ACC Konsumen' : 'Kalibrasi RIP Color Profile (CMYK / RGB)';
        $tpStatusLabel = ($testStatus === 'Menunggu ACC') ? 'Sampel Cetak Selesai • Menunggu ACC / Persetujuan Konsumen'
            : (($testStatus === 'Warna sudah ACC' || $testStatus === 'Disetujui') ? 'Kalibrasi RIP Disetujui (Warna ACC)' : 'Test Print & Penyesuaian Profil Warna');
        $timeline[] = [
            'key' => 'test_print_layout',
            'division' => 'Divisi Layout & RIP',
            'status' => $tpStatusLabel,
            'title' => $tpTitle,
            'date' => (in_array($status, ['Test Print', 'Layout', 'Print', 'Press', 'Cutting', 'Jahit', 'QC', 'Selesai']) || $isTestPrintActive)
                ? (!empty($order['TestPrintDate']) ? $order['TestPrintDate'] : (isset($order['CreatedAt']) ? $order['CreatedAt'] : null)) : null,
            'icon' => 'palette',
            'done' => $isPastTestPrint,
            'isCurrent' => $isTestPrintCurrent,
            'desc' => ($testStatus === 'Menunggu ACC')
                ? 'Sampel cetak fisik selesai diuji • Menunggu konfirmasi ACC warna dari pemesan'
                : 'Kalibrasi RIP & uji kesesuaian warna',
            'operator' => !empty($order['TestPrintOperator']) ? $order['TestPrintOperator'] : 'Operator RIP & Prepress',
            'specs' => [
                'Status Uji' => $testStatus ?: 'Belum Test Print',
                'Profil Terverifikasi' => !empty($order['VerifiedColorProfile']) ? $order['VerifiedColorProfile'] : (!empty($order['ColorProfile']) ? $order['ColorProfile'] : 'CMYK Standard'),
                'Catatan Warna' => !empty($order['TestPrintNotes']) ? $order['TestPrintNotes'] : 'Standar cetak normal'
            ]
        ];

        $mPrint = ($spk && !empty($spk['MeterPrint'])) ? floatval($spk['MeterPrint']) : floatval(isset($order['MeterPrint']) ? $order['MeterPrint'] : 0);
        $pSize = ($spk && !empty($spk['PaperSize'])) ? $spk['PaperSize'] : (!empty($order['PaperSize']) ? $order['PaperSize'] : '160 cm');
        $pWidthM = self::parsePaperWidthInMeters($pSize);
        $luas = number_format($mPrint * $pWidthM, 2, '.', '');
        $paperType = ($spk && !empty($spk['PaperType'])) ? $spk['PaperType'] : (!empty($order['PaperType']) ? $order['PaperType'] : 'Sticky');

        if ($hasPrint) {
            $timeline[] = [
                'key' => 'print',
                'division' => 'Divisi Print',
                'status' => $status === 'Antri Print' ? 'Antri Mesin Print' : 'Proses Mesin Printing Sublim',
                'title' => $status === 'Antri Print' ? 'Menunggu Antrian Mesin Cetak Sublim' : 'Pencetakan Transfer Paper High-Resolution',
                'date' => in_array($status, ['Antri Print', 'Print', 'Antri Press', 'Press', 'Antri Cutting', 'Cutting', 'Antri Jahit', 'Jahit', 'Antri QC', 'QC', 'Selesai']) ? (!empty($order['StatusUpdatedAt']) ? $order['StatusUpdatedAt'] : $order['CreatedAt']) : null,
                'icon' => 'printer',
                'done' => in_array($status, ['Antri Press', 'Press', 'Antri Cutting', 'Cutting', 'Antri Jahit', 'Jahit', 'Antri QC', 'QC', 'Selesai']) || ($spk && isset($spk['StatusPrint']) && $spk['StatusPrint'] === 'Done'),
                'isCurrent' => ($status === 'Antri Print' || $status === 'Print'),
                'desc' => $mPrint > 0 ? "Panjang: {$mPrint}m x ({$pSize}) • Total Luas: {$luas} m²" : 'Pencetakan roll transfer paper',
                'operator' => !empty($order['StatusUpdatedBy']) ? $order['StatusUpdatedBy'] : 'Randi Operator Print',
                'specs' => ['Total Luas (M²)' => "{$luas} m²", 'Jenis Kertas' => $paperType]
            ];
        }

        if ($hasPress) {
            $matPress = ($spk && !empty($spk['MaterialPress'])) ? $spk['MaterialPress'] : (!empty($order['MaterialType']) ? $order['MaterialType'] : 'Dryfit');
            $qtyMat = ($spk && !empty($spk['QtyMaterial'])) ? $spk['QtyMaterial'] : (isset($order['QtyMaterial']) ? $order['QtyMaterial'] : 0);
            $timeline[] = [
                'key' => 'press',
                'division' => 'Divisi Heat Press Roll',
                'status' => $status === 'Antri Press' ? 'Antri Heat Press' : 'Heat Press Transfer Sublimasi',
                'title' => 'Transfer Tinta ke Serat Kain (200°C)',
                'date' => in_array($status, ['Antri Press', 'Press', 'Antri Cutting', 'Cutting', 'Antri Jahit', 'Jahit', 'Antri QC', 'QC', 'Selesai']) ? (isset($order['StatusUpdatedAt']) ? $order['StatusUpdatedAt'] : null) : null,
                'icon' => 'flame',
                'done' => in_array($status, ['Antri Cutting', 'Cutting', 'Antri Jahit', 'Jahit', 'Antri QC', 'QC', 'Selesai']) || ($spk && isset($spk['StatusPress']) && $spk['StatusPress'] === 'Done'),
                'isCurrent' => ($status === 'Antri Press' || $status === 'Press'),
                'desc' => "Kain: {$matPress} ({$qtyMat} Kg)",
                'operator' => 'Eko Operator Press',
                'specs' => ['Bahan Kain' => $matPress, 'Kuantitas Kain' => "{$qtyMat} Kg / Roll", 'Metode Press' => ($spk && !empty($spk['PressCalcMode'])) ? $spk['PressCalcMode'] : 'Meter Persegi']
            ];
        }

        if ($hasCutting) {
            $timeline[] = [
                'key' => 'cutting',
                'division' => 'Divisi Cutting & Pola',
                'status' => $status === 'Antri Cutting' ? 'Antri Cutting Pola' : 'Pemotongan Pola Kain (Laser / Manual)',
                'title' => 'Cutting Presisi Sesuai Template Pola',
                'date' => in_array($status, ['Antri Cutting', 'Cutting', 'Antri Jahit', 'Jahit', 'Antri QC', 'QC', 'Selesai']) ? (isset($order['StatusUpdatedAt']) ? $order['StatusUpdatedAt'] : null) : null,
                'icon' => 'scissors',
                'done' => in_array($status, ['Antri Jahit', 'Jahit', 'Antri QC', 'QC', 'Selesai']) || ($spk && isset($spk['StatusCutting']) && $spk['StatusCutting'] === 'Done'),
                'isCurrent' => ($status === 'Antri Cutting' || $status === 'Cutting'),
                'desc' => ($spk && !empty($spk['MethodCutting'])) ? "Metode: {$spk['MethodCutting']}" : 'Pemotongan pola garment',
                'operator' => 'Dedi Operator Cutting',
                'specs' => ['Metode Cutting' => ($spk && !empty($spk['MethodCutting'])) ? $spk['MethodCutting'] : 'Laser Cutting CNC']
            ];
        }

        if ($hasJahit) {
            $totPcs = !empty($order['TotalBarang']) ? $order['TotalBarang'] : ($spk && !empty($spk['TotalBarang']) ? $spk['TotalBarang'] : 0);
            $timeline[] = [
                'key' => 'jahit',
                'division' => 'Divisi Jahit & Perakitan',
                'status' => $status === 'Antri Jahit' ? 'Antri Penjahitan' : 'Penjahitan & Finishing Garmen',
                'title' => 'Perakitan Busana & Jahitan Overdeck / Rantai',
                'date' => in_array($status, ['Antri Jahit', 'Jahit', 'Antri QC', 'QC', 'Selesai']) ? (isset($order['StatusUpdatedAt']) ? $order['StatusUpdatedAt'] : null) : null,
                'icon' => 'shirt',
                'done' => in_array($status, ['Antri QC', 'QC', 'Selesai']) || ($spk && isset($spk['StatusJahit']) && $spk['StatusJahit'] === 'Done'),
                'isCurrent' => ($status === 'Antri Jahit' || $status === 'Jahit'),
                'desc' => 'Penjahitan pola busana & obras rapi',
                'operator' => 'Agus Operator Jahit',
                'specs' => ['Tipe Jahit' => $jenisOrder, 'Total Pcs' => "{$totPcs} Pcs"]
            ];
        }

        $timeline[] = [
            'key' => 'qc',
            'division' => 'Divisi Quality Control',
            'status' => $status === 'Antri QC' ? 'Antri Audit QC' : 'Pemeriksaan Mutu & Kerapian (QC)',
            'title' => 'Validasi Hasil Cetak, Warna & Kerapian Jahit',
            'date' => in_array($status, ['Antri QC', 'QC', 'Selesai']) ? (isset($order['StatusUpdatedAt']) ? $order['StatusUpdatedAt'] : null) : null,
            'icon' => 'check-circle',
            'done' => $status === 'Selesai' || ($spk && isset($spk['StatusQC']) && $spk['StatusQC'] === 'OK'),
            'isCurrent' => ($status === 'Antri QC' || $status === 'QC'),
            'desc' => ($spk && isset($spk['StatusQC']) && $spk['StatusQC'] === 'OK') ? 'Lolos Pemeriksaan Mutu (Grade A)' : 'Pemeriksaan standar cetak',
            'operator' => 'Rina Quality Control',
            'specs' => ['Status QC' => ($spk && !empty($spk['StatusQC'])) ? $spk['StatusQC'] : 'Dalam Pemeriksaan', 'Reject Qty' => ($spk && isset($spk['RejectQty']) ? $spk['RejectQty'] : 0) . ' Pcs']
        ];

        $isOrderDone = ($status === 'Selesai');
        $cName = isset($order['CourierName']) ? strtolower($order['CourierName']) : '';
        $isDikirimPaket = (isset($order['PengirimanMetode']) && $order['PengirimanMetode'] === 'Dikirim Paket')
            || !empty($order['CourierTrackingNo'])
            || ($cName !== '' && strpos($cName, 'ambil') === false && strpos($cName, 'workshop') === false && strpos($cName, 'self') === false);

        $timeline[] = [
            'key' => 'done',
            'division' => 'Finishing & Pengepakan',
            'status' => $isOrderDone ? 'Selesai Produksi (Done)' : 'Penyelesaian Akhir & Pengemasan',
            'title' => 'Produksi Selesai & Lolos QC (Done)',
            'date' => $isOrderDone ? (!empty($order['StatusUpdatedAt']) ? $order['StatusUpdatedAt'] : $order['CreatedAt']) : null,
            'icon' => 'check-circle',
            'done' => $isOrderDone,
            'isCurrent' => $isOrderDone && !$isDikirimPaket,
            'desc' => $isOrderDone ? ($isDikirimPaket ? 'Siap diserahkan ke ekspedisi.' : 'Siap diambil langsung di workshop.') : 'Penyelesaian akhir produksi & pengemasan pesanan.',
            'operator' => !empty($order['StatusUpdatedBy']) ? $order['StatusUpdatedBy'] : 'Petugas Finishing & QC',
            'specs' => ['Status Produksi' => $isOrderDone ? 'Done (Selesai)' : 'Dalam Pengerjaan', 'Metode Penyerahan' => $isDikirimPaket ? 'Dikirim Paket (Ekspedisi)' : 'Diambil ke Workshop']
        ];

        if ($isDikirimPaket) {
            $isDelivered = stripos(isset($order['CourierStatus']) ? $order['CourierStatus'] : '', 'diterima') !== false;
            $timeline[] = [
                'key' => 'ekspedisi',
                'division' => 'Ekspedisi / Pengiriman Paket',
                'status' => $isDelivered ? 'Paket Telah Diterima Konsumen' : ($order['CourierStatus'] ?: ($isOrderDone ? 'Menunggu Kurir' : 'Antrian Pengiriman')),
                'title' => 'Pengiriman via Ekspedisi ' . (!empty($order['CourierName']) ? $order['CourierName'] : 'Kurir Paket'),
                'date' => ($isOrderDone && !empty($order['CourierTrackingNo'])) ? (isset($order['StatusUpdatedAt']) ? $order['StatusUpdatedAt'] : null) : null,
                'icon' => 'truck',
                'done' => $isDelivered,
                'isCurrent' => $isOrderDone && !$isDelivered,
                'desc' => !empty($order['CourierTrackingNo']) ? "Resi: {$order['CourierTrackingNo']}" : "Pengiriman ke: " . (!empty($order['AlamatPengiriman']) ? $order['AlamatPengiriman'] : '-'),
                'operator' => !empty($order['CourierName']) ? $order['CourierName'] : 'Petugas Ekspedisi',
                'specs' => ['Ekspedisi' => !empty($order['CourierName']) ? $order['CourierName'] : 'J&T Express', 'Nomor Resi' => !empty($order['CourierTrackingNo']) ? $order['CourierTrackingNo'] : 'Menunggu Resi']
            ];
        }

        $baseTs = strtotime(!empty($order['TanggalOrder']) ? $order['TanggalOrder'] : (!empty($order['CreatedAt']) ? $order['CreatedAt'] : 'now'));
        $history = [
            [
                'id' => "HIST-{$order['ID']}-01",
                'stage' => 'Penerimaan Order',
                'status' => 'Order Dibuat',
                'title' => 'Order Pesanan Diterima oleh CS',
                'description' => "Pesanan {$order['ID']} didaftarkan oleh " . (!empty($order['CreatedBy']) ? $order['CreatedBy'] : 'CS') . ". File desain {$order['NamaFile']} terverifikasi.",
                'timestamp' => gmdate('Y-m-d\TH:i:s.000\Z', $baseTs),
                'operatorName' => !empty($order['CreatedBy']) ? $order['CreatedBy'] : 'Siti CS',
                'operatorRole' => 'Customer Service',
                'duration' => '10 Menit',
                'state' => 'completed',
                'icon' => 'cart',
                'technicalDetails' => ['Jenis Order' => $jenisOrder, 'Kriteria Prioritas' => isset($order['Kriteria']) ? $order['Kriteria'] : 'Normal']
            ]
        ];

        $relatedLogs = [];
        foreach ((isset($state['logs']) ? $state['logs'] : []) as $l) {
            $descL = strtolower(isset($l['Description']) ? $l['Description'] : '');
            if (strpos($descL, strtolower($order['ID'])) !== false ||
                ($spk && strpos($descL, strtolower($spk['ID'])) !== false) ||
                (!empty($order['NamaKonsumen']) && strpos($descL, strtolower($order['NamaKonsumen'])) !== false)) {
                $relatedLogs[] = $l;
            }
        }

        return [
            'order' => $order,
            'spk' => $spk,
            'timeline' => $timeline,
            'history' => $history,
            'relatedLogs' => $relatedLogs
        ];
    }

    public static function computeChecksum($str) {
        $hash = 0;
        $len = strlen($str);
        for ($i = 0; $i < $len; $i++) {
            $hash = (($hash << 5) - $hash) + ord($str[$i]);
            $hash = $hash & 0xFFFFFFFF;
            if ($hash & 0x80000000) $hash = $hash - 0x100000000;
        }
        return 'CRC32-' . strtoupper(str_pad(dechex(abs($hash)), 8, '0', STR_PAD_LEFT));
    }

    public static function getDatabaseCounts($state) {
        $o = count(isset($state['orders']) ? $state['orders'] : []);
        $s = count(isset($state['spkList']) ? $state['spkList'] : []);
        $m = count(isset($state['materials']) ? $state['materials'] : []);
        $i = count(isset($state['invoices']) ? $state['invoices'] : []);
        $p = count(isset($state['piutangs']) ? $state['piutangs'] : []);
        $u = count(isset($state['users']) ? $state['users'] : []);
        $l = count(isset($state['logs']) ? $state['logs'] : []);
        return [
            'orders' => $o, 'spk' => $s, 'materials' => $m, 'invoices' => $i,
            'piutang' => $p, 'users' => $u, 'logs' => $l,
            'totalRecords' => $o + $s + $m + $i + $p + $u + $l
        ];
    }

    public static function createFullSnapshotPayload($state) {
        $rawData = [
            'orders' => isset($state['orders']) ? $state['orders'] : [],
            'spkList' => isset($state['spkList']) ? $state['spkList'] : [],
            'materials' => isset($state['materials']) ? $state['materials'] : [],
            'invoices' => isset($state['invoices']) ? $state['invoices'] : [],
            'piutangs' => isset($state['piutangs']) ? $state['piutangs'] : [],
            'users' => isset($state['users']) ? $state['users'] : [],
            'logs' => isset($state['logs']) ? $state['logs'] : [],
            'rolePermissions' => isset($state['rolePermissions']) ? $state['rolePermissions'] : new stdClass(),
            'paperSettings' => isset($state['paperSettings']) ? $state['paperSettings'] : new stdClass(),
            'priceSettings' => isset($state['priceSettings']) ? $state['priceSettings'] : new stdClass(),
            'syncInfo' => isset($state['syncInfo']) ? $state['syncInfo'] : new stdClass(),
            'companyProfile' => isset($state['companyProfile']) ? $state['companyProfile'] : new stdClass()
        ];
        $jsonStr = json_encode($rawData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return [
            'version' => '3.0.0-3TIER',
            'exportedAt' => self::formatWIB(self::nowIso()),
            'appId' => 'PRINT-SUBLIME-ERP-3TIER',
            'checksum' => self::computeChecksum($jsonStr),
            'counts' => self::getDatabaseCounts($state),
            'data' => $rawData
        ];
    }

    public static function createServerSnapshot(&$state, $label = '', $trigger = 'auto_schedule', $description = '') {
        $payload = self::createFullSnapshotPayload($state);
        $dt = new DateTime('now', new DateTimeZone('Asia/Jakarta'));
        $id = 'SNAP-' . $dt->format('Ymd-His') . '-' . str_pad(strval(mt_rand(0, 999)), 3, '0', STR_PAD_LEFT);
        $sizeBytes = strlen(json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        $nowIso = self::nowIso();

        $meta = [
            'id' => $id,
            'timestamp' => self::formatWIB($nowIso),
            'createdAtISO' => $nowIso,
            'label' => $label ?: ('Snapshot Server (' . $dt->format('H:i:s') . ' WIB)'),
            'tier' => 2,
            'trigger' => $trigger,
            'sizeBytes' => $sizeBytes,
            'checksum' => $payload['checksum'],
            'counts' => $payload['counts'],
            'status' => 'Verified',
            'description' => $description ?: ("Titik pemulihan server dengan {$payload['counts']['totalRecords']} total data rekord."),
            'fullData' => $payload
        ];
        if (!isset($state['serverSnapshots']) || !is_array($state['serverSnapshots'])) $state['serverSnapshots'] = [];
        array_unshift($state['serverSnapshots'], $meta);
        $limit = !empty($state['backupConfig']['tier2']['retentionLimit']) ? intval($state['backupConfig']['tier2']['retentionLimit']) : 30;
        if (count($state['serverSnapshots']) > $limit) {
            $state['serverSnapshots'] = array_slice($state['serverSnapshots'], 0, $limit);
        }
        $state['backupConfig']['tier2']['lastServerSnapshotTimestamp'] = $nowIso;
        unset($meta['fullData']);
        return $meta;
    }

    private static function sqlStr($val) {
        if ($val === null) return 'NULL';
        if (is_array($val) || is_object($val)) {
            $s = json_encode($val, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        } else {
            $s = strval($val);
        }
        $s = str_replace(['\\', "'", "\n", "\r"], ['\\\\', "\\'", '\\n', '\\r'], $s);
        return "'" . $s . "'";
    }

    public static function generatePhpMyAdminSqlDump($state, $dbName = 'sublime_erp_db') {
        $ts = self::nowIso();
        $sql = "-- ==============================================================\n";
        $sql .= "-- phpMyAdmin SQL Dump & Setup (PHP cPanel Mode)\n";
        $sql .= "-- Sistem Manajemen Percetakan Sublime ERP\n";
        $sql .= "-- Dihasilkan pada: {$ts}\n";
        $sql .= "-- ==============================================================\n\n";
        $sql .= "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\nSTART TRANSACTION;\nSET time_zone = \"+07:00\";\n\n";
        $sql .= "DROP TABLE IF EXISTS `users`;\nCREATE TABLE `users` (`id` varchar(64) NOT NULL, `username` varchar(100) NOT NULL, `password` varchar(255) DEFAULT NULL, `nama` varchar(150) NOT NULL, `email` varchar(150) DEFAULT NULL, `noTelp` varchar(50) DEFAULT NULL, `role` varchar(50) NOT NULL, `active` tinyint(1) DEFAULT 1, `preferences` longtext DEFAULT NULL, `permissions` longtext DEFAULT NULL, `createdAt` varchar(50) DEFAULT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n";
        if (!empty($state['users'])) {
            $rows = [];
            foreach ($state['users'] as $u) {
                $rows[] = '(' . self::sqlStr($u['id']) . ',' . self::sqlStr($u['username']) . ',' . self::sqlStr(isset($u['password']) ? $u['password'] : '') . ',' . self::sqlStr($u['nama']) . ',' . self::sqlStr(isset($u['email']) ? $u['email'] : '') . ',' . self::sqlStr(isset($u['noTelp']) ? $u['noTelp'] : '') . ',' . self::sqlStr($u['role']) . ',' . (!empty($u['active']) ? 1 : 0) . ',' . self::sqlStr(isset($u['preferences']) ? $u['preferences'] : null) . ',' . self::sqlStr(isset($u['permissions']) ? $u['permissions'] : null) . ',' . self::sqlStr(isset($u['createdAt']) ? $u['createdAt'] : $ts) . ')';
            }
            $sql .= "INSERT INTO `users` (`id`,`username`,`password`,`nama`,`email`,`noTelp`,`role`,`active`,`preferences`,`permissions`,`createdAt`) VALUES\n" . implode(",\n", $rows) . ";\n\n";
        }

        $sql .= "DROP TABLE IF EXISTS `materials`;\nCREATE TABLE `materials` (`id` varchar(64) NOT NULL, `namaMaterial` varchar(150) NOT NULL, `satuan` varchar(50) DEFAULT 'Roll', `stok` decimal(12,2) DEFAULT 0.00, `minStok` decimal(12,2) DEFAULT 0.00, `harga` decimal(15,2) DEFAULT 0.00, `kategori` varchar(50) DEFAULT 'Paper', `data_json` longtext NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n";
        if (!empty($state['materials'])) {
            $rows = [];
            foreach ($state['materials'] as $m) {
                $rows[] = '(' . self::sqlStr($m['ID']) . ',' . self::sqlStr($m['NamaMaterial']) . ',' . self::sqlStr(isset($m['Satuan']) ? $m['Satuan'] : 'Roll') . ',' . floatval($m['Stok']) . ',' . floatval(isset($m['MinStok']) ? $m['MinStok'] : 0) . ',' . floatval(isset($m['Harga']) ? $m['Harga'] : 0) . ',' . self::sqlStr(isset($m['Kategori']) ? $m['Kategori'] : 'Paper') . ',' . self::sqlStr($m) . ')';
            }
            $sql .= "INSERT INTO `materials` (`id`,`namaMaterial`,`satuan`,`stok`,`minStok`,`harga`,`kategori`,`data_json`) VALUES\n" . implode(",\n", $rows) . ";\n\n";
        }

        $sql .= "DROP TABLE IF EXISTS `orders`;\nCREATE TABLE `orders` (`id` varchar(64) NOT NULL, `customerName` varchar(150) NOT NULL, `customerPhone` varchar(50) DEFAULT NULL, `jenisOrder` varchar(100) DEFAULT NULL, `status` varchar(50) NOT NULL, `paymentStatus` varchar(50) DEFAULT 'Belum Bayar', `totalHarga` decimal(15,2) DEFAULT 0.00, `meterPrint` decimal(10,2) DEFAULT 0.00, `kain` varchar(100) DEFAULT NULL, `kertas` varchar(100) DEFAULT NULL, `lebarKertas` varchar(50) DEFAULT NULL, `tanggalOrder` varchar(50) DEFAULT NULL, `deadline` varchar(50) DEFAULT NULL, `data_json` longtext NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n";
        if (!empty($state['orders'])) {
            $rows = [];
            foreach ($state['orders'] as $o) {
                $rows[] = '(' . self::sqlStr($o['ID']) . ',' . self::sqlStr(isset($o['NamaKonsumen']) ? $o['NamaKonsumen'] : '') . ',' . self::sqlStr(isset($o['NoTelpKonsumen']) ? $o['NoTelpKonsumen'] : '') . ',' . self::sqlStr(isset($o['JenisOrder']) ? $o['JenisOrder'] : '') . ',' . self::sqlStr(isset($o['Status']) ? $o['Status'] : 'Pending') . ",'Belum Bayar'," . floatval(isset($o['PriceTotal']) ? $o['PriceTotal'] : 0) . ',' . floatval(isset($o['MeterPrint']) ? $o['MeterPrint'] : 0) . ',' . self::sqlStr(isset($o['MaterialPress']) ? $o['MaterialPress'] : '') . ',' . self::sqlStr(isset($o['PaperType']) ? $o['PaperType'] : '') . ',' . self::sqlStr(isset($o['PaperSize']) ? $o['PaperSize'] : '') . ',' . self::sqlStr(isset($o['TanggalOrder']) ? $o['TanggalOrder'] : '') . ',' . self::sqlStr(isset($o['Deadline']) ? $o['Deadline'] : '') . ',' . self::sqlStr($o) . ')';
            }
            $sql .= "INSERT INTO `orders` (`id`,`customerName`,`customerPhone`,`jenisOrder`,`status`,`paymentStatus`,`totalHarga`,`meterPrint`,`kain`,`kertas`,`lebarKertas`,`tanggalOrder`,`deadline`,`data_json`) VALUES\n" . implode(",\n", $rows) . ";\n\n";
        }

        $sql .= "DROP TABLE IF EXISTS `spk`;\nCREATE TABLE `spk` (`id` varchar(64) NOT NULL, `orderId` varchar(64) NOT NULL, `nomorSPK` varchar(100) NOT NULL, `status` varchar(50) DEFAULT 'Pending', `operator` varchar(100) DEFAULT NULL, `deadline` varchar(50) DEFAULT NULL, `data_json` longtext NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n";
        if (!empty($state['spkList'])) {
            $rows = [];
            foreach ($state['spkList'] as $s) {
                $st = isset($s['StatusPrint']) ? $s['StatusPrint'] : 'Pending';
                $rows[] = '(' . self::sqlStr($s['ID']) . ',' . self::sqlStr(isset($s['OrderID']) ? $s['OrderID'] : $s['ID']) . ',' . self::sqlStr($s['ID']) . ',' . self::sqlStr($st) . ',' . self::sqlStr(isset($s['LayoutOperator']) ? $s['LayoutOperator'] : '') . ',' . self::sqlStr(isset($s['Deadline']) ? $s['Deadline'] : '') . ',' . self::sqlStr($s) . ')';
            }
            $sql .= "INSERT INTO `spk` (`id`,`orderId`,`nomorSPK`,`status`,`operator`,`deadline`,`data_json`) VALUES\n" . implode(",\n", $rows) . ";\n\n";
        }

        $sql .= "DROP TABLE IF EXISTS `invoices`;\nCREATE TABLE `invoices` (`id` varchar(64) NOT NULL, `orderId` varchar(64) DEFAULT NULL, `invoiceNumber` varchar(100) NOT NULL, `namaKonsumen` varchar(150) DEFAULT NULL, `totalAmount` decimal(15,2) DEFAULT 0.00, `sisaTagihan` decimal(15,2) DEFAULT 0.00, `statusPembayaran` varchar(50) DEFAULT 'Unpaid', `data_json` longtext NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n";
        if (!empty($state['invoices'])) {
            $rows = [];
            foreach ($state['invoices'] as $inv) {
                $tot = floatval(isset($inv['TotalAmount']) ? $inv['TotalAmount'] : 0);
                $paid = floatval(isset($inv['PaidAmount']) ? $inv['PaidAmount'] : 0);
                $rows[] = '(' . self::sqlStr($inv['ID']) . ',' . self::sqlStr(isset($inv['OrderID']) ? $inv['OrderID'] : '') . ',' . self::sqlStr($inv['ID']) . ',' . self::sqlStr(isset($inv['NamaKonsumen']) ? $inv['NamaKonsumen'] : '') . ',' . $tot . ',' . max(0, $tot - $paid) . ',' . self::sqlStr(isset($inv['Status']) ? $inv['Status'] : 'Unpaid') . ',' . self::sqlStr($inv) . ')';
            }
            $sql .= "INSERT INTO `invoices` (`id`,`orderId`,`invoiceNumber`,`namaKonsumen`,`totalAmount`,`sisaTagihan`,`statusPembayaran`,`data_json`) VALUES\n" . implode(",\n", $rows) . ";\n\n";
        }

        $sql .= "DROP TABLE IF EXISTS `piutang`;\nCREATE TABLE `piutang` (`id` varchar(64) NOT NULL, `orderId` varchar(64) DEFAULT NULL, `customerName` varchar(150) DEFAULT NULL, `totalHutang` decimal(15,2) DEFAULT 0.00, `sisaTagihan` decimal(15,2) DEFAULT 0.00, `status` varchar(50) DEFAULT 'Belum Lunas', `data_json` longtext NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n";
        if (!empty($state['piutangs'])) {
            $rows = [];
            foreach ($state['piutangs'] as $p) {
                $rows[] = '(' . self::sqlStr($p['ID']) . ',' . self::sqlStr(isset($p['InvoiceID']) ? $p['InvoiceID'] : '') . ',' . self::sqlStr(isset($p['NamaKonsumen']) ? $p['NamaKonsumen'] : '') . ',' . floatval(isset($p['Jumlah']) ? $p['Jumlah'] : 0) . ',' . floatval(isset($p['Sisa']) ? $p['Sisa'] : 0) . ',' . self::sqlStr(isset($p['Status']) ? $p['Status'] : 'Belum Lunas') . ',' . self::sqlStr($p) . ')';
            }
            $sql .= "INSERT INTO `piutang` (`id`,`orderId`,`customerName`,`totalHutang`,`sisaTagihan`,`status`,`data_json`) VALUES\n" . implode(",\n", $rows) . ";\n\n";
        }

        $sql .= "DROP TABLE IF EXISTS `customers`;\nCREATE TABLE `customers` (`id` varchar(64) NOT NULL, `nama` varchar(150) NOT NULL, `noTelp` varchar(50) DEFAULT NULL, `email` varchar(150) DEFAULT NULL, `alamat` text DEFAULT NULL, `catatan` text DEFAULT NULL, `createdAt` varchar(50) DEFAULT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n";
        if (!empty($state['customerProfiles'])) {
            $rows = [];
            foreach ($state['customerProfiles'] as $c) {
                $rows[] = '(' . self::sqlStr(isset($c['id']) ? $c['id'] : '') . ',' . self::sqlStr(isset($c['nama']) ? $c['nama'] : '') . ',' . self::sqlStr(isset($c['noTelp']) ? $c['noTelp'] : '') . ',' . self::sqlStr(isset($c['email']) ? $c['email'] : '') . ',' . self::sqlStr(isset($c['alamat']) ? $c['alamat'] : '') . ',' . self::sqlStr(isset($c['catatan']) ? $c['catatan'] : '') . ',' . self::sqlStr(isset($c['createdAt']) ? $c['createdAt'] : $ts) . ')';
            }
            $sql .= "INSERT INTO `customers` (`id`,`nama`,`noTelp`,`email`,`alamat`,`catatan`,`createdAt`) VALUES\n" . implode(",\n", $rows) . ";\n\n";
        }

        $sql .= "DROP TABLE IF EXISTS `operational_expenses`;\nCREATE TABLE `operational_expenses` (`id` varchar(64) NOT NULL, `tanggal` varchar(50) NOT NULL, `kategori` varchar(100) NOT NULL, `nominal` decimal(15,2) DEFAULT 0.00, `keterangan` text DEFAULT NULL, `metodeBayar` varchar(100) DEFAULT NULL, `noReferensi` varchar(100) DEFAULT NULL, `dicatatOleh` varchar(100) DEFAULT NULL, `createdAt` varchar(50) DEFAULT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n";
        if (!empty($state['operationalExpenses'])) {
            $rows = [];
            foreach ($state['operationalExpenses'] as $e) {
                $rows[] = '(' . self::sqlStr(isset($e['id']) ? $e['id'] : '') . ',' . self::sqlStr(isset($e['tanggal']) ? $e['tanggal'] : '') . ',' . self::sqlStr(isset($e['kategori']) ? $e['kategori'] : '') . ',' . floatval(isset($e['nominal']) ? $e['nominal'] : 0) . ',' . self::sqlStr(isset($e['keterangan']) ? $e['keterangan'] : '') . ',' . self::sqlStr(isset($e['metodeBayar']) ? $e['metodeBayar'] : '') . ',' . self::sqlStr(isset($e['noReferensi']) ? $e['noReferensi'] : '') . ',' . self::sqlStr(isset($e['dicatatOleh']) ? $e['dicatatOleh'] : '') . ',' . self::sqlStr(isset($e['createdAt']) ? $e['createdAt'] : $ts) . ')';
            }
            $sql .= "INSERT INTO `operational_expenses` (`id`,`tanggal`,`kategori`,`nominal`,`keterangan`,`metodeBayar`,`noReferensi`,`dicatatOleh`,`createdAt`) VALUES\n" . implode(",\n", $rows) . ";\n\n";
        }

        $sql .= "DROP TABLE IF EXISTS `system_settings`;\nCREATE TABLE `system_settings` (`settingKey` varchar(100) NOT NULL, `settingValue` longtext NOT NULL, PRIMARY KEY (`settingKey`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n";
        $sql .= "INSERT INTO `system_settings` (`settingKey`,`settingValue`) VALUES\n";
        $sql .= "('paper'," . self::sqlStr($state['paperSettings']) . "),\n";
        $sql .= "('prices'," . self::sqlStr($state['priceSettings']) . "),\n";
        $sql .= "('permissions'," . self::sqlStr($state['rolePermissions']) . "),\n";
        $sql .= "('company'," . self::sqlStr($state['companyProfile']) . ");\n\nCOMMIT;\n";
        return $sql;
    }

    public static function syncToPayroll(&$state, $tx) {
        if (!isset($state['payrollTransactions']) || !is_array($state['payrollTransactions'])) $state['payrollTransactions'] = [];
        $updated = false;
        foreach ($state['payrollTransactions'] as $idx => $existing) {
            if (isset($existing['id']) && $existing['id'] === $tx['id']) {
                $state['payrollTransactions'][$idx] = $tx;
                $updated = true;
                break;
            }
        }
        if (!$updated) array_unshift($state['payrollTransactions'], $tx);
        if (count($state['payrollTransactions']) > 200) {
            $state['payrollTransactions'] = array_slice($state['payrollTransactions'], 0, 200);
        }

        $targetUrl = !empty($state['payrollConfig']['targetUrl']) ? trim($state['payrollConfig']['targetUrl']) : '';
        $enabled = !empty($state['payrollConfig']['enabled']);
        if ($enabled && !empty($targetUrl) && function_exists('curl_init')) {
            try {
                $ch = curl_init($targetUrl);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($tx));
                curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_TIMEOUT, 2);
                @curl_exec($ch);
                @curl_close($ch);
            } catch (Exception $e) {}
        }
        return ['success' => true, 'id' => $tx['id'], 'message' => 'Transaksi tersinkronisasi!', 'targetDb' => $targetUrl ?: 'local_storage'];
    }
}

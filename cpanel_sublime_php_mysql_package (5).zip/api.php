<?php
/**
 * Print Sublime ERP - PHP REST API Controller
 * Dirancang untuk cPanel Standar (Apache / LiteSpeed + PHP 7.4/8.x + MySQL/JSON)
 * Tanpa memerlukan Node.js runtime atau daemon background.
 */

@date_default_timezone_set('Asia/Jakarta');
@ini_set('display_errors', '0');

require_once __DIR__ . '/php_lib/Store.php';
require_once __DIR__ . '/php_lib/Helpers.php';

// Header default JSON & CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-User-Role, X-User-Id, X-User-Nama, X-User-Username, X-User-Can-Edit-Settings');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper($_SERVER['REQUEST_METHOD']) : 'GET';
if ($method === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// Parse request path relatif terhadap /api (mendukung root domain maupun subfolder!)
$reqUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/api/health';
$rawPath = parse_url($reqUri, PHP_URL_PATH);
if (!$rawPath) $rawPath = '/';
$apiPos = strpos($rawPath, '/api');
if ($apiPos !== false) {
    $path = substr($rawPath, $apiPos);
} else {
    $path = '/api/' . ltrim($rawPath, '/');
}
$path = rtrim($path, '/');
if ($path === '') $path = '/api';

// Extract headers
$headers = [];
if (function_exists('getallheaders')) {
    $allH = getallheaders();
    if (is_array($allH)) {
        foreach ($allH as $k => $v) $headers[strtolower($k)] = $v;
    }
}
foreach ($_SERVER as $k => $v) {
    if (substr($k, 0, 5) === 'HTTP_') {
        $hName = str_replace('_', '-', strtolower(substr($k, 5)));
        $headers[$hName] = $v;
    }
}

// Parse JSON request body
$rawInput = @file_get_contents('php://input');
$body = [];
if ($rawInput !== false && trim($rawInput) !== '') {
    $decoded = json_decode($rawInput, true);
    if (is_array($decoded)) $body = $decoded;
}
$query = is_array($_GET) ? $_GET : [];

function jsonOut($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function getRemoteIp() {
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $parts = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($parts[0]);
    }
    return !empty($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1';
}

try {
    // ========================================================
    // FAST ENDPOINTS (Tanpa load app_state.json penuh)
    // ========================================================
    if ($method === 'GET' && $path === '/api/health') {
        jsonOut([
            'status' => 'ok',
            'mode' => 'php-cpanel',
            'phpVersion' => PHP_VERSION,
            'time' => ErpHelpers::nowIso()
        ]);
    }

    if ($method === 'GET' && $path === '/api/notifications/stream') {
        // Jangan pernah buat infinite loop di PHP shared hosting agar tidak kena 503 Worker Exhaustion!
        // Mengembalikan respons cepat agar client NotificationContext otomatis beralih ke polling 5 detik.
        jsonOut([
            'success' => false,
            'mode' => 'php-polling',
            'message' => 'SSE dinonaktifkan pada mode PHP shared hosting; menggunakan polling HTTP otomatis.'
        ], 501);
    }

    if ($method === 'POST' && $path === '/api/network/heartbeat') {
        $sinceTs = isset($body['since']) ? $body['since'] : (isset($query['since']) ? $query['since'] : null);
        $rtData = ErpStore::heartbeatAndFetchEvents($body, getRemoteIp(), $sinceTs);
        jsonOut(['success' => true, 'data' => $rtData]);
    }

    if ($method === 'POST' && $path === '/api/network/event') {
        $ev = isset($body['event']) ? $body['event'] : '';
        if (!empty($ev)) {
            ErpStore::pushRealtimeEvent(
                $ev,
                isset($body['payload']) ? $body['payload'] : [],
                isset($body['sender']) ? $body['sender'] : null,
                'broadcast:event'
            );
        }
        jsonOut(['success' => true]);
    }

    if ($method === 'GET' && $path === '/api/network/info') {
        $devices = ErpStore::getConnectedDevicesSnapshot();
        $host = !empty($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : gethostname();
        $srvAddr = !empty($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : '127.0.0.1';
        $port = !empty($_SERVER['SERVER_PORT']) ? intval($_SERVER['SERVER_PORT']) : 80;
        jsonOut([
            'success' => true,
            'data' => [
                'wsSupported' => false,
                'mode' => 'php-polling',
                'lanIps' => [$srvAddr],
                'port' => $port,
                'hostname' => $host,
                'serverTime' => ErpHelpers::nowIso(),
                'connectedDevices' => $devices,
                'totalConnected' => count($devices),
                'origin' => ErpHelpers::getAppOrigin()
            ]
        ]);
    }

    // Load authoritative state
    $state = ErpStore::loadState();

    // ========================================================
    // NETWORK BROADCAST
    // ========================================================
    if ($method === 'POST' && $path === '/api/network/broadcast') {
        $title = isset($body['title']) ? trim($body['title']) : '';
        $message = isset($body['message']) ? trim($body['message']) : '';
        if (!$title || !$message) {
            jsonOut(['success' => false, 'message' => 'Judul dan pesan wajib diisi.'], 400);
        }
        $sender = isset($body['sender']) ? $body['sender'] : ['userName' => 'Admin Workshop', 'userRole' => 'Super Admin'];
        ErpStore::pushRealtimeEvent('urgent-announcement', ['title' => $title, 'message' => $message], $sender, 'broadcast:urgent', [
            'title' => $title,
            'message' => $message
        ]);
        ErpHelpers::broadcastNotification($state, $title, $message, 'warning');
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => 'Pengumuman berhasil disiarkan ke semua layar perangkat!']);
    }

    // ========================================================
    // AUTHENTICATION
    // ========================================================
    if ($method === 'POST' && $path === '/api/login') {
        $username = isset($body['username']) ? trim($body['username']) : '';
        $password = isset($body['password']) ? $body['password'] : '';
        if (!$username || !$password) {
            jsonOut(['success' => false, 'message' => 'Username dan password wajib diisi!'], 400);
        }
        $lowerInput = strtolower($username);
        $user = null;
        foreach ($state['users'] as $u) {
            if (strtolower(isset($u['username']) ? $u['username'] : '') === $lowerInput && !empty($u['active'])) {
                $user = $u;
                break;
            }
        }
        if (!$user) {
            jsonOut(['success' => false, 'message' => 'Username tidak ditemukan atau akun dinonaktifkan!'], 401);
        }
        $defaultPass = in_array($user['username'], ['superadmin', 'administrasi', 'koord']) ? 'admin123' : 'password123';
        $expectedPass = !empty($user['password']) ? $user['password'] : $defaultPass;
        if ($password !== $expectedPass) {
            jsonOut(['success' => false, 'message' => 'Password salah! Silakan coba lagi atau gunakan fitur Ganti Password.'], 401);
        }
        ErpHelpers::addLog($state, $user['id'], $user['nama'], 'LOGIN', 'User berhasil login ke sistem');
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => 'Login berhasil!', 'user' => $user]);
    }

    if ($method === 'POST' && $path === '/api/change-password') {
        $username = isset($body['username']) ? trim($body['username']) : '';
        $userId = isset($body['userId']) ? $body['userId'] : '';
        $oldPass = isset($body['oldPassword']) ? $body['oldPassword'] : '';
        $newPass = isset($body['newPassword']) ? trim($body['newPassword']) : '';
        $isReset = !empty($body['isResetByAdmin']);

        if (strlen($newPass) < 4) {
            jsonOut(['success' => false, 'message' => 'Password baru minimal 4 karakter!'], 400);
        }
        $tIdx = -1;
        foreach ($state['users'] as $idx => $u) {
            if (($userId && $u['id'] === $userId) || ($username && strtolower($u['username']) === strtolower($username))) {
                $tIdx = $idx; break;
            }
        }
        if ($tIdx === -1) {
            jsonOut(['success' => false, 'message' => 'Pengguna tidak ditemukan!'], 404);
        }
        $target = &$state['users'][$tIdx];
        if (!$isReset && $oldPass !== '') {
            $currPass = !empty($target['password']) ? $target['password'] : (in_array($target['username'], ['superadmin', 'administrasi', 'koord']) ? 'admin123' : 'password123');
            if ($oldPass !== $currPass) {
                jsonOut(['success' => false, 'message' => 'Password lama tidak sesuai!'], 400);
            }
        }
        $target['password'] = $newPass;
        ErpHelpers::addLog($state, $target['id'], $target['nama'], 'CHANGE_PASSWORD', "Memperbarui password akun user: {$target['username']}");
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => "Password akun @{$target['username']} berhasil diubah!", 'user' => $target]);
    }

    // ========================================================
    // WEBAUTHN / BIOMETRIC (FINGERPRINT) LOGIN API (PHP)
    // ========================================================
    $b64uEncode = function ($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    };
    $b64uDecode = function ($data) {
        $pad = strlen($data) % 4;
        if ($pad) $data .= str_repeat('=', 4 - $pad);
        return base64_decode(strtr($data, '-_', '+/'));
    };
    $getWebAuthnRpId = function () use ($headers) {
        $origin = ErpHelpers::getHeader($headers, 'origin');
        if ($origin) {
            $parsed = @parse_url($origin);
            if (!empty($parsed['host'])) return $parsed['host'];
        }
        $host = ErpHelpers::getHeader($headers, 'x-forwarded-host') ?: (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost');
        $host = trim(explode(',', $host)[0]);
        return preg_replace('/:\d+$/', '', $host) ?: 'localhost';
    };
    $challengeFile = __DIR__ . '/storage/webauthn_challenges.json';
    $loadChallenges = function () use ($challengeFile) {
        if (!file_exists($challengeFile)) return [];
        $raw = @file_get_contents($challengeFile);
        $arr = json_decode($raw, true);
        if (!is_array($arr)) return [];
        $now = time();
        $clean = [];
        foreach ($arr as $k => $v) {
            if (isset($v['expiresAt']) && $v['expiresAt'] >= $now) $clean[$k] = $v;
        }
        return $clean;
    };
    $saveChallenges = function ($arr) use ($challengeFile) {
        @file_put_contents($challengeFile, json_encode($arr));
    };

    if ($method === 'POST' && $path === '/api/auth/webauthn/register-options') {
        $uid = isset($body['userId']) ? $body['userId'] : '';
        $uname = isset($body['username']) ? strtolower(trim($body['username'])) : '';
        $attachmentMode = isset($body['attachmentMode']) ? $body['attachmentMode'] : 'platform';
        $targetUser = null;
        foreach ($state['users'] as $u) {
            if (!empty($u['active']) && (($uid && $u['id'] === $uid) || ($uname && strtolower($u['username']) === $uname))) {
                $targetUser = $u;
                break;
            }
        }
        if (!$targetUser) jsonOut(['success' => false, 'message' => 'Akun user aktif tidak ditemukan.'], 404);

        $rpId = $getWebAuthnRpId();
        $challenge = $b64uEncode(random_bytes(32));
        $challengeId = 'ch-' . time() . '-' . bin2hex(random_bytes(4));
        $challenges = $loadChallenges();
        $challenges[$challengeId] = [
            'challenge' => $challenge,
            'rpId' => $rpId,
            'userId' => $targetUser['id'],
            'username' => $targetUser['username'],
            'expiresAt' => time() + 300
        ];
        $saveChallenges($challenges);

        $exclude = [];
        $creds = isset($targetUser['preferences']['biometricCredentials']) ? $targetUser['preferences']['biometricCredentials'] : [];
        foreach ($creds as $c) {
            $exclude[] = [
                'id' => $c['credentialId'],
                'type' => 'public-key',
                'transports' => !empty($c['transports']) ? $c['transports'] : ['internal']
            ];
        }
        $authSelection = [
            'userVerification' => 'required',
            'residentKey' => 'preferred',
            'requireResidentKey' => false
        ];
        if ($attachmentMode === 'cross-platform') {
            $authSelection['authenticatorAttachment'] = 'cross-platform';
        } elseif ($attachmentMode !== 'any') {
            $authSelection['authenticatorAttachment'] = 'platform';
        }
        $appName = !empty($state['companyProfile']['appName']) ? $state['companyProfile']['appName'] : 'Sublime Management';
        jsonOut([
            'success' => true,
            'data' => [
                'challengeId' => $challengeId,
                'publicKey' => [
                    'challenge' => $challenge,
                    'rp' => ['name' => $appName, 'id' => $rpId],
                    'user' => [
                        'id' => $b64uEncode($targetUser['id']),
                        'name' => $targetUser['username'],
                        'displayName' => "{$targetUser['nama']} ({$targetUser['role']})"
                    ],
                    'pubKeyCredParams' => [
                        ['alg' => -7, 'type' => 'public-key'],
                        ['alg' => -257, 'type' => 'public-key']
                    ],
                    'timeout' => 60000,
                    'attestation' => 'none',
                    'excludeCredentials' => $exclude,
                    'authenticatorSelection' => $authSelection
                ]
            ]
        ]);
    }

    if ($method === 'POST' && $path === '/api/auth/webauthn/register-verify') {
        $challengeId = isset($body['challengeId']) ? $body['challengeId'] : '';
        $challenges = $loadChallenges();
        if (empty($challenges[$challengeId])) {
            jsonOut(['success' => false, 'message' => 'Sesi pendaftaran sidik jari kedaluwarsa. Silakan ulangi.'], 400);
        }
        $entry = $challenges[$challengeId];
        unset($challenges[$challengeId]);
        $saveChallenges($challenges);

        $uid = !empty($body['userId']) ? $body['userId'] : $entry['userId'];
        $credentialId = isset($body['credentialId']) ? $body['credentialId'] : '';
        $clientDataJSON = isset($body['clientDataJSON']) ? $body['clientDataJSON'] : '';
        $publicKeySpki = isset($body['publicKeySpki']) ? $body['publicKeySpki'] : '';

        $clientData = json_decode($b64uDecode($clientDataJSON), true);
        if (!$clientData || ($clientData['type'] ?? '') !== 'webauthn.create' || ($clientData['challenge'] ?? '') !== $entry['challenge']) {
            jsonOut(['success' => false, 'message' => 'Verifikasi challenge pendaftaran sidik jari tidak valid.'], 400);
        }
        if (!$credentialId || !$publicKeySpki) {
            jsonOut(['success' => false, 'message' => 'Kunci publik biometrik tidak tersedia dari browser ini.'], 400);
        }

        $tIdx = -1;
        foreach ($state['users'] as $idx => $u) {
            if ($u['id'] === $uid && !empty($u['active'])) { $tIdx = $idx; break; }
        }
        if ($tIdx === -1) jsonOut(['success' => false, 'message' => 'User tidak ditemukan atau tidak aktif.'], 404);

        $target = &$state['users'][$tIdx];
        if (!isset($target['preferences']) || !is_array($target['preferences'])) $target['preferences'] = [];
        $existingCreds = isset($target['preferences']['biometricCredentials']) && is_array($target['preferences']['biometricCredentials'])
            ? $target['preferences']['biometricCredentials'] : [];

        $newCred = [
            'credentialId' => $credentialId,
            'publicKey' => $publicKeySpki,
            'algorithm' => isset($body['algorithm']) ? intval($body['algorithm']) : -7,
            'counter' => 0,
            'deviceName' => substr(strval(!empty($body['deviceName']) ? $body['deviceName'] : 'Perangkat Biometrik'), 0, 80),
            'transports' => !empty($body['transports']) && is_array($body['transports']) ? $body['transports'] : ['internal'],
            'rpId' => $entry['rpId'],
            'createdAt' => ErpHelpers::nowIso()
        ];

        $filteredCreds = [$newCred];
        foreach ($existingCreds as $ec) {
            if (($ec['credentialId'] ?? '') !== $credentialId && count($filteredCreds) < 5) {
                $filteredCreds[] = $ec;
            }
        }
        $target['preferences']['biometricCredentials'] = $filteredCreds;

        ErpHelpers::addLog($state, $target['id'], $target['nama'], 'REGISTER_BIOMETRIC', "Mendaftarkan sidik jari/biometrik perangkat: {$newCred['deviceName']}");
        ErpStore::saveState($state);
        jsonOut([
            'success' => true,
            'message' => "Sidik jari pada \"{$newCred['deviceName']}\" berhasil diaktifkan!",
            'credentialId' => $credentialId,
            'user' => $target
        ]);
    }

    if ($method === 'POST' && $path === '/api/auth/webauthn/login-options') {
        $uname = isset($body['username']) ? trim($body['username']) : '';
        $rpId = $getWebAuthnRpId();
        $challenge = $b64uEncode(random_bytes(32));
        $challengeId = 'ch-' . time() . '-' . bin2hex(random_bytes(4));
        $allowCredentials = [];

        if ($uname !== '') {
            $lower = strtolower($uname);
            $targetUser = null;
            foreach ($state['users'] as $u) {
                if (strtolower($u['username']) === $lower && !empty($u['active'])) { $targetUser = $u; break; }
            }
            if (!$targetUser) jsonOut(['success' => false, 'message' => 'Username tidak ditemukan atau akun dinonaktifkan.'], 404);
            $creds = isset($targetUser['preferences']['biometricCredentials']) ? $targetUser['preferences']['biometricCredentials'] : [];
            if (empty($creds)) {
                jsonOut(['success' => false, 'message' => "Akun @{$targetUser['username']} belum mendaftarkan sidik jari. Silakan login dengan password dulu lalu aktifkan Sidik Jari di menu profil."], 400);
            }
            foreach ($creds as $c) {
                $allowCredentials[] = ['id' => $c['credentialId'], 'type' => 'public-key', 'transports' => !empty($c['transports']) ? $c['transports'] : ['internal']];
            }
        } else {
            foreach ($state['users'] as $u) {
                if (empty($u['active'])) continue;
                $creds = isset($u['preferences']['biometricCredentials']) ? $u['preferences']['biometricCredentials'] : [];
                foreach ($creds as $c) {
                    $allowCredentials[] = ['id' => $c['credentialId'], 'type' => 'public-key', 'transports' => !empty($c['transports']) ? $c['transports'] : ['internal']];
                }
            }
            if (empty($allowCredentials)) {
                jsonOut(['success' => false, 'message' => 'Belum ada akun yang mengaktifkan sidik jari di server. Silakan login dengan password lalu aktifkan Sidik Jari di menu profil.'], 400);
            }
        }

        $challenges = $loadChallenges();
        $challenges[$challengeId] = [
            'challenge' => $challenge,
            'rpId' => $rpId,
            'username' => $uname ?: null,
            'expiresAt' => time() + 300
        ];
        $saveChallenges($challenges);

        jsonOut([
            'success' => true,
            'data' => [
                'challengeId' => $challengeId,
                'publicKey' => [
                    'challenge' => $challenge,
                    'rpId' => $rpId,
                    'timeout' => 60000,
                    'userVerification' => 'required',
                    'allowCredentials' => $allowCredentials
                ]
            ]
        ]);
    }

    if ($method === 'POST' && $path === '/api/auth/webauthn/login-verify') {
        $challengeId = isset($body['challengeId']) ? $body['challengeId'] : '';
        $challenges = $loadChallenges();
        if (empty($challenges[$challengeId])) {
            jsonOut(['success' => false, 'message' => 'Sesi verifikasi sidik jari kedaluwarsa. Silakan coba lagi.'], 400);
        }
        $entry = $challenges[$challengeId];
        unset($challenges[$challengeId]);
        $saveChallenges($challenges);

        $credentialId = isset($body['credentialId']) ? $body['credentialId'] : '';
        $clientDataJSON = isset($body['clientDataJSON']) ? $body['clientDataJSON'] : '';
        $authenticatorData = isset($body['authenticatorData']) ? $body['authenticatorData'] : '';
        $signature = isset($body['signature']) ? $body['signature'] : '';

        $uIdx = -1;
        $cIdx = -1;
        foreach ($state['users'] as $i => $u) {
            if (empty($u['active'])) continue;
            $creds = isset($u['preferences']['biometricCredentials']) ? $u['preferences']['biometricCredentials'] : [];
            foreach ($creds as $j => $c) {
                if (($c['credentialId'] ?? '') === $credentialId) {
                    $uIdx = $i; $cIdx = $j; break 2;
                }
            }
        }
        if ($uIdx === -1) {
            jsonOut(['success' => false, 'message' => 'Sidik jari ini tidak terdaftar pada akun aktif mana pun.'], 401);
        }

        $clientDataBytes = $b64uDecode($clientDataJSON);
        $clientData = json_decode($clientDataBytes, true);
        if (!$clientData || ($clientData['type'] ?? '') !== 'webauthn.get' || ($clientData['challenge'] ?? '') !== $entry['challenge']) {
            jsonOut(['success' => false, 'message' => 'Challenge otentikasi sidik jari tidak valid.'], 401);
        }

        $authDataBytes = $b64uDecode($authenticatorData);
        if (strlen($authDataBytes) < 37) {
            jsonOut(['success' => false, 'message' => 'AuthenticatorData tidak valid.'], 401);
        }
        $rpIdHash = substr($authDataBytes, 0, 32);
        $expectedCurrent = hash('sha256', $entry['rpId'], true);
        $storedRpId = !empty($state['users'][$uIdx]['preferences']['biometricCredentials'][$cIdx]['rpId'])
            ? $state['users'][$uIdx]['preferences']['biometricCredentials'][$cIdx]['rpId'] : '';
        $expectedStored = $storedRpId ? hash('sha256', $storedRpId, true) : '';
        if (!hash_equals($expectedCurrent, $rpIdHash) && (!$expectedStored || !hash_equals($expectedStored, $rpIdHash))) {
            jsonOut(['success' => false, 'message' => 'Domain sidik jari tidak cocok dengan server.'], 401);
        }
        if ((ord($authDataBytes[32]) & 0x01) === 0) {
            jsonOut(['success' => false, 'message' => 'Kehadiran pengguna tidak terverifikasi.'], 401);
        }

        $spkiDer = $b64uDecode($state['users'][$uIdx]['preferences']['biometricCredentials'][$cIdx]['publicKey']);
        $pem = "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($spkiDer), 64, "\n") . "-----END PUBLIC KEY-----\n";
        $signedPayload = $authDataBytes . hash('sha256', $clientDataBytes, true);
        $sigBytes = $b64uDecode($signature);
        if (openssl_verify($signedPayload, $sigBytes, $pem, OPENSSL_ALGO_SHA256) !== 1) {
            jsonOut(['success' => false, 'message' => 'Tanda tangan kriptografi sidik jari tidak valid.'], 401);
        }

        $state['users'][$uIdx]['preferences']['biometricCredentials'][$cIdx]['lastUsedAt'] = ErpHelpers::nowIso();
        $matchedUser = $state['users'][$uIdx];
        $devName = $matchedUser['preferences']['biometricCredentials'][$cIdx]['deviceName'] ?? 'Perangkat Biometrik';
        ErpHelpers::addLog($state, $matchedUser['id'], $matchedUser['nama'], 'LOGIN_BIOMETRIC', "User berhasil login menggunakan sidik jari ({$devName})");
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => "Login sidik jari berhasil! Selamat datang, {$matchedUser['nama']}.", 'user' => $matchedUser]);
    }

    if ($method === 'POST' && $path === '/api/auth/webauthn/remove') {
        $uid = isset($body['userId']) ? $body['userId'] : '';
        $credId = isset($body['credentialId']) ? $body['credentialId'] : '';
        foreach ($state['users'] as &$u) {
            if ($u['id'] === $uid) {
                $creds = isset($u['preferences']['biometricCredentials']) ? $u['preferences']['biometricCredentials'] : [];
                $next = [];
                $removedName = '';
                foreach ($creds as $c) {
                    if (($c['credentialId'] ?? '') === $credId) { $removedName = $c['deviceName'] ?? 'Perangkat'; }
                    else { $next[] = $c; }
                }
                if (!isset($u['preferences']) || !is_array($u['preferences'])) $u['preferences'] = [];
                $u['preferences']['biometricCredentials'] = $next;
                if ($removedName) {
                    ErpHelpers::addLog($state, $u['id'], $u['nama'], 'REMOVE_BIOMETRIC', "Menghapus perangkat sidik jari: {$removedName}");
                }
                ErpStore::saveState($state);
                jsonOut(['success' => true, 'message' => 'Perangkat sidik jari berhasil dihapus dari akun.', 'user' => $u]);
            }
        }
        unset($u);
        jsonOut(['success' => false, 'message' => 'User tidak ditemukan.'], 404);
    }

    // ========================================================
    // USERS
    // ========================================================
    if ($method === 'GET' && $path === '/api/users') {
        $mysqlInfo = ErpStore::getMysqlConfig();
        jsonOut([
            'success' => true,
            'data' => $state['users'],
            'storage' => [
                'diskFile' => 'storage/app_state.json',
                'mysqlConnected' => !empty($mysqlInfo['configured']),
                'mysqlDatabase' => !empty($mysqlInfo['database']) ? $mysqlInfo['database'] : 'sublime_erp_db',
                'totalUsers' => count($state['users'])
            ]
        ]);
    }

    if ($method === 'POST' && $path === '/api/users') {
        $userRole = ErpHelpers::getHeader($headers, 'x-user-role') ?: (isset($body['userRole']) ? $body['userRole'] : '');
        $allowed = ($userRole === 'Super Admin' || $userRole === 'Koord' || (!empty($userRole) && !empty($state['rolePermissions'][$userRole]['canManageUsers'])));
        if ($userRole && !$allowed) {
            jsonOut(['success' => false, 'message' => 'Akses Ditolak: Role Anda tidak memiliki izin Kelola Pengguna & Hak Akses!'], 403);
        }
        $cleanUsername = !empty($body['username']) ? trim($body['username']) : ('user' . time());
        $existingIds = [];
        $maxNum = 0;
        foreach ($state['users'] as $eu) {
            if (!empty($eu['id'])) {
                $existingIds[$eu['id']] = true;
                if (preg_match('/^USR-(\d+)$/i', $eu['id'], $idm)) {
                    $num = intval($idm[1]);
                    if ($num > $maxNum) $maxNum = $num;
                }
            }
            if (!empty($eu['username']) && strtolower(trim($eu['username'])) === strtolower($cleanUsername)) {
                jsonOut(['success' => false, 'message' => "Username @{$cleanUsername} sudah digunakan! Gunakan username lain."], 400);
            }
        }
        $nextNum = max($maxNum + 1, count($state['users']) + 1);
        while (isset($existingIds['USR-' . str_pad(strval($nextNum), 3, '0', STR_PAD_LEFT)])) {
            $nextNum++;
        }
        $newId = 'USR-' . str_pad(strval($nextNum), 3, '0', STR_PAD_LEFT);
        $newUser = [
            'id' => $newId,
            'username' => $cleanUsername,
            'password' => !empty($body['password']) ? $body['password'] : 'password123',
            'nama' => !empty($body['nama']) ? $body['nama'] : 'User Baru',
            'email' => isset($body['email']) ? $body['email'] : '',
            'noTelp' => isset($body['noTelp']) ? $body['noTelp'] : '',
            'role' => !empty($body['role']) ? $body['role'] : 'CS',
            'active' => array_key_exists('active', $body) ? (bool)$body['active'] : true,
            'createdAt' => ErpHelpers::nowIso()
        ];
        if (isset($body['permissions'])) $newUser['permissions'] = $body['permissions'];
        if (isset($body['preferences'])) $newUser['preferences'] = $body['preferences'];
        $state['users'][] = $newUser;
        ErpHelpers::addLog($state, $newUser['id'], $newUser['nama'], 'CREATE_USER', "Menambahkan user baru: {$newUser['username']} ({$newUser['role']})");
        ErpStore::saveState($state);
        ErpStore::pushRealtimeEvent('users-updated', ['id' => $newId]);
        jsonOut(['success' => true, 'message' => 'User berhasil dibuat dan disimpan ke database!', 'user' => $newUser]);
    }

    if ($method === 'PUT' && preg_match('#^/api/users/([^/]+)/preferences$#', $path, $m)) {
        $uid = urldecode($m[1]);
        $prefs = isset($body['preferences']) && is_array($body['preferences']) ? $body['preferences'] : [];
        foreach ($state['users'] as &$u) {
            if ($u['id'] === $uid) {
                $existing = isset($u['preferences']) && is_array($u['preferences']) ? $u['preferences'] : [];
                $u['preferences'] = array_merge($existing, $prefs);
                ErpHelpers::addLog($state, $uid, $u['nama'], 'UPDATE_PREFERENCES', "Memperbarui preferensi dashboard user: {$u['username']}");
                ErpStore::saveState($state);
                jsonOut(['success' => true, 'message' => 'Preferensi dashboard berhasil disimpan!', 'user' => $u]);
            }
        }
        unset($u);
        jsonOut(['success' => false, 'message' => 'User tidak ditemukan!'], 404);
    }

    if ($method === 'PUT' && preg_match('#^/api/users/([^/]+)$#', $path, $m)) {
        $uid = urldecode($m[1]);
        $userRole = ErpHelpers::getHeader($headers, 'x-user-role') ?: (isset($body['userRole']) ? $body['userRole'] : '');
        $allowed = ($userRole === 'Super Admin' || $userRole === 'Koord' || (!empty($userRole) && !empty($state['rolePermissions'][$userRole]['canManageUsers'])));
        if ($userRole && !$allowed) {
            jsonOut(['success' => false, 'message' => 'Akses Ditolak: Role Anda tidak memiliki izin Kelola Pengguna & Hak Akses!'], 403);
        }
        if (isset($body['username'])) {
            $nextUname = trim($body['username']);
            foreach ($state['users'] as $eu) {
                if ($eu['id'] !== $uid && !empty($eu['username']) && strtolower(trim($eu['username'])) === strtolower($nextUname)) {
                    jsonOut(['success' => false, 'message' => "Username @{$nextUname} sudah dipakai oleh akun lain!"], 400);
                }
            }
        }
        foreach ($state['users'] as &$u) {
            if ($u['id'] === $uid) {
                if (isset($body['username'])) $u['username'] = trim($body['username']);
                if (!empty($body['password'])) $u['password'] = $body['password'];
                if (isset($body['nama'])) $u['nama'] = $body['nama'];
                if (isset($body['email'])) $u['email'] = $body['email'];
                if (isset($body['noTelp'])) $u['noTelp'] = $body['noTelp'];
                if (isset($body['role'])) $u['role'] = $body['role'];
                if (array_key_exists('active', $body)) $u['active'] = (bool)$body['active'];
                if (isset($body['permissions'])) $u['permissions'] = $body['permissions'];
                if (isset($body['preferences'])) $u['preferences'] = $body['preferences'];
                ErpHelpers::addLog($state, $uid, $u['nama'], 'UPDATE_USER', "Memperbarui akun user: {$u['username']} ({$u['role']})");
                ErpStore::saveState($state);
                ErpStore::pushRealtimeEvent('users-updated', ['id' => $uid]);
                jsonOut(['success' => true, 'message' => 'Data user berhasil diperbarui di database!', 'user' => $u]);
            }
        }
        unset($u);
        jsonOut(['success' => false, 'message' => 'User tidak ditemukan!'], 404);
    }

    if ($method === 'DELETE' && preg_match('#^/api/users/([^/]+)$#', $path, $m)) {
        $uid = urldecode($m[1]);
        $userRole = ErpHelpers::getHeader($headers, 'x-user-role') ?: (isset($body['userRole']) ? $body['userRole'] : '');
        if ($userRole && $userRole !== 'Super Admin') {
            jsonOut(['success' => false, 'message' => 'Akses Ditolak: Hanya Super Admin yang berhak menghapus akun pengguna & hak aksesnya!'], 403);
        }
        $targetUser = null;
        $filtered = [];
        foreach ($state['users'] as $u) {
            if ($u['id'] === $uid) $targetUser = $u;
            else $filtered[] = $u;
        }
        if (!$targetUser) jsonOut(['success' => false, 'message' => 'User tidak ditemukan!'], 404);
        $state['users'] = $filtered;
        $actorName = ErpHelpers::getHeader($headers, 'x-user-nama') ?: 'Super Admin';
        ErpHelpers::addLog($state, 'USR-000', $actorName, 'DELETE_USER', "Menghapus user: {$targetUser['username']} ({$targetUser['role']})");
        ErpStore::deleteUserFromMysql($uid, isset($targetUser['username']) ? $targetUser['username'] : null);
        ErpStore::saveState($state);
        ErpStore::pushRealtimeEvent('users-updated', ['id' => $uid]);
        jsonOut(['success' => true, 'message' => "User {$targetUser['username']} berhasil dihapus!", 'data' => $state['users']]);
    }

    // ========================================================
    // PERMISSIONS & COMPANY PROFILE
    // ========================================================
    if ($method === 'GET' && $path === '/api/settings/permissions') {
        jsonOut(['success' => true, 'data' => $state['rolePermissions']]);
    }

    if ($method === 'PUT' && $path === '/api/settings/permissions') {
        $userRole = ErpHelpers::getHeader($headers, 'x-user-role') ?: (isset($body['userRole']) ? $body['userRole'] : '');
        if ($userRole && $userRole !== 'Super Admin' && $userRole !== 'Koord') {
            jsonOut(['success' => false, 'message' => 'Akses Ditolak: Hanya Super Admin / Koordinator yang berhak menyimpan hak akses!'], 403);
        }
        if (is_array($body)) {
            $state['rolePermissions'] = array_merge($state['rolePermissions'], $body);
            $actorName = ErpHelpers::getHeader($headers, 'x-user-nama') ?: 'Super Admin';
            ErpHelpers::addLog($state, 'USR-000', $actorName, 'UPDATE_PERMISSIONS', 'Memperbarui konfigurasi matriks hak akses & role');
            ErpStore::saveState($state);
            ErpStore::pushRealtimeEvent('settings-updated', ['scope' => 'permissions']);
            jsonOut(['success' => true, 'message' => 'Konfigurasi hak akses berhasil disimpan!', 'data' => $state['rolePermissions']]);
        }
        jsonOut(['success' => false, 'message' => 'Format data hak akses tidak valid!'], 400);
    }

    if ($method === 'POST' && $path === '/api/settings/permissions/reset') {
        $seedFile = ErpStore::getRootDir() . '/seed_data.json';
        if (file_exists($seedFile)) {
            $seed = json_decode(@file_get_contents($seedFile), true);
            if (!empty($seed['rolePermissions'])) {
                $state['rolePermissions'] = $seed['rolePermissions'];
            }
        }
        $actorName = ErpHelpers::getHeader($headers, 'x-user-nama') ?: 'Super Admin';
        ErpHelpers::addLog($state, 'USR-000', $actorName, 'RESET_PERMISSIONS', 'Mereset konfigurasi hak akses ke default sistem');
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => 'Hak akses berhasil direset ke pengaturan bawaan!', 'data' => $state['rolePermissions']]);
    }

    if ($method === 'GET' && $path === '/api/settings/company-profile') {
        jsonOut(['success' => true, 'data' => $state['companyProfile']]);
    }

    if ($method === 'PUT' && $path === '/api/settings/company-profile') {
        if (is_array($body)) {
            $state['companyProfile'] = array_merge($state['companyProfile'], $body, ['updatedAt' => ErpHelpers::nowIso()]);
            $actorName = ErpHelpers::getHeader($headers, 'x-user-nama') ?: 'Super Admin';
            ErpHelpers::addLog($state, 'USR-000', $actorName, 'UPDATE_COMPANY_PROFILE', 'Memperbarui identitas perusahaan & aplikasi');
            ErpStore::saveState($state);
            ErpStore::pushRealtimeEvent('settings-updated', ['scope' => 'company']);
            jsonOut(['success' => true, 'message' => 'Identitas perusahaan & aplikasi berhasil disimpan!', 'data' => $state['companyProfile']]);
        }
        jsonOut(['success' => false, 'message' => 'Format data profil perusahaan tidak valid!'], 400);
    }

    if ($method === 'POST' && $path === '/api/settings/company-profile/reset') {
        $seedFile = ErpStore::getRootDir() . '/seed_data.json';
        if (file_exists($seedFile)) {
            $seed = json_decode(@file_get_contents($seedFile), true);
            if (!empty($seed['companyProfile'])) {
                $state['companyProfile'] = $seed['companyProfile'];
            }
        }
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => 'Identitas perusahaan berhasil direset ke bawaan!', 'data' => $state['companyProfile']]);
    }

    // ========================================================
    // PAPER & PRICE & MASTER MATERIALS SETTINGS
    // ========================================================
    if ($method === 'GET' && $path === '/api/settings/paper') {
        ErpHelpers::ensurePaperMaterialsSynced($state);
        jsonOut(['success' => true, 'data' => $state['paperSettings']]);
    }

    if ($method === 'POST' && $path === '/api/settings/paper/types') {
        if (!ErpHelpers::checkCanEditPrices($state, $headers, $body, $query)) {
            jsonOut(['success' => false, 'message' => 'Akses ditolak!'], 403);
        }
        $name = isset($body['name']) ? trim($body['name']) : '';
        if ($name !== '') {
            if (!in_array($name, $state['paperSettings']['types'])) $state['paperSettings']['types'][] = $name;
            $numPrice = isset($body['price']) ? floatval($body['price']) : 250000;
            $unitStr = !empty($body['unit']) ? $body['unit'] : 'roll';
            $desc = isset($body['description']) ? $body['description'] : '';
            $state['paperSettings']['typePrices'][$name] = $numPrice;
            $state['paperSettings']['typeUnits'][$name] = $unitStr;
            $state['paperSettings']['paperItems'][] = ['id' => 'pap-' . time(), 'name' => $name, 'price' => $numPrice, 'unit' => $unitStr, 'description' => $desc];
            $state['priceSettings']['papers'][] = ['id' => 'pap-' . time(), 'name' => $name, 'price' => $numPrice, 'unit' => $unitStr, 'description' => $desc];
            ErpHelpers::ensurePaperMaterialsSynced($state);
            ErpStore::saveState($state);
            ErpStore::pushRealtimeEvent('settings-updated', ['scope' => 'paper']);
        }
        jsonOut(['success' => true, 'data' => $state['paperSettings']]);
    }

    if ($method === 'PUT' && preg_match('#^/api/settings/paper/types/([^/]+)$#', $path, $m)) {
        if (!ErpHelpers::checkCanEditPrices($state, $headers, $body, $query)) {
            jsonOut(['success' => false, 'message' => 'Akses ditolak!'], 403);
        }
        $name = urldecode($m[1]);
        if (isset($body['price'])) $state['paperSettings']['typePrices'][$name] = floatval($body['price']);
        if (!empty($body['unit'])) $state['paperSettings']['typeUnits'][$name] = $body['unit'];
        foreach ($state['paperSettings']['paperItems'] as &$pi) {
            if (strtolower(trim($pi['name'])) === strtolower(trim($name))) {
                if (isset($body['price'])) $pi['price'] = floatval($body['price']);
                if (!empty($body['unit'])) $pi['unit'] = $body['unit'];
                if (isset($body['description'])) $pi['description'] = $body['description'];
            }
        }
        unset($pi);
        foreach ($state['priceSettings']['papers'] as &$pi) {
            if (strtolower(trim($pi['name'])) === strtolower(trim($name))) {
                if (isset($body['price'])) $pi['price'] = floatval($body['price']);
                if (!empty($body['unit'])) $pi['unit'] = $body['unit'];
            }
        }
        unset($pi);
        if (isset($body['price'])) {
            $numP = floatval($body['price']);
            foreach ($state['materials'] as &$mat) {
                if (isset($mat['Kategori']) && $mat['Kategori'] === 'Paper' &&
                    ((isset($mat['TipePaper']) && strtolower(trim($mat['TipePaper'])) === strtolower(trim($name))) || stripos($mat['NamaMaterial'], $name) !== false)) {
                    $mat['Harga'] = $numP;
                }
            }
            unset($mat);
        }
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'data' => $state['paperSettings']]);
    }

    if ($method === 'DELETE' && preg_match('#^/api/settings/paper/types/([^/]+)$#', $path, $m)) {
        if (!ErpHelpers::checkCanEditPrices($state, $headers, $body, $query)) {
            jsonOut(['success' => false, 'message' => 'Akses ditolak!'], 403);
        }
        $name = urldecode($m[1]);
        $state['paperSettings']['types'] = array_values(array_filter($state['paperSettings']['types'], function($t) use ($name) { return $t !== $name; }));
        unset($state['paperSettings']['typePrices'][$name], $state['paperSettings']['typeUnits'][$name]);
        $state['paperSettings']['paperItems'] = array_values(array_filter($state['paperSettings']['paperItems'], function($p) use ($name) { return $p['name'] !== $name; }));
        $state['priceSettings']['papers'] = array_values(array_filter($state['priceSettings']['papers'], function($p) use ($name) { return $p['name'] !== $name; }));
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'data' => $state['paperSettings']]);
    }

    if ($method === 'POST' && $path === '/api/settings/paper/widths') {
        if (!ErpHelpers::checkCanEditPrices($state, $headers, $body, $query)) jsonOut(['success' => false, 'message' => 'Akses ditolak!'], 403);
        $name = isset($body['name']) ? trim($body['name']) : '';
        if ($name !== '' && !in_array($name, $state['paperSettings']['widths'])) {
            $state['paperSettings']['widths'][] = $name;
            ErpHelpers::ensurePaperMaterialsSynced($state);
            ErpStore::saveState($state);
        }
        jsonOut(['success' => true, 'data' => $state['paperSettings']]);
    }

    if ($method === 'DELETE' && preg_match('#^/api/settings/paper/widths/([^/]+)$#', $path, $m)) {
        if (!ErpHelpers::checkCanEditPrices($state, $headers, $body, $query)) jsonOut(['success' => false, 'message' => 'Akses ditolak!'], 403);
        $name = urldecode($m[1]);
        $state['paperSettings']['widths'] = array_values(array_filter($state['paperSettings']['widths'], function($w) use ($name) { return $w !== $name; }));
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'data' => $state['paperSettings']]);
    }

    if ($method === 'POST' && $path === '/api/settings/paper/combined') {
        if (!ErpHelpers::checkCanEditPrices($state, $headers, $body, $query)) jsonOut(['success' => false, 'message' => 'Akses ditolak!'], 403);
        $type = isset($body['type']) ? trim($body['type']) : '';
        $width = isset($body['width']) ? trim($body['width']) : '';
        if (!$type || !$width) jsonOut(['success' => false, 'message' => 'Tipe kertas dan ukuran lebar wajib diisi!'], 400);

        $numRollCount = max(0, floatval(isset($body['rollCount']) ? $body['rollCount'] : 0));
        $numMeterPerRoll = max(10, floatval(isset($body['meterPerRoll']) ? $body['meterPerRoll'] : 100));
        $numPrice = max(0, floatval(isset($body['price']) ? $body['price'] : 250000));
        $desc = isset($body['description']) ? $body['description'] : "Lebar {$width}, {$numMeterPerRoll}m/roll";

        if (!in_array($type, $state['paperSettings']['types'])) $state['paperSettings']['types'][] = $type;
        if (!in_array($width, $state['paperSettings']['widths'])) $state['paperSettings']['widths'][] = $width;
        $state['paperSettings']['typePrices'][$type] = $numPrice;
        $state['paperSettings']['typeUnits'][$type] = 'roll';

        $paperNameFull = 'Kertas Sublim ' . $type . ' ' . preg_replace('/\s+/', '', $width);
        $foundP = false;
        foreach ($state['priceSettings']['papers'] as &$p) {
            if (strtolower(trim($p['name'])) === strtolower($paperNameFull) || strtolower(trim($p['name'])) === strtolower($type)) {
                $p['price'] = $numPrice; $p['unit'] = 'roll'; $foundP = true;
            }
        }
        unset($p);
        if (!$foundP) {
            $state['priceSettings']['papers'][] = ['id' => 'pap-' . time(), 'name' => $paperNameFull, 'price' => $numPrice, 'unit' => 'roll', 'description' => $desc];
        }

        $cleanDigits = preg_replace('/[^0-9]/', '', $width);
        $foundMatIdx = -1;
        foreach ($state['materials'] as $idx => $mat) {
            if (isset($mat['Kategori']) && $mat['Kategori'] === 'Paper' && stripos($mat['NamaMaterial'], 'protection') === false) {
                $matchT = (isset($mat['TipePaper']) && strtolower(trim($mat['TipePaper'])) === strtolower($type)) || stripos($mat['NamaMaterial'], $type) !== false;
                $matchW = ($cleanDigits && ((isset($mat['LebarPaper']) && strpos($mat['LebarPaper'], $cleanDigits) !== false) || strpos($mat['NamaMaterial'], $cleanDigits) !== false));
                if ($matchT && $matchW) { $foundMatIdx = $idx; break; }
            }
        }

        if ($foundMatIdx !== -1) {
            $state['materials'][$foundMatIdx]['NamaMaterial'] = $paperNameFull;
            $state['materials'][$foundMatIdx]['TipePaper'] = $type;
            $state['materials'][$foundMatIdx]['LebarPaper'] = $width;
            $state['materials'][$foundMatIdx]['Harga'] = $numPrice;
            $state['materials'][$foundMatIdx]['MeterPerRoll'] = $numMeterPerRoll;
            if (isset($body['rollCount'])) {
                $state['materials'][$foundMatIdx]['Stok'] = $numRollCount;
                $state['materials'][$foundMatIdx]['RollCount'] = $numRollCount;
            }
        } else {
            $state['materials'][] = [
                'ID' => ErpHelpers::generateNextMaterialId($state['materials']),
                'NamaMaterial' => $paperNameFull,
                'Satuan' => 'roll',
                'Stok' => $numRollCount,
                'MinStok' => 4,
                'Harga' => $numPrice,
                'Kategori' => 'Paper',
                'MeterPerRoll' => $numMeterPerRoll,
                'LebarPaper' => $width,
                'TipePaper' => $type,
                'RollCount' => $numRollCount
            ];
        }

        ErpStore::saveState($state);
        ErpStore::pushRealtimeEvent('materials-updated', ['scope' => 'paper']);
        $paperMats = array_values(array_filter($state['materials'], function($m) { return isset($m['Kategori']) && $m['Kategori'] === 'Paper'; }));
        jsonOut(['success' => true, 'message' => "Kertas sublimasi '{$paperNameFull}' berhasil dikombinasikan!", 'data' => ['paperSettings' => $state['paperSettings'], 'materials' => $paperMats]]);
    }

    if ($method === 'PUT' && preg_match('#^/api/settings/paper/combined/([^/]+)$#', $path, $m)) {
        if (!ErpHelpers::checkCanEditPrices($state, $headers, $body, $query)) jsonOut(['success' => false, 'message' => 'Akses ditolak!'], 403);
        $matId = urldecode($m[1]);
        foreach ($state['materials'] as &$mat) {
            if ($mat['ID'] === $matId) {
                if (isset($body['rollCount'])) { $mat['Stok'] = max(0, floatval($body['rollCount'])); $mat['RollCount'] = $mat['Stok']; }
                if (isset($body['price'])) $mat['Harga'] = max(0, floatval($body['price']));
                if (isset($body['meterPerRoll'])) $mat['MeterPerRoll'] = max(10, floatval($body['meterPerRoll']));
                if (!empty($body['lebarPaper'])) {
                    $mat['LebarPaper'] = $body['lebarPaper'];
                    if (!in_array($body['lebarPaper'], $state['paperSettings']['widths'])) $state['paperSettings']['widths'][] = $body['lebarPaper'];
                }
                if (!empty($body['tipePaper'])) {
                    $mat['TipePaper'] = $body['tipePaper'];
                    if (!in_array($body['tipePaper'], $state['paperSettings']['types'])) $state['paperSettings']['types'][] = $body['tipePaper'];
                }
                ErpStore::saveState($state);
                ErpStore::pushRealtimeEvent('materials-updated', ['id' => $matId]);
                jsonOut(['success' => true, 'message' => 'Data kertas berhasil diperbarui!', 'data' => $mat]);
            }
        }
        unset($mat);
        jsonOut(['success' => false, 'message' => 'Material kertas tidak ditemukan!'], 404);
    }

    // Price & Rates
    if ($method === 'GET' && $path === '/api/settings/prices') {
        jsonOut(['success' => true, 'data' => $state['priceSettings']]);
    }

    if ($method === 'POST' && $path === '/api/settings/prices/fabrics') {
        if (!ErpHelpers::checkCanEditPrices($state, $headers, $body, $query)) jsonOut(['success' => false, 'message' => 'Akses ditolak!'], 403);
        $name = isset($body['name']) ? trim($body['name']) : '';
        if (!$name || !isset($body['price'])) jsonOut(['success' => false, 'message' => 'Nama dan harga bahan harus diisi.'], 400);
        $newFab = ['id' => 'fab-' . time(), 'name' => $name, 'price' => floatval($body['price']), 'unit' => !empty($body['unit']) ? $body['unit'] : 'Kg'];
        $state['priceSettings']['fabrics'][] = $newFab;
        $exists = false;
        foreach ($state['materials'] as $mat) { if (strtolower($mat['NamaMaterial']) === strtolower($name)) { $exists = true; break; } }
        if (!$exists) {
            $state['materials'][] = ['ID' => ErpHelpers::generateNextMaterialId($state['materials']), 'NamaMaterial' => $name, 'Satuan' => $newFab['unit'], 'Stok' => 100, 'MinStok' => 20, 'Harga' => $newFab['price'], 'Kategori' => 'Fabric'];
        }
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'data' => $state['priceSettings']]);
    }

    if ($method === 'PUT' && preg_match('#^/api/settings/prices/fabrics/([^/]+)$#', $path, $m)) {
        if (!ErpHelpers::checkCanEditPrices($state, $headers, $body, $query)) jsonOut(['success' => false, 'message' => 'Akses ditolak!'], 403);
        $id = urldecode($m[1]);
        foreach ($state['priceSettings']['fabrics'] as &$f) {
            if ($f['id'] === $id) {
                $oldName = $f['name'];
                if (!empty($body['name'])) $f['name'] = trim($body['name']);
                if (isset($body['price'])) $f['price'] = floatval($body['price']);
                if (!empty($body['unit'])) $f['unit'] = $body['unit'];
                foreach ($state['materials'] as &$mat) {
                    if (strtolower($mat['NamaMaterial']) === strtolower($oldName)) {
                        $mat['NamaMaterial'] = $f['name']; $mat['Harga'] = $f['price']; $mat['Satuan'] = $f['unit'];
                    }
                }
                unset($mat);
                ErpStore::saveState($state);
                jsonOut(['success' => true, 'data' => $state['priceSettings']]);
            }
        }
        unset($f);
        jsonOut(['success' => false, 'message' => 'Bahan kain tidak ditemukan.'], 404);
    }

    if ($method === 'DELETE' && preg_match('#^/api/settings/prices/fabrics/([^/]+)$#', $path, $m)) {
        if (!ErpHelpers::checkCanEditPrices($state, $headers, $body, $query)) jsonOut(['success' => false, 'message' => 'Akses ditolak!'], 403);
        $id = urldecode($m[1]);
        $state['priceSettings']['fabrics'] = array_values(array_filter($state['priceSettings']['fabrics'], function($f) use ($id) { return $f['id'] !== $id; }));
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'data' => $state['priceSettings']]);
    }

    if ($method === 'POST' && $path === '/api/settings/prices/papers') {
        if (!ErpHelpers::checkCanEditPrices($state, $headers, $body, $query)) jsonOut(['success' => false, 'message' => 'Akses ditolak!'], 403);
        $name = isset($body['name']) ? trim($body['name']) : '';
        if (!$name || !isset($body['price'])) jsonOut(['success' => false, 'message' => 'Nama dan harga paper harus diisi.'], 400);
        $p = ['id' => 'pap-' . time(), 'name' => $name, 'price' => floatval($body['price']), 'unit' => !empty($body['unit']) ? $body['unit'] : 'roll', 'description' => isset($body['description']) ? $body['description'] : ''];
        $state['priceSettings']['papers'][] = $p;
        if (!in_array($name, $state['paperSettings']['types'])) $state['paperSettings']['types'][] = $name;
        $state['paperSettings']['typePrices'][$name] = $p['price'];
        $state['paperSettings']['typeUnits'][$name] = $p['unit'];
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'data' => $state['priceSettings']]);
    }

    if ($method === 'PUT' && preg_match('#^/api/settings/prices/papers/([^/]+)$#', $path, $m)) {
        if (!ErpHelpers::checkCanEditPrices($state, $headers, $body, $query)) jsonOut(['success' => false, 'message' => 'Akses ditolak!'], 403);
        $id = urldecode($m[1]);
        foreach ($state['priceSettings']['papers'] as &$p) {
            if ($p['id'] === $id) {
                if (!empty($body['name'])) $p['name'] = trim($body['name']);
                if (isset($body['price'])) $p['price'] = floatval($body['price']);
                if (!empty($body['unit'])) $p['unit'] = $body['unit'];
                if (isset($body['description'])) $p['description'] = $body['description'];
                ErpStore::saveState($state);
                jsonOut(['success' => true, 'data' => $state['priceSettings']]);
            }
        }
        unset($p);
        jsonOut(['success' => false, 'message' => 'Jenis paper tidak ditemukan.'], 404);
    }

    if ($method === 'DELETE' && preg_match('#^/api/settings/prices/papers/([^/]+)$#', $path, $m)) {
        if (!ErpHelpers::checkCanEditPrices($state, $headers, $body, $query)) jsonOut(['success' => false, 'message' => 'Akses ditolak!'], 403);
        $id = urldecode($m[1]);
        $state['priceSettings']['papers'] = array_values(array_filter($state['priceSettings']['papers'], function($p) use ($id) { return $p['id'] !== $id; }));
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'data' => $state['priceSettings']]);
    }

    if ($method === 'GET' && $path === '/api/settings/prices/rates') {
        jsonOut(['success' => true, 'data' => $state['priceSettings']]);
    }

    if ($method === 'PUT' && $path === '/api/settings/prices/rates') {
        if (!ErpHelpers::checkCanEditPrices($state, $headers, $body, $query)) jsonOut(['success' => false, 'message' => 'Akses ditolak!'], 403);
        foreach (['pressRate', 'cuttingRate', 'printRate', 'sewingRate', 'packingRate'] as $rk) {
            if (isset($body[$rk])) $state['priceSettings'][$rk] = floatval($body[$rk]);
        }
        if (isset($body['serviceRateDetails']) && is_array($body['serviceRateDetails'])) {
            $state['priceSettings']['serviceRateDetails'] = $body['serviceRateDetails'];
        }
        $actorName = ErpHelpers::getHeader($headers, 'x-user-nama') ?: 'Staff';
        ErpHelpers::addLog($state, 'USR-PRICE', $actorName, 'UPDATE_SERVICE_RATES', 'Memperbarui tarif jasa pengerjaan');
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => 'Tarif jasa berhasil diperbarui!', 'data' => $state['priceSettings']]);
    }

    if ($method === 'POST' && $path === '/api/settings/prices/rates/reset') {
        if (!ErpHelpers::checkCanEditPrices($state, $headers, $body, $query)) jsonOut(['success' => false, 'message' => 'Akses ditolak!'], 403);
        $state['priceSettings']['printRate'] = 25000;
        $state['priceSettings']['pressRate'] = 15000;
        $state['priceSettings']['cuttingRate'] = 5000;
        $state['priceSettings']['sewingRate'] = 12000;
        $state['priceSettings']['packingRate'] = 2000;
        unset($state['priceSettings']['serviceRateDetails']);
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => 'Tarif jasa berhasil dikembalikan ke standar awal pabrik!', 'data' => $state['priceSettings']]);
    }

    // Master Materials
    if ($method === 'GET' && $path === '/api/master-materials') {
        $ps = $state['priceSettings'];
        $mats = $state['materials'];
        $all = [];
        $findMat = function($name, $cat = null) use ($mats) {
            foreach ($mats as $m) {
                if (strtolower(trim($m['NamaMaterial'])) === strtolower(trim($name))) return $m;
                if ($cat && isset($m['Kategori']) && $m['Kategori'] === $cat && stripos($m['NamaMaterial'], $name) !== false) return $m;
            }
            return null;
        };
        foreach ((isset($ps['fabrics']) ? $ps['fabrics'] : []) as $f) {
            $mm = $findMat($f['name'], 'Fabric');
            $all[] = ['id' => $f['id'], 'name' => $f['name'], 'category' => 'Fabric', 'price' => $f['price'], 'unit' => isset($f['unit']) ? $f['unit'] : 'Kg', 'description' => 'Bahan kain sublimasi workshop', 'isRegisteredInWarehouse' => (bool)$mm, 'warehouseSKU' => $mm ? $mm['ID'] : null, 'warehouseStock' => $mm ? $mm['Stok'] : null, 'warehouseUnit' => $mm ? $mm['Satuan'] : null];
        }
        foreach ((isset($ps['papers']) ? $ps['papers'] : []) as $p) {
            $mm = $findMat($p['name'], 'Paper');
            $w = !empty($p['width']) ? $p['width'] : (preg_match('/(\d+\s*cm)/i', $p['name'], $wm) ? $wm[1] : '160 cm');
            $pt = !empty($p['type']) ? $p['type'] : (stripos($p['name'], 'fastdry') !== false ? 'Fastdry' : 'Sticky');
            $all[] = ['id' => $p['id'], 'name' => $p['name'], 'category' => 'Paper', 'price' => $p['price'], 'unit' => isset($p['unit']) ? $p['unit'] : 'roll', 'description' => isset($p['description']) ? $p['description'] : 'Kertas transfer sublimasi roll', 'width' => $w, 'paperType' => $pt, 'recommendation' => isset($p['recommendation']) ? $p['recommendation'] : '', 'isRegisteredInWarehouse' => (bool)$mm, 'warehouseSKU' => $mm ? $mm['ID'] : null, 'warehouseStock' => $mm ? $mm['Stok'] : null, 'warehouseUnit' => $mm ? $mm['Satuan'] : null];
        }
        foreach ((isset($ps['inks']) ? $ps['inks'] : []) as $i) {
            $mm = $findMat($i['name'], 'Ink');
            $all[] = ['id' => $i['id'], 'name' => $i['name'], 'category' => 'Ink', 'price' => $i['price'], 'unit' => isset($i['unit']) ? $i['unit'] : 'botol', 'description' => isset($i['description']) ? $i['description'] : 'Tinta sublimasi CMYK', 'isRegisteredInWarehouse' => (bool)$mm, 'warehouseSKU' => $mm ? $mm['ID'] : null, 'warehouseStock' => $mm ? $mm['Stok'] : null, 'warehouseUnit' => $mm ? $mm['Satuan'] : null];
        }
        foreach ((isset($ps['accessories']) ? $ps['accessories'] : []) as $a) {
            $mm = $findMat($a['name']);
            $cat = stripos($a['name'], 'benang') !== false ? 'Thread' : (stripos($a['name'], 'rib') !== false ? 'Rib' : 'Other');
            $all[] = ['id' => $a['id'], 'name' => $a['name'], 'category' => $cat, 'price' => $a['price'], 'unit' => isset($a['unit']) ? $a['unit'] : 'pcs', 'description' => isset($a['description']) ? $a['description'] : 'Aksesoris jahit', 'isRegisteredInWarehouse' => (bool)$mm, 'warehouseSKU' => $mm ? $mm['ID'] : null, 'warehouseStock' => $mm ? $mm['Stok'] : null, 'warehouseUnit' => $mm ? $mm['Satuan'] : null];
        }
        foreach ($mats as $m) {
            $found = false;
            foreach ($all as $it) { if (strtolower(trim($it['name'])) === strtolower(trim($m['NamaMaterial']))) { $found = true; break; } }
            if (!$found) {
                $cat = isset($m['Kategori']) ? $m['Kategori'] : 'Other';
                $all[] = ['id' => 'mat-' . $m['ID'], 'name' => $m['NamaMaterial'], 'category' => $cat, 'price' => isset($m['Harga']) ? $m['Harga'] : 0, 'unit' => isset($m['Satuan']) ? $m['Satuan'] : 'pcs', 'description' => "Material gudang ({$m['ID']})", 'isRegisteredInWarehouse' => true, 'warehouseSKU' => $m['ID'], 'warehouseStock' => $m['Stok'], 'warehouseUnit' => $m['Satuan']];
            }
        }
        jsonOut(['success' => true, 'data' => ['fabrics' => isset($ps['fabrics']) ? $ps['fabrics'] : [], 'papers' => isset($ps['papers']) ? $ps['papers'] : [], 'inks' => isset($ps['inks']) ? $ps['inks'] : [], 'accessories' => isset($ps['accessories']) ? $ps['accessories'] : [], 'all' => $all]]);
    }

    if ($method === 'POST' && $path === '/api/master-materials') {
        if (!ErpHelpers::checkCanEditPrices($state, $headers, $body, $query)) jsonOut(['success' => false, 'message' => 'Akses ditolak!'], 403);
        $name = isset($body['name']) ? trim($body['name']) : '';
        if (!$name || !isset($body['price'])) jsonOut(['success' => false, 'message' => 'Nama dan harga wajib diisi.'], 400);
        $cat = !empty($body['category']) ? $body['category'] : 'Fabric';
        $numPrice = floatval($body['price']);
        $itemId = 'mat-' . base_convert(strval(time()), 10, 36) . '-' . substr(md5(mt_rand()), 0, 4);
        if ($cat === 'Fabric') {
            $state['priceSettings']['fabrics'][] = ['id' => $itemId, 'name' => $name, 'price' => $numPrice, 'unit' => !empty($body['unit']) ? $body['unit'] : 'Kg'];
        } elseif ($cat === 'Paper') {
            $state['priceSettings']['papers'][] = ['id' => $itemId, 'name' => $name, 'price' => $numPrice, 'unit' => !empty($body['unit']) ? $body['unit'] : 'roll', 'description' => isset($body['description']) ? $body['description'] : '', 'width' => isset($body['width']) ? $body['width'] : '160 cm', 'type' => isset($body['paperType']) ? $body['paperType'] : 'Sticky'];
        } elseif ($cat === 'Ink') {
            $state['priceSettings']['inks'][] = ['id' => $itemId, 'name' => $name, 'price' => $numPrice, 'unit' => !empty($body['unit']) ? $body['unit'] : 'botol', 'description' => isset($body['description']) ? $body['description'] : 'Tinta sublimasi'];
        } else {
            $state['priceSettings']['accessories'][] = ['id' => $itemId, 'name' => $name, 'price' => $numPrice, 'unit' => !empty($body['unit']) ? $body['unit'] : 'pcs', 'description' => isset($body['description']) ? $body['description'] : 'Aksesoris'];
        }
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => "Master bahan '{$name}' berhasil didaftarkan!", 'id' => $itemId]);
    }

    if ($method === 'PUT' && preg_match('#^/api/master-materials/([^/]+)$#', $path, $m)) {
        if (!ErpHelpers::checkCanEditPrices($state, $headers, $body, $query)) jsonOut(['success' => false, 'message' => 'Akses ditolak!'], 403);
        $id = urldecode($m[1]);
        $rawId = preg_replace('/^mat-/', '', $id);
        $found = false;
        foreach (['fabrics', 'papers', 'inks', 'accessories'] as $group) {
            if (!empty($state['priceSettings'][$group])) {
                foreach ($state['priceSettings'][$group] as &$it) {
                    if ($it['id'] === $id || $it['id'] === $rawId) {
                        if (!empty($body['name'])) $it['name'] = trim($body['name']);
                        if (isset($body['price'])) $it['price'] = floatval($body['price']);
                        if (!empty($body['unit'])) $it['unit'] = $body['unit'];
                        if (isset($body['description'])) $it['description'] = $body['description'];
                        $found = true;
                    }
                }
                unset($it);
            }
        }
        foreach ($state['materials'] as &$mat) {
            if ($mat['ID'] === $rawId || $mat['ID'] === $id) {
                if (!empty($body['name'])) $mat['NamaMaterial'] = trim($body['name']);
                if (isset($body['price'])) $mat['Harga'] = floatval($body['price']);
                if (!empty($body['unit'])) $mat['Satuan'] = $body['unit'];
                $found = true;
            }
        }
        unset($mat);
        if (!$found) jsonOut(['success' => false, 'message' => 'Item master bahan tidak ditemukan.'], 404);
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => 'Master bahan berhasil diperbarui!']);
    }

    if ($method === 'DELETE' && preg_match('#^/api/master-materials/([^/]+)$#', $path, $m)) {
        if (!ErpHelpers::checkCanEditPrices($state, $headers, $body, $query)) jsonOut(['success' => false, 'message' => 'Akses ditolak!'], 403);
        $id = urldecode($m[1]);
        $rawId = preg_replace('/^mat-/', '', $id);
        $delName = '';
        $newMats = [];
        foreach ($state['materials'] as $mat) {
            if ($mat['ID'] === $rawId || $mat['ID'] === $id) {
                $delName = $mat['NamaMaterial'];
                $state['deletedMaterialIds'][] = $mat['ID'];
            } else {
                $newMats[] = $mat;
            }
        }
        $state['materials'] = $newMats;
        foreach (['fabrics', 'papers', 'inks', 'accessories'] as $group) {
            if (!empty($state['priceSettings'][$group])) {
                $state['priceSettings'][$group] = array_values(array_filter($state['priceSettings'][$group], function($it) use ($id, $rawId, &$delName) {
                    if ($it['id'] === $id || $it['id'] === $rawId) {
                        if (!$delName) $delName = $it['name'];
                        return false;
                    }
                    return true;
                }));
            }
        }
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => "Master bahan '{$delName}' berhasil dihapus dari katalog."]);
    }

    // ========================================================
    // ORDERS & REPRINT & QC-ACTION
    // ========================================================
    if ($method === 'GET' && $path === '/api/orders') {
        foreach ($state['orders'] as &$o) {
            $o['TahapanPekerjaan'] = ErpHelpers::getOrderActiveStages($o);
        }
        unset($o);
        jsonOut(['success' => true, 'data' => $state['orders']]);
    }

    if ($method === 'GET' && preg_match('#^/api/orders/([^/]+)$#', $path, $m)) {
        $oid = urldecode($m[1]);
        foreach ($state['orders'] as $o) {
            if ($o['ID'] === $oid) jsonOut(['success' => true, 'data' => $o]);
        }
        jsonOut(['success' => false, 'message' => 'Order tidak ditemukan!'], 404);
    }

    if ($method === 'POST' && $path === '/api/orders') {
        $dateStr = date('Ymd');
        $randSuf = strval(mt_rand(1000, 9999));
        $orderId = "ORD-{$dateStr}-{$randSuf}";
        $daftarBarang = (!empty($body['DaftarBarang']) && is_array($body['DaftarBarang'])) ? $body['DaftarBarang'] : [];
        $totalBarang = 0;
        if (!empty($daftarBarang)) {
            foreach ($daftarBarang as $dbItem) $totalBarang += floatval(isset($dbItem['jumlah']) ? $dbItem['jumlah'] : 0);
        } else {
            $totalBarang = floatval(isset($body['TotalBarang']) ? $body['TotalBarang'] : 0);
        }

        $isDiambil = (isset($body['PengirimanMetode']) && $body['PengirimanMetode'] === 'Diambil ke Workshop');
        $pengirimanMetode = $isDiambil ? 'Diambil ke Workshop' : (!empty($body['PengirimanMetode']) ? $body['PengirimanMetode'] : 'Diambil ke Workshop');
        $courierName = $isDiambil ? 'Ambil di Workshop' : (!empty($body['CourierName']) ? $body['CourierName'] : 'J&T Express');
        $courierTrack = $isDiambil ? '' : (isset($body['CourierTrackingNo']) ? $body['CourierTrackingNo'] : '');
        $courierStatus = $isDiambil ? 'Siap Diambil di Workshop' : (!empty($body['CourierStatus']) ? $body['CourierStatus'] : ($courierTrack ? 'Resi Telah Dibuat' : 'Dalam Antrian Penjemputan'));
        $alamat = $isDiambil ? '' : (isset($body['AlamatPengiriman']) ? $body['AlamatPengiriman'] : '');

        $initialMeter = floatval(isset($body['MeterPrint']) ? $body['MeterPrint'] : (isset($body['LayoutPanjangPrint']) ? $body['LayoutPanjangPrint'] : 0));
        $initialWidth = !empty($body['LayoutLebarKertas']) ? $body['LayoutLebarKertas'] : (!empty($body['PaperSize']) ? $body['PaperSize'] : '160 cm');
        $initialPaperType = !empty($body['LayoutPaperType']) ? $body['LayoutPaperType'] : (!empty($body['PaperType']) ? $body['PaperType'] : 'Sticky');
        $jenisOrder = !empty($body['JenisOrder']) ? $body['JenisOrder'] : 'Full Order';
        $colorProfile = !empty($body['ColorProfile']) ? $body['ColorProfile'] : 'CMYK 300 DPI';
        $isTest = stripos($colorProfile, 'test') !== false;

        if (!empty($body['TahapanPekerjaan']) && is_array($body['TahapanPekerjaan'])) {
            $stages = $body['TahapanPekerjaan'];
        } else {
            if ($jenisOrder === 'Print Saja') $stages = ['Print', 'QC'];
            elseif ($jenisOrder === 'Press Saja') $stages = ['Press', 'QC'];
            elseif ($jenisOrder === 'Print & Press') $stages = ['Print', 'Press', 'QC'];
            else $stages = ['Print', 'Press', 'Cutting', 'Jahit', 'QC', 'Packing'];
        }
        if (!in_array('QC', $stages)) $stages[] = 'QC';

        $matType = !empty($body['MaterialType']) ? $body['MaterialType'] : 'Kain Dryfit Titik';
        $matNote = isset($body['MaterialTypeNote']) ? $body['MaterialTypeNote'] : '';
        $isBawa = (stripos($matType, 'bawa bahan') !== false || stripos($matNote, 'bawa bahan') !== false || (isset($body['FabricOption']) && $body['FabricOption'] === 'Bawa Bahan'));
        $fabricOpt = $isBawa ? 'Bawa Bahan' : 'Beli Bahan';
        $matPress = $isBawa ? ($matNote ?: ($matType ?: 'Bawa Bahan Sendiri')) : ($matType === 'Lainnya / Custom (Sebutkan)' ? ($matNote ?: 'Bahan Custom') : $matType);
        $fabPrice = 85000;
        if ($isBawa) {
            $fabPrice = 0;
        } else {
            foreach ($state['priceSettings']['fabrics'] as $f) {
                if (strtolower($f['name']) === strtolower($matPress)) { $fabPrice = floatval($f['price']); break; }
            }
        }

        $nowIso = ErpHelpers::nowIso();
        $newOrder = [
            'ID' => $orderId,
            'TanggalOrder' => $nowIso,
            'NamaKonsumen' => !empty($body['NamaKonsumen']) ? $body['NamaKonsumen'] : 'Tanpa Nama',
            'NamaFile' => !empty($body['NamaFile']) ? $body['NamaFile'] : 'file.pdf',
            'JenisOrder' => $jenisOrder,
            'Kriteria' => !empty($body['Kriteria']) ? $body['Kriteria'] : 'Normal',
            'Deadline' => !empty($body['Deadline']) ? $body['Deadline'] : gmdate('Y-m-d\TH:i:s.000\Z', time() + 86400 * 2),
            'NoTelpKonsumen' => isset($body['NoTelpKonsumen']) ? $body['NoTelpKonsumen'] : '',
            'EmailKonsumen' => isset($body['EmailKonsumen']) ? $body['EmailKonsumen'] : '',
            'Status' => !empty($body['Status']) ? $body['Status'] : 'Pending',
            'Notes' => isset($body['Notes']) ? $body['Notes'] : '',
            'CreatedBy' => !empty($body['CreatedBy']) ? $body['CreatedBy'] : 'CS',
            'CreatedAt' => $nowIso,
            'PriceTotal' => floatval(isset($body['PriceTotal']) ? $body['PriceTotal'] : 0),
            'PengirimanMetode' => $pengirimanMetode,
            'AlamatPengiriman' => $alamat,
            'CourierName' => $courierName,
            'CourierTrackingNo' => $courierTrack,
            'CourierStatus' => $courierStatus,
            'MeterPrint' => $initialMeter,
            'LayoutPanjangPrint' => $initialMeter,
            'PaperSize' => $initialWidth,
            'LayoutLebarKertas' => $initialWidth,
            'PaperType' => $initialPaperType,
            'LayoutPaperType' => $initialPaperType,
            'MaterialType' => $matType,
            'MaterialTypeNote' => $matNote,
            'FabricOption' => $fabricOpt,
            'FabricPrice' => $fabPrice,
            'MaterialPress' => $matPress,
            'QtyMaterial' => 0,
            'MainColor' => !empty($body['MainColor']) ? $body['MainColor'] : 'Full Color',
            'ColorProfile' => $colorProfile,
            'VerifiedColorProfile' => $isTest ? null : (!empty($body['VerifiedColorProfile']) ? $body['VerifiedColorProfile'] : (stripos($colorProfile, 'rgb') !== false ? 'RGB' : 'CMYK')),
            'TestPrintStatus' => $isTest ? (!empty($body['TestPrintStatus']) ? $body['TestPrintStatus'] : 'Menunggu Uji') : (!empty($body['TestPrintStatus']) ? $body['TestPrintStatus'] : 'Warna sudah ACC'),
            'TestPrintNotes' => isset($body['TestPrintNotes']) ? $body['TestPrintNotes'] : ($isTest ? 'Wajib uji cetak fisik sampel warna sebelum proses print massal' : 'Otomatis di-ACC'),
            'MockupFront' => isset($body['MockupFront']) ? $body['MockupFront'] : '',
            'MockupBack' => isset($body['MockupBack']) ? $body['MockupBack'] : '',
            'MockupLeft' => isset($body['MockupLeft']) ? $body['MockupLeft'] : '',
            'MockupRight' => isset($body['MockupRight']) ? $body['MockupRight'] : '',
            'DaftarBarang' => $daftarBarang,
            'TotalBarang' => $totalBarang,
            'TahapanPekerjaan' => $stages
        ];
        array_unshift($state['orders'], $newOrder);

        $spkId = "SPK-{$dateStr}-{$randSuf}";
        $newSPK = [
            'ID' => $spkId,
            'OrderID' => $orderId,
            'NamaKonsumen' => $newOrder['NamaKonsumen'],
            'NamaFile' => $newOrder['NamaFile'],
            'JenisOrder' => $jenisOrder,
            'TahapanPekerjaan' => $stages,
            'Deadline' => $newOrder['Deadline'],
            'Kriteria' => $newOrder['Kriteria'],
            'PengirimanMetode' => $pengirimanMetode,
            'CourierName' => $courierName,
            'CourierTrackingNo' => $courierTrack,
            'StatusPrint' => 'Pending',
            'MeterPrint' => $initialMeter,
            'LayoutPanjangPrint' => $initialMeter,
            'PaperSize' => $initialWidth,
            'LayoutLebarKertas' => $initialWidth,
            'PaperType' => $initialPaperType,
            'LayoutPaperType' => $initialPaperType,
            'StatusPress' => 'Pending',
            'FabricOption' => $fabricOpt,
            'FabricPrice' => $fabPrice,
            'MaterialPress' => $matPress,
            'QtyMaterial' => 0,
            'StatusCutting' => 'Pending',
            'MethodCutting' => 'Laser',
            'RincianCutting' => '',
            'StatusJahit' => 'Pending',
            'StatusQC' => 'Pending',
            'RejectQty' => 0,
            'CreatedAt' => $nowIso,
            'CreatedBy' => $newOrder['CreatedBy'],
            'TujuanPengiriman' => $newOrder['NamaKonsumen'],
            'Penerima' => $newOrder['NamaKonsumen'],
            'MaterialType' => $matType,
            'MaterialTypeNote' => $matNote,
            'MainColor' => $newOrder['MainColor'],
            'ColorProfile' => $colorProfile,
            'VerifiedColorProfile' => $newOrder['VerifiedColorProfile'],
            'TestPrintStatus' => $newOrder['TestPrintStatus'],
            'TestPrintNotes' => $newOrder['TestPrintNotes'],
            'MockupFront' => $newOrder['MockupFront'],
            'MockupBack' => $newOrder['MockupBack'],
            'MockupLeft' => $newOrder['MockupLeft'],
            'MockupRight' => $newOrder['MockupRight'],
            'DaftarBarang' => $daftarBarang,
            'TotalBarang' => $totalBarang
        ];
        array_unshift($state['spkList'], $newSPK);

        // Auto register customer profile
        $custKey = strtolower(trim($newOrder['NamaKonsumen']));
        if ($custKey !== '') {
            $state['deletedCustomerKeys'] = array_values(array_filter($state['deletedCustomerKeys'], function($k) use ($custKey) { return strtolower($k) !== $custKey; }));
            $foundC = false;
            foreach ($state['customerProfiles'] as &$cp) {
                if (strtolower(trim($cp['nama'])) === $custKey) {
                    if (empty($cp['noTelp']) && !empty($newOrder['NoTelpKonsumen'])) $cp['noTelp'] = $newOrder['NoTelpKonsumen'];
                    if (empty($cp['email']) && !empty($newOrder['EmailKonsumen'])) $cp['email'] = $newOrder['EmailKonsumen'];
                    if (empty($cp['alamat']) && !empty($newOrder['AlamatPengiriman'])) $cp['alamat'] = $newOrder['AlamatPengiriman'];
                    $foundC = true; break;
                }
            }
            unset($cp);
            if (!$foundC) {
                $state['customerProfiles'][] = [
                    'id' => 'CUST-' . strtoupper(base_convert(strval(time()), 10, 36)),
                    'nama' => trim($newOrder['NamaKonsumen']),
                    'noTelp' => $newOrder['NoTelpKonsumen'],
                    'email' => $newOrder['EmailKonsumen'],
                    'alamat' => $newOrder['AlamatPengiriman'],
                    'catatan' => 'Otomatis terdaftar dari entri order baru',
                    'createdAt' => $nowIso
                ];
            }
        }

        if (in_array($newOrder['Status'], ['Antri Print', 'Print', 'Antri Press', 'Press', 'Antri Cutting', 'Cutting', 'Antri Jahit', 'Jahit', 'Antri QC', 'QC', 'Selesai']) && $initialMeter > 0) {
            ErpHelpers::syncPaperStockDeduction($state, $orderId, $initialMeter, $initialWidth, $initialPaperType, "Order Baru: {$newOrder['Status']}");
        }

        ErpHelpers::addLog($state, 'CS', 'Customer Service', 'CREATE_ORDER', "Membuat order baru {$orderId} untuk {$newOrder['NamaKonsumen']}");
        ErpHelpers::broadcastNotification($state, 'Order Baru Dibuat', "Pesanan {$orderId} ({$newOrder['NamaKonsumen']}) berhasil dibuat oleh {$newOrder['CreatedBy']}.", 'success', $orderId);
        ErpHelpers::syncToPayroll($state, [
            'id' => 'sub-' . $newOrder['ID'],
            'date' => substr($newOrder['TanggalOrder'], 0, 10),
            'businessUnit' => 'ERVO SUBLIME',
            'type' => 'income',
            'category' => 'Jasa Cetak Sublime',
            'amount' => floatval($newOrder['PriceTotal']),
            'description' => 'Order Cetak ' . $newOrder['NamaKonsumen'] . ($initialMeter > 0 ? " ({$initialMeter}m)" : ''),
            'paymentMethod' => !empty($body['MetodePembayaran']) ? $body['MetodePembayaran'] : 'Transfer Bank / Kasir',
            'referenceNo' => $newOrder['ID'],
            'status' => 'completed',
            'source' => 'api_sync',
            'sourceApp' => ErpHelpers::getAppOrigin(),
            'createdAt' => $nowIso
        ]);

        ErpStore::saveState($state);
        ErpStore::pushRealtimeEvent('orders-updated', ['orderId' => $orderId, 'action' => 'create']);
        ErpStore::pushRealtimeEvent('spk-updated', ['orderId' => $orderId]);
        jsonOut(['success' => true, 'message' => 'Order dan SPK berhasil dibuat!', 'order' => $newOrder, 'spk' => $newSPK]);
    }

    if ($method === 'PUT' && preg_match('#^/api/orders/([^/]+)$#', $path, $m)) {
        $orderId = urldecode($m[1]);
        $ordIdx = -1;
        foreach ($state['orders'] as $i => $o) { if ($o['ID'] === $orderId) { $ordIdx = $i; break; } }
        if ($ordIdx === -1) jsonOut(['success' => false, 'message' => 'Order tidak ditemukan!'], 404);

        $prevStatus = $state['orders'][$ordIdx]['Status'];
        $state['orders'][$ordIdx] = array_merge($state['orders'][$ordIdx], $body);
        $state['orders'][$ordIdx]['ModifiedAt'] = ErpHelpers::nowIso();
        $state['orders'][$ordIdx]['ModifiedBy'] = !empty($body['ModifiedBy']) ? $body['ModifiedBy'] : 'System';

        if (isset($body['LayoutPanjangPrint']) && !isset($body['MeterPrint'])) $state['orders'][$ordIdx]['MeterPrint'] = floatval($body['LayoutPanjangPrint']);
        if (isset($body['LayoutLebarKertas']) && !isset($body['PaperSize'])) $state['orders'][$ordIdx]['PaperSize'] = $body['LayoutLebarKertas'];
        if (isset($body['LayoutPaperType']) && !isset($body['PaperType'])) $state['orders'][$ordIdx]['PaperType'] = $body['LayoutPaperType'];

        $spkIdx = -1;
        foreach ($state['spkList'] as $i => $s) { if ($s['OrderID'] === $orderId) { $spkIdx = $i; break; } }
        if ($spkIdx !== -1) {
            foreach (['LayoutPanjangPrint', 'MeterPrint', 'LayoutLebarKertas', 'PaperSize', 'LayoutPaperType', 'PaperType', 'QtyMaterial', 'MaterialType', 'MaterialTypeNote', 'MainColor', 'ColorProfile', 'VerifiedColorProfile', 'TestPrintStatus', 'TestPrintNotes', 'TestPrintDate', 'TestPrintOperator', 'MockupFront', 'MockupBack', 'MockupLeft', 'MockupRight'] as $k) {
                if (isset($body[$k])) $state['spkList'][$spkIdx][$k] = $body[$k];
            }
            if (!empty($body['DaftarBarang']) && is_array($body['DaftarBarang'])) {
                $totB = 0;
                foreach ($body['DaftarBarang'] as $bi) $totB += floatval(isset($bi['jumlah']) ? $bi['jumlah'] : 0);
                $state['orders'][$ordIdx]['TotalBarang'] = $totB;
                $state['spkList'][$spkIdx]['DaftarBarang'] = $body['DaftarBarang'];
                $state['spkList'][$spkIdx]['TotalBarang'] = $totB;
            }
        }

        $currOrd = $state['orders'][$ordIdx];
        $isBawa = (isset($currOrd['FabricOption']) && $currOrd['FabricOption'] === 'Bawa Bahan') || (isset($body['FabricOption']) && $body['FabricOption'] === 'Bawa Bahan');
        if (!$isBawa && !empty($currOrd['QtyMaterial']) && floatval($currOrd['QtyMaterial']) > 0) {
            ErpHelpers::syncFabricStockDeduction($state, $orderId, !empty($currOrd['MaterialPress']) ? $currOrd['MaterialPress'] : (!empty($currOrd['MaterialType']) ? $currOrd['MaterialType'] : ''), $currOrd['QtyMaterial'], 'Update Order');
        } elseif ($isBawa) {
            ErpHelpers::syncFabricStockDeduction($state, $orderId, !empty($currOrd['MaterialPress']) ? $currOrd['MaterialPress'] : '', 0, 'Ubah Bawa Bahan');
        }

        if (!empty($body['Status']) && $body['Status'] !== $prevStatus) {
            $ns = $body['Status'];
            $state['orders'][$ordIdx]['StatusUpdatedAt'] = ErpHelpers::nowIso();
            $state['orders'][$ordIdx]['StatusUpdatedBy'] = !empty($body['StatusUpdatedBy']) ? $body['StatusUpdatedBy'] : 'Operator';
            ErpHelpers::addLog($state, 'USER', $state['orders'][$ordIdx]['StatusUpdatedBy'], 'UPDATE_STATUS', "Mengubah status order {$orderId} dari '{$prevStatus}' ke '{$ns}'");
            ErpHelpers::broadcastNotification($state, 'Pembaruan Status Order', "Order {$orderId} ({$state['orders'][$ordIdx]['NamaKonsumen']}) berubah ke '{$ns}'.", $ns === 'Selesai' ? 'success' : ($ns === 'Reject' ? 'danger' : 'info'), $orderId);

            if ($spkIdx !== -1) {
                if ($ns === 'Pending' || $ns === 'Antri Print') { $state['spkList'][$spkIdx]['StatusPrint'] = 'Pending'; $state['spkList'][$spkIdx]['StatusPress'] = 'Pending'; $state['spkList'][$spkIdx]['StatusCutting'] = 'Pending'; $state['spkList'][$spkIdx]['StatusJahit'] = 'Pending'; $state['spkList'][$spkIdx]['StatusQC'] = 'Pending'; }
                elseif ($ns === 'Test Print') { $state['spkList'][$spkIdx]['StatusPrint'] = 'Test Print'; }
                elseif ($ns === 'Layout') { $state['spkList'][$spkIdx]['StatusPrint'] = 'Layout'; }
                elseif ($ns === 'Print') { $state['spkList'][$spkIdx]['StatusPrint'] = 'Print'; }
                elseif ($ns === 'Antri Press') { $state['spkList'][$spkIdx]['StatusPrint'] = 'Done'; $state['spkList'][$spkIdx]['StatusPress'] = 'Pending'; }
                elseif ($ns === 'Press') { $state['spkList'][$spkIdx]['StatusPrint'] = 'Done'; $state['spkList'][$spkIdx]['StatusPress'] = 'Proses'; }
                elseif ($ns === 'Antri Cutting') { $state['spkList'][$spkIdx]['StatusPrint'] = 'Done'; $state['spkList'][$spkIdx]['StatusPress'] = 'Done'; $state['spkList'][$spkIdx]['StatusCutting'] = 'Pending'; }
                elseif ($ns === 'Cutting') { $state['spkList'][$spkIdx]['StatusPrint'] = 'Done'; $state['spkList'][$spkIdx]['StatusPress'] = 'Done'; $state['spkList'][$spkIdx]['StatusCutting'] = 'Proses'; }
                elseif ($ns === 'Antri Jahit') { $state['spkList'][$spkIdx]['StatusPrint'] = 'Done'; $state['spkList'][$spkIdx]['StatusPress'] = 'Done'; $state['spkList'][$spkIdx]['StatusCutting'] = 'Done'; $state['spkList'][$spkIdx]['StatusJahit'] = 'Pending'; }
                elseif ($ns === 'Jahit') { $state['spkList'][$spkIdx]['StatusPrint'] = 'Done'; $state['spkList'][$spkIdx]['StatusPress'] = 'Done'; $state['spkList'][$spkIdx]['StatusCutting'] = 'Done'; $state['spkList'][$spkIdx]['StatusJahit'] = 'Proses'; }
                elseif ($ns === 'Antri QC') { $state['spkList'][$spkIdx]['StatusPrint'] = 'Done'; $state['spkList'][$spkIdx]['StatusPress'] = 'Done'; $state['spkList'][$spkIdx]['StatusCutting'] = 'Done'; $state['spkList'][$spkIdx]['StatusJahit'] = 'Done'; $state['spkList'][$spkIdx]['StatusQC'] = 'Pending'; }
                elseif ($ns === 'QC') { $state['spkList'][$spkIdx]['StatusQC'] = 'Proses'; }
                elseif ($ns === 'Selesai') { $state['spkList'][$spkIdx]['StatusPrint'] = 'Done'; $state['spkList'][$spkIdx]['StatusPress'] = 'Done'; $state['spkList'][$spkIdx]['StatusCutting'] = 'Done'; $state['spkList'][$spkIdx]['StatusJahit'] = 'Done'; $state['spkList'][$spkIdx]['StatusQC'] = 'OK'; }
            }
        }

        $currSt = $state['orders'][$ordIdx]['Status'];
        $mVal = floatval(!empty($state['orders'][$ordIdx]['MeterPrint']) ? $state['orders'][$ordIdx]['MeterPrint'] : (isset($state['orders'][$ordIdx]['LayoutPanjangPrint']) ? $state['orders'][$ordIdx]['LayoutPanjangPrint'] : 0));
        $lVal = !empty($state['orders'][$ordIdx]['LayoutLebarKertas']) ? $state['orders'][$ordIdx]['LayoutLebarKertas'] : (!empty($state['orders'][$ordIdx]['PaperSize']) ? $state['orders'][$ordIdx]['PaperSize'] : '160 cm');
        $tVal = !empty($state['orders'][$ordIdx]['PaperType']) ? $state['orders'][$ordIdx]['PaperType'] : 'Sticky';
        if (in_array($currSt, ['Layout', 'Antri Print', 'Print', 'Antri Press', 'Press', 'Antri Cutting', 'Cutting', 'Antri Jahit', 'Jahit', 'Antri QC', 'QC', 'Selesai']) && $mVal > 0) {
            ErpHelpers::syncPaperStockDeduction($state, $orderId, $mVal, $lVal, $tVal, "Status Order: {$currSt}");
        } elseif (in_array($currSt, ['Pending', 'Reject']) && !empty($state['orders'][$ordIdx]['DeductedPaperMeters'])) {
            ErpHelpers::syncPaperStockDeduction($state, $orderId, 0, $lVal, $tVal, "Revert Order: {$currSt}");
        }

        ErpStore::saveState($state);
        ErpStore::pushRealtimeEvent('orders-updated', ['orderId' => $orderId]);
        ErpStore::pushRealtimeEvent('spk-updated', ['orderId' => $orderId]);
        jsonOut(['success' => true, 'message' => 'Order berhasil diperbarui!', 'data' => $state['orders'][$ordIdx]]);
    }

    if ($method === 'POST' && preg_match('#^/api/orders/([^/]+)/reprint$#', $path, $m)) {
        $orderId = urldecode($m[1]);
        $ordIdx = -1;
        foreach ($state['orders'] as $i => $o) { if ($o['ID'] === $orderId) { $ordIdx = $i; break; } }
        if ($ordIdx === -1) jsonOut(['success' => false, 'message' => 'Order tidak ditemukan!'], 404);

        $order = &$state['orders'][$ordIdx];
        $targetStatus = (isset($body['targetStatus']) && $body['targetStatus'] === 'Test Print') ? 'Test Print' : 'Print';
        $respParty = (isset($body['responsibleParty']) && $body['responsibleParty'] === 'internal') ? 'internal' : 'konsumen';
        $meterRep = floatval(isset($body['meterReprint']) ? $body['meterReprint'] : 0);
        $rate = floatval(isset($body['ratePerMeter']) ? $body['ratePerMeter'] : 0);
        $totCost = ($respParty === 'konsumen') ? (isset($body['totalCost']) ? floatval($body['totalCost']) : ($meterRep * $rate)) : 0;
        $reason = !empty($body['reason']) ? $body['reason'] : 'Revisi / Cetak ulang';
        $requestedBy = !empty($body['requestedBy']) ? $body['requestedBy'] : (ErpHelpers::getHeader($headers, 'x-user-role') ?: 'Supervisor');
        $addToInv = ($respParty === 'konsumen' && (!isset($body['addToInvoice']) || $body['addToInvoice'] !== false) && $totCost > 0);

        $repRec = [
            'ID' => 'REP-' . intval(microtime(true) * 1000),
            'OrderID' => $orderId,
            'Timestamp' => ErpHelpers::nowIso(),
            'ResponsibleParty' => $respParty,
            'MeterReprint' => $meterRep,
            'RatePerMeter' => $rate,
            'TotalCost' => $totCost,
            'Reason' => $reason,
            'KategoriKendala' => isset($body['kategoriKendala']) ? $body['kategoriKendala'] : '',
            'OperatorOrDept' => isset($body['operatorOrDept']) ? $body['operatorOrDept'] : '',
            'AddedToInvoice' => $addToInv,
            'TargetStatus' => $targetStatus,
            'RequestedBy' => $requestedBy
        ];

        if (!isset($order['ReprintHistory']) || !is_array($order['ReprintHistory'])) $order['ReprintHistory'] = [];
        array_unshift($order['ReprintHistory'], $repRec);
        $order['IsReprint'] = true;
        $order['Status'] = $targetStatus;
        $order['StatusUpdatedAt'] = ErpHelpers::nowIso();
        $order['StatusUpdatedBy'] = $requestedBy;
        if ($targetStatus === 'Test Print') $order['TestPrintStatus'] = 'Perlu Revisi';

        foreach ($state['spkList'] as &$sp) {
            if ($sp['OrderID'] === $orderId) {
                $sp['IsReprint'] = true;
                $sp['StatusPrint'] = $targetStatus;
                $sp['StatusPress'] = 'Pending';
                $sp['StatusCutting'] = 'Pending';
                $sp['StatusJahit'] = 'Pending';
                $sp['StatusQC'] = 'Pending';
            }
        }
        unset($sp);

        $updInv = null;
        if ($addToInv) {
            $extra = ['id' => 'EXTRA-REP-' . time(), 'description' => "Biaya Cetak Ulang ({$meterRep}m) - {$reason}", 'amount' => $totCost];
            foreach ($state['invoices'] as &$inv) {
                if ($inv['OrderID'] === $orderId || strtolower($inv['NamaKonsumen']) === strtolower($order['NamaKonsumen'])) {
                    if (!isset($inv['ExtraItems'])) $inv['ExtraItems'] = [];
                    $inv['ExtraItems'][] = $extra;
                    $inv['TotalAmount'] = floatval($inv['TotalAmount']) + $totCost;
                    $updInv = $inv;
                    foreach ($state['piutangs'] as &$pit) {
                        if ($pit['InvoiceID'] === $inv['ID']) {
                            $pit['Jumlah'] = $inv['TotalAmount'];
                            $pit['Sisa'] = max(0, $inv['TotalAmount'] - floatval(isset($inv['PaidAmount']) ? $inv['PaidAmount'] : 0));
                        }
                    }
                    unset($pit);
                    break;
                }
            }
            unset($inv);
        }

        if ($meterRep > 0 && $targetStatus === 'Print') {
            $prevD = floatval(isset($order['DeductedPaperMeters']) ? $order['DeductedPaperMeters'] : 0);
            ErpHelpers::syncPaperStockDeduction($state, $orderId, $prevD + $meterRep, isset($order['PaperSize']) ? $order['PaperSize'] : '160 cm', isset($order['PaperType']) ? $order['PaperType'] : 'Sticky', "Cetak Ulang");
        }

        ErpHelpers::addLog($state, 'PRODUCTION', $requestedBy, 'REPRINT_ORDER', "Cetak ulang Order {$orderId} ({$meterRep}m) ke {$targetStatus}");
        ErpHelpers::broadcastNotification($state, 'Cetak Ulang / Rework', "Order {$orderId} diajukan cetak ulang {$meterRep}m oleh {$requestedBy}.", 'warning', $orderId);
        ErpStore::saveState($state);
        ErpStore::pushRealtimeEvent('orders-updated', ['orderId' => $orderId]);
        jsonOut(['success' => true, 'message' => 'Permintaan cetak ulang berhasil diproses!', 'data' => $order, 'reprintRecord' => $repRec, 'invoice' => $updInv]);
    }

    if ($method === 'POST' && preg_match('#^/api/orders/([^/]+)/qc-action$#', $path, $m)) {
        $orderId = urldecode($m[1]);
        $ordIdx = -1;
        foreach ($state['orders'] as $i => $o) { if ($o['ID'] === $orderId) { $ordIdx = $i; break; } }
        if ($ordIdx === -1) jsonOut(['success' => false, 'message' => 'Order tidak ditemukan!'], 404);

        $order = &$state['orders'][$ordIdx];
        $action = isset($body['action']) ? $body['action'] : '';
        $targetDept = isset($body['targetDept']) ? $body['targetDept'] : 'print';
        $reworkQty = intval(isset($body['reworkQty']) ? $body['reworkQty'] : 0);
        $passedQty = intval(isset($body['passedQty']) ? $body['passedQty'] : 0);
        $reason = isset($body['reason']) ? $body['reason'] : 'Perbaikan QC';
        $actor = !empty($body['operatorName']) ? $body['operatorName'] : (ErpHelpers::getHeader($headers, 'x-user-nama') ?: 'Petugas QC');

        if ($action === 'rework' || $action === 'rework_queue') {
            $tStatus = ($action === 'rework_queue' || $targetDept === 'rework_queue') ? 'Reject' : ucfirst($targetDept);
            if ($tStatus === 'Print' || $tStatus === 'Press' || $tStatus === 'Cutting' || $tStatus === 'Jahit' || $tStatus === 'Reject') {
                $order['Status'] = $tStatus;
            } else {
                $order['Status'] = 'Print';
            }
            $order['IsReprint'] = true;
            $order['StatusUpdatedAt'] = ErpHelpers::nowIso();
            $order['StatusUpdatedBy'] = $actor;
            ErpHelpers::addLog($state, 'QC', $actor, 'QC_REJECT_ROUTED', "QC merouting {$orderId} ke {$order['Status']}: {$reason}");
            ErpHelpers::broadcastNotification($state, 'QC Reject: Rework', "Order {$orderId} dialihkan ke {$order['Status']} ({$reworkQty} Pcs): {$reason}", 'danger', $orderId);
            ErpStore::saveState($state);
            ErpStore::pushRealtimeEvent('orders-updated', ['orderId' => $orderId]);
            jsonOut(['success' => true, 'message' => "Order #{$orderId} dirouting ke {$order['Status']}!", 'data' => $order]);
        } elseif ($action === 'partial_pass') {
            $order['Status'] = 'Selesai';
            $order['StatusUpdatedAt'] = ErpHelpers::nowIso();
            $order['StatusUpdatedBy'] = $actor;
            ErpHelpers::addLog($state, 'QC', $actor, 'QC_PASS_TOLERANCE', "QC meloloskan {$orderId} dengan toleransi ({$passedQty} Pcs lolos)");
            ErpStore::saveState($state);
            ErpStore::pushRealtimeEvent('orders-updated', ['orderId' => $orderId]);
            jsonOut(['success' => true, 'message' => "Order diselesaikan dengan toleransi ({$passedQty} Pcs).", 'data' => $order]);
        } elseif ($action === 'reject_hold' || $action === 'cancel') {
            $order['Status'] = 'Reject';
            $order['StatusUpdatedAt'] = ErpHelpers::nowIso();
            $order['StatusUpdatedBy'] = $actor;
            ErpHelpers::addLog($state, 'QC', $actor, 'QC_REJECT', "Order {$orderId} ditandai Reject di QC: {$reason}");
            ErpStore::saveState($state);
            ErpStore::pushRealtimeEvent('orders-updated', ['orderId' => $orderId]);
            jsonOut(['success' => true, 'message' => "Order {$orderId} ditandai Reject.", 'data' => $order]);
        }
        jsonOut(['success' => false, 'message' => 'Aksi QC tidak valid.'], 400);
    }

    if ($method === 'DELETE' && preg_match('#^/api/orders/([^/]+)$#', $path, $m)) {
        $orderId = urldecode($m[1]);
        foreach ($state['orders'] as $o) {
            if ($o['ID'] === $orderId) {
                if (!empty($o['DeductedPaperMeters']) && floatval($o['DeductedPaperMeters']) > 0) {
                    ErpHelpers::syncPaperStockDeduction($state, $orderId, 0, isset($o['PaperSize']) ? $o['PaperSize'] : '160 cm', isset($o['PaperType']) ? $o['PaperType'] : 'Sticky', "Hapus Order: {$orderId}");
                }
                if (!empty($o['DeductedFabricQty']) && floatval($o['DeductedFabricQty']) > 0) {
                    ErpHelpers::syncFabricStockDeduction($state, $orderId, isset($o['MaterialPress']) ? $o['MaterialPress'] : '', 0, "Hapus Order: {$orderId}");
                }
                break;
            }
        }
        $state['orders'] = array_values(array_filter($state['orders'], function($o) use ($orderId) { return $o['ID'] !== $orderId; }));
        $state['spkList'] = array_values(array_filter($state['spkList'], function($s) use ($orderId) { return $s['OrderID'] !== $orderId; }));
        ErpHelpers::addLog($state, 'ADMIN', 'Admin', 'DELETE_ORDER', "Menghapus order {$orderId}");
        ErpStore::saveState($state);
        ErpStore::pushRealtimeEvent('orders-updated', ['orderId' => $orderId, 'action' => 'delete']);
        ErpStore::pushRealtimeEvent('spk-updated', ['orderId' => $orderId]);
        jsonOut(['success' => true, 'message' => 'Order berhasil dihapus!']);
    }

    // ========================================================
    // SPK API
    // ========================================================
    if ($method === 'GET' && $path === '/api/spk') {
        jsonOut(['success' => true, 'data' => $state['spkList']]);
    }

    if ($method === 'GET' && preg_match('#^/api/spk/([^/]+)$#', $path, $m)) {
        $oid = urldecode($m[1]);
        foreach ($state['spkList'] as $s) {
            if ($s['OrderID'] === $oid || $s['ID'] === $oid) jsonOut(['success' => true, 'data' => $s]);
        }
        foreach ($state['orders'] as $o) {
            if ($o['ID'] === $oid) {
                $spk = [
                    'ID' => 'SPK-' . time(),
                    'OrderID' => $o['ID'],
                    'NamaKonsumen' => $o['NamaKonsumen'],
                    'NamaFile' => $o['NamaFile'],
                    'JenisOrder' => $o['JenisOrder'],
                    'Deadline' => $o['Deadline'],
                    'Kriteria' => $o['Kriteria'],
                    'StatusPrint' => 'Pending',
                    'MeterPrint' => isset($o['MeterPrint']) ? $o['MeterPrint'] : 0,
                    'PaperType' => isset($o['PaperType']) ? $o['PaperType'] : 'Sticky',
                    'PaperSize' => isset($o['PaperSize']) ? $o['PaperSize'] : '160 cm',
                    'StatusPress' => 'Pending',
                    'FabricOption' => isset($o['FabricOption']) ? $o['FabricOption'] : 'Beli Bahan',
                    'FabricPrice' => isset($o['FabricPrice']) ? $o['FabricPrice'] : 85000,
                    'MaterialPress' => isset($o['MaterialPress']) ? $o['MaterialPress'] : 'Kain Dryfit Titik',
                    'QtyMaterial' => 0,
                    'StatusJahit' => 'Pending',
                    'StatusQC' => 'Pending',
                    'RejectQty' => 0,
                    'CreatedAt' => ErpHelpers::nowIso(),
                    'CreatedBy' => isset($o['CreatedBy']) ? $o['CreatedBy'] : 'CS',
                    'DaftarBarang' => isset($o['DaftarBarang']) ? $o['DaftarBarang'] : [],
                    'TotalBarang' => isset($o['TotalBarang']) ? $o['TotalBarang'] : 0
                ];
                $state['spkList'][] = $spk;
                ErpStore::saveState($state);
                jsonOut(['success' => true, 'data' => $spk]);
            }
        }
        jsonOut(['success' => false, 'message' => 'Order tidak ditemukan!'], 404);
    }

    if ($method === 'PUT' && preg_match('#^/api/spk/([^/]+)$#', $path, $m)) {
        $spkId = urldecode($m[1]);
        $spkIdx = -1;
        foreach ($state['spkList'] as $i => $s) {
            if ($s['ID'] === $spkId || $s['OrderID'] === $spkId) { $spkIdx = $i; break; }
        }
        if ($spkIdx === -1) jsonOut(['success' => false, 'message' => 'SPK tidak ditemukan!'], 404);

        $oldSPK = $state['spkList'][$spkIdx];
        $state['spkList'][$spkIdx] = array_merge($oldSPK, $body);
        $newSPK = &$state['spkList'][$spkIdx];

        if (isset($body['LayoutPanjangPrint'])) {
            $newSPK['LayoutPanjangPrint'] = floatval($body['LayoutPanjangPrint']);
            if (!isset($body['MeterPrint']) && empty($newSPK['MeterPrint'])) $newSPK['MeterPrint'] = $newSPK['LayoutPanjangPrint'];
        }
        if (isset($body['LayoutLebarKertas']) && !isset($body['PaperSize'])) $newSPK['PaperSize'] = $body['LayoutLebarKertas'];
        if (isset($body['LayoutPaperType']) && !isset($body['PaperType'])) $newSPK['PaperType'] = $body['LayoutPaperType'];

        $deductedMaterials = [];
        $meterPrint = floatval(!empty($newSPK['MeterPrint']) ? $newSPK['MeterPrint'] : (isset($newSPK['LayoutPanjangPrint']) ? $newSPK['LayoutPanjangPrint'] : 0));
        $isPrintActive = (
            (isset($body['StatusPrint']) && ($body['StatusPrint'] === 'Done' || $body['StatusPrint'] === 'Print')) ||
            (isset($newSPK['StatusPrint']) && ($newSPK['StatusPrint'] === 'Done' || $newSPK['StatusPrint'] === 'Print')) ||
            (isset($body['MeterPrint']) && floatval($body['MeterPrint']) > 0)
        );
        if ($isPrintActive && $meterPrint > 0) {
            $rollLen = intval(!empty($newSPK['PaperMeterPerRoll']) ? $newSPK['PaperMeterPerRoll'] : (!empty($newSPK['LayoutPaperMeterPerRoll']) ? $newSPK['LayoutPaperMeterPerRoll'] : 100));
            $paperRes = ErpHelpers::syncPaperStockDeduction($state, $newSPK['OrderID'], $meterPrint, isset($newSPK['PaperSize']) ? $newSPK['PaperSize'] : '160 cm', isset($newSPK['PaperType']) ? $newSPK['PaperType'] : 'Sticky', 'SPK Print', $rollLen);
            if (!empty($paperRes['success']) && $paperRes['deductedRolls'] > 0) {
                $deductedMaterials[] = "{$paperRes['materialName']} (-{$paperRes['deductedRolls']} roll / {$paperRes['deductedMeters']}m)";
            }
        }
        if (isset($newSPK['FabricOption']) && $newSPK['FabricOption'] === 'Beli Bahan') {
            $qtyF = floatval(isset($newSPK['QtyMaterial']) ? $newSPK['QtyMaterial'] : 0);
            if ($qtyF > 0) {
                $fRes = ErpHelpers::syncFabricStockDeduction($state, $newSPK['OrderID'], isset($newSPK['MaterialPress']) ? $newSPK['MaterialPress'] : '', $qtyF, 'SPK Press');
                if (!empty($fRes['success']) && $fRes['deducted'] > 0) $deductedMaterials[] = "{$fRes['materialName']} (-{$fRes['deducted']} Kg)";
            }
        } elseif (isset($newSPK['FabricOption']) && $newSPK['FabricOption'] === 'Bawa Bahan') {
            ErpHelpers::syncFabricStockDeduction($state, $newSPK['OrderID'], isset($newSPK['MaterialPress']) ? $newSPK['MaterialPress'] : '', 0, 'SPK Bawa Bahan');
        }

        // Sync to related order
        foreach ($state['orders'] as &$ord) {
            if ($ord['ID'] === $newSPK['OrderID']) {
                if (isset($body['StatusQC']) && $body['StatusQC'] === 'OK') $ord['Status'] = 'Selesai';
                elseif (isset($body['StatusQC']) && $body['StatusQC'] === 'Reject') $ord['Status'] = 'Reject';
                elseif (isset($body['StatusQC']) && $body['StatusQC'] === 'Proses') $ord['Status'] = 'QC';
                elseif (isset($body['StatusJahit']) && $body['StatusJahit'] === 'Done') $ord['Status'] = ErpHelpers::getNextStageAfter($ord, 'jahit');
                elseif (isset($body['StatusJahit']) && $body['StatusJahit'] === 'Proses') $ord['Status'] = 'Jahit';
                elseif (isset($body['StatusCutting']) && $body['StatusCutting'] === 'Done') $ord['Status'] = ErpHelpers::getNextStageAfter($ord, 'cutting');
                elseif (isset($body['StatusCutting']) && $body['StatusCutting'] === 'Proses') $ord['Status'] = 'Cutting';
                elseif (isset($body['StatusPress']) && $body['StatusPress'] === 'Done') $ord['Status'] = ErpHelpers::getNextStageAfter($ord, 'press');
                elseif (isset($body['StatusPress']) && $body['StatusPress'] === 'Proses') $ord['Status'] = 'Press';
                elseif (isset($body['StatusPrint']) && $body['StatusPrint'] === 'Done') $ord['Status'] = ErpHelpers::getNextStageAfter($ord, 'print');
                elseif (isset($body['StatusPrint']) && in_array($body['StatusPrint'], ['Test Print', 'Layout', 'Print'])) $ord['Status'] = $body['StatusPrint'];

                foreach (['MeterPrint', 'LayoutPanjangPrint', 'PaperType', 'LayoutPaperType', 'PaperSize', 'LayoutLebarKertas', 'PrintCalcMode', 'MaterialPress', 'FabricOption', 'FabricPrice', 'MaterialType', 'MaterialTypeNote', 'QtyMaterial', 'MainColor', 'ColorProfile', 'VerifiedColorProfile', 'TestPrintStatus', 'TestPrintNotes', 'TestPrintDate', 'TestPrintOperator', 'PriceTotal'] as $ok) {
                    if (isset($body[$ok])) $ord[$ok] = $body[$ok];
                }
                if (isset($body['DaftarBarang']) && is_array($body['DaftarBarang'])) {
                    $ord['DaftarBarang'] = $body['DaftarBarang'];
                    $totB = 0; foreach ($body['DaftarBarang'] as $bi) $totB += floatval(isset($bi['jumlah']) ? $bi['jumlah'] : 0);
                    $ord['TotalBarang'] = $totB;
                }
                $ord['StatusUpdatedAt'] = ErpHelpers::nowIso();
                $ord['StatusUpdatedBy'] = !empty($body['UpdatedBy']) ? $body['UpdatedBy'] : 'Operator';
                break;
            }
        }
        unset($ord);

        ErpHelpers::addLog($state, 'OPERATOR', !empty($body['UpdatedBy']) ? $body['UpdatedBy'] : 'Operator', 'UPDATE_SPK', "Mengubah data SPK {$spkId}");
        ErpHelpers::broadcastNotification($state, 'SPK Diperbarui', "Data SPK {$spkId} ({$newSPK['NamaKonsumen']}) diperbarui.", 'info', $newSPK['OrderID']);
        ErpStore::saveState($state);
        ErpStore::pushRealtimeEvent('spk-updated', ['spkId' => $spkId]);
        ErpStore::pushRealtimeEvent('orders-updated', ['orderId' => $newSPK['OrderID']]);
        jsonOut(['success' => true, 'message' => 'SPK berhasil diperbarui!', 'data' => $newSPK, 'deductedMaterials' => $deductedMaterials]);
    }

    // ========================================================
    // MATERIALS API
    // ========================================================
    if ($method === 'GET' && $path === '/api/materials') {
        jsonOut(['success' => true, 'data' => $state['materials']]);
    }

    if ($method === 'POST' && $path === '/api/materials') {
        $newId = ErpHelpers::generateNextMaterialId($state['materials']);
        $kat = !empty($body['Kategori']) ? $body['Kategori'] : 'Lainnya';
        $stok = floatval(isset($body['Stok']) ? $body['Stok'] : 0);
        $newMat = [
            'ID' => $newId,
            'NamaMaterial' => !empty($body['NamaMaterial']) ? $body['NamaMaterial'] : 'Material Baru',
            'Satuan' => !empty($body['Satuan']) ? $body['Satuan'] : ($kat === 'Fabric' ? 'Kg' : ($kat === 'Paper' ? 'roll' : 'pcs')),
            'Stok' => $stok,
            'MinStok' => floatval(isset($body['MinStok']) ? $body['MinStok'] : 5),
            'Harga' => floatval(isset($body['Harga']) ? $body['Harga'] : 10000),
            'Kategori' => $kat,
            'RollCount' => isset($body['RollCount']) ? floatval($body['RollCount']) : ($kat === 'Fabric' ? round($stok / 25, 1) : null),
            'MeterPerRoll' => isset($body['MeterPerRoll']) ? floatval($body['MeterPerRoll']) : ($kat === 'Paper' ? 100 : null),
            'LebarPaper' => isset($body['LebarPaper']) ? $body['LebarPaper'] : null,
            'WeightNotes' => isset($body['WeightNotes']) ? $body['WeightNotes'] : '',
            'SuratJalanNo' => isset($body['SuratJalanNo']) ? $body['SuratJalanNo'] : '',
            'Supplier' => isset($body['Supplier']) ? $body['Supplier'] : ''
        ];
        $state['materials'][] = $newMat;
        ErpHelpers::addLog($state, 'USR-MATERIAL', 'Admin', 'ADD_MATERIAL', "Menambah material baru '{$newMat['NamaMaterial']}'");
        ErpStore::saveState($state);
        ErpStore::pushRealtimeEvent('materials-updated', ['id' => $newId]);
        jsonOut(['success' => true, 'message' => "Material '{$newMat['NamaMaterial']}' berhasil ditambahkan!", 'data' => $newMat, 'priceSettings' => $state['priceSettings']]);
    }

    if ($method === 'POST' && $path === '/api/materials/receive-rolls') {
        $matId = isset($body['materialId']) ? $body['materialId'] : '';
        $rollsIn = floatval(isset($body['rollCount']) ? $body['rollCount'] : 0);
        if ($rollsIn <= 0) jsonOut(['success' => false, 'message' => 'Jumlah Roll fisik harus lebih dari 0!'], 400);

        foreach ($state['materials'] as &$mat) {
            if ($mat['ID'] === $matId) {
                $unitClean = strtolower(trim(isset($mat['Satuan']) ? $mat['Satuan'] : ''));
                $isPaper = (isset($mat['Kategori']) && $mat['Kategori'] === 'Paper') || $unitClean === 'roll';
                $isFabricKg = !$isPaper && ((isset($mat['Kategori']) && $mat['Kategori'] === 'Fabric') || $unitClean === 'kg');
                if ($isFabricKg) {
                    $kgIn = floatval(isset($body['totalKg']) ? $body['totalKg'] : 0);
                    if ($kgIn <= 0) jsonOut(['success' => false, 'message' => 'Total Berat Riil (Kg) harus diisi!'], 400);
                    $mat['Stok'] = round(floatval($mat['Stok']) + $kgIn, 1);
                    $mat['RollCount'] = round((isset($mat['RollCount']) ? floatval($mat['RollCount']) : 0) + $rollsIn, 1);
                    $mat['AvgWeightPerRoll'] = round($mat['Stok'] / max(1, $mat['RollCount']), 2);
                } elseif ($isPaper) {
                    $mRoll = !empty($body['meterPerRoll']) ? floatval($body['meterPerRoll']) : (!empty($mat['MeterPerRoll']) ? floatval($mat['MeterPerRoll']) : 100);
                    $mat['Stok'] = round(floatval($mat['Stok']) + $rollsIn, 2);
                    $mat['MeterPerRoll'] = $mRoll;
                } else {
                    $added = !empty($body['totalKg']) ? floatval($body['totalKg']) : $rollsIn;
                    $mat['Stok'] = round(floatval($mat['Stok']) + $added, 2);
                }
                $mat['LastBatchDate'] = ErpHelpers::nowIso();
                $mat['LastReceivedRolls'] = $rollsIn;
                if (!empty($body['suratJalanNo'])) $mat['SuratJalanNo'] = $body['suratJalanNo'];
                if (!empty($body['supplier'])) $mat['Supplier'] = $body['supplier'];

                // Record expense if nominal provided
                $purchaseAmt = floatval(!empty($body['nominalPembelian']) ? $body['nominalPembelian'] : (!empty($body['totalHarga']) ? $body['totalHarga'] : 0));
                if ($purchaseAmt > 0) {
                    $expItem = [
                        'id' => 'EXP-MAT-' . time(),
                        'tanggal' => ErpHelpers::todayYmd(),
                        'kategori' => $isPaper ? 'Bahan Baku Sublime' : ($mat['Kategori'] === 'Ink' ? 'Bahan Tinta' : 'Bahan Baku Sublime'),
                        'nominal' => $purchaseAmt,
                        'keterangan' => "Pembelian {$rollsIn} Roll {$mat['NamaMaterial']}",
                        'metodeBayar' => !empty($body['metodeBayar']) ? $body['metodeBayar'] : 'Transfer Bank BCA',
                        'noReferensi' => !empty($body['suratJalanNo']) ? $body['suratJalanNo'] : ('SJ-' . time()),
                        'dicatatOleh' => !empty($body['receivedBy']) ? $body['receivedBy'] : 'Petugas Gudang',
                        'createdAt' => ErpHelpers::nowIso()
                    ];
                    array_unshift($state['operationalExpenses'], $expItem);
                }
                ErpHelpers::addLog($state, 'WAREHOUSE', !empty($body['receivedBy']) ? $body['receivedBy'] : 'Gudang', 'RECEIVE_ROLLS', "Penerimaan {$rollsIn} Roll {$mat['NamaMaterial']}");
                ErpStore::saveState($state);
                ErpStore::pushRealtimeEvent('materials-updated', ['id' => $matId]);
                jsonOut(['success' => true, 'message' => "Berhasil mencatat penerimaan {$rollsIn} Roll {$mat['NamaMaterial']}.", 'data' => $mat]);
            }
        }
        unset($mat);
        jsonOut(['success' => false, 'message' => 'Material tidak ditemukan di inventori gudang!'], 404);
    }

    if ($method === 'POST' && $path === '/api/materials/sell-fabric') {
        $qty = floatval(isset($body['qty']) ? $body['qty'] : 0);
        if ($qty <= 0) jsonOut(['success' => false, 'message' => 'Kuantitas kain harus lebih dari 0!'], 400);
        $matId = isset($body['materialId']) ? $body['materialId'] : '';
        $fabName = isset($body['fabricName']) ? $body['fabricName'] : '';
        foreach ($state['materials'] as &$mat) {
            if ($mat['ID'] === $matId || ($fabName && strtolower($mat['NamaMaterial']) === strtolower($fabName))) {
                if (floatval($mat['Stok']) < $qty) {
                    jsonOut(['success' => false, 'message' => "Stok kain '{$mat['NamaMaterial']}' tidak mencukupi!"], 400);
                }
                $mat['Stok'] = max(0, round(floatval($mat['Stok']) - $qty, 1));
                $avgW = !empty($mat['AvgWeightPerRoll']) ? floatval($mat['AvgWeightPerRoll']) : 25;
                $mat['RollCount'] = round($mat['Stok'] / $avgW, 1);
                ErpHelpers::addLog($state, 'ADMIN', 'Kasir', 'SELL_FABRIC', "Penjualan kain langsung: {$mat['NamaMaterial']} (-{$qty} {$mat['Satuan']})");
                ErpStore::saveState($state);
                ErpStore::pushRealtimeEvent('materials-updated', ['id' => $mat['ID']]);
                jsonOut(['success' => true, 'message' => "Penjualan {$qty} {$mat['Satuan']} kain {$mat['NamaMaterial']} berhasil.", 'data' => $mat]);
            }
        }
        unset($mat);
        jsonOut(['success' => false, 'message' => 'Material kain tidak ditemukan!'], 404);
    }

    if ($method === 'GET' && $path === '/api/materials/paper-usage') {
        $printStages = ['Antri Print', 'Print', 'Antri Press', 'Press', 'Antri Cutting', 'Cutting', 'Antri Jahit', 'Jahit', 'Antri QC', 'QC', 'Selesai'];
        $activePaperOrders = [];
        $totalMeters = 0; $totalRolls = 0; $breakdown = [];
        foreach ($state['orders'] as $o) {
            $meter = floatval(!empty($o['MeterPrint']) ? $o['MeterPrint'] : (isset($o['LayoutPanjangPrint']) ? $o['LayoutPanjangPrint'] : 0));
            $deducted = floatval(isset($o['DeductedPaperMeters']) ? $o['DeductedPaperMeters'] : 0);
            if ($meter > 0 || $deducted > 0 || in_array($o['Status'], $printStages)) {
                $width = !empty($o['LayoutLebarKertas']) ? $o['LayoutLebarKertas'] : (!empty($o['PaperSize']) ? $o['PaperSize'] : '160 cm');
                $type = !empty($o['LayoutPaperType']) ? $o['LayoutPaperType'] : (!empty($o['PaperType']) ? $o['PaperType'] : 'Sticky');
                $mRoll = !empty($o['PaperMeterPerRoll']) ? floatval($o['PaperMeterPerRoll']) : 100;
                $dedRolls = round($deducted / $mRoll, 2);
                $activePaperOrders[] = [
                    'orderId' => $o['ID'], 'namaKonsumen' => $o['NamaKonsumen'], 'namaFile' => $o['NamaFile'], 'status' => $o['Status'],
                    'meterPrint' => $meter, 'layoutPanjangPrint' => floatval(isset($o['LayoutPanjangPrint']) ? $o['LayoutPanjangPrint'] : 0),
                    'paperSize' => $width, 'paperType' => $type, 'deductedMeters' => $deducted, 'deductedRolls' => $dedRolls,
                    'isDeducted' => !empty($o['PaperStockDeducted']),
                    'materialSKU' => !empty($o['DeductedPaperSKU']) ? $o['DeductedPaperSKU'] : 'MAT-008',
                    'materialName' => !empty($o['DeductedPaperName']) ? $o['DeductedPaperName'] : "Kertas Sublim Roll {$width}",
                    'estimatedRolls' => round($meter / $mRoll, 2),
                    'isInPrintStage' => in_array($o['Status'], $printStages),
                    'tanggalOrder' => !empty($o['TanggalOrder']) ? $o['TanggalOrder'] : $o['CreatedAt']
                ];
                $totalMeters += $deducted;
                $totalRolls += $dedRolls;
                if (!isset($breakdown[$width])) $breakdown[$width] = ['meters' => 0, 'rolls' => 0, 'orderCount' => 0];
                $breakdown[$width]['meters'] = round($breakdown[$width]['meters'] + $deducted, 1);
                $breakdown[$width]['rolls'] = round($breakdown[$width]['rolls'] + $dedRolls, 2);
                $breakdown[$width]['orderCount'] += 1;
            }
        }
        $paperMats = [];
        foreach ($state['materials'] as $m) {
            if (isset($m['Kategori']) && $m['Kategori'] === 'Paper') {
                $mR = !empty($m['MeterPerRoll']) ? floatval($m['MeterPerRoll']) : 100;
                $paperMats[] = [
                    'id' => $m['ID'], 'name' => $m['NamaMaterial'], 'stokRoll' => $m['Stok'], 'minStok' => $m['MinStok'],
                    'meterPerRoll' => $mR, 'totalMetersCapacity' => round($m['Stok'] * $mR),
                    'lebarPaper' => !empty($m['LebarPaper']) ? $m['LebarPaper'] : '160 cm',
                    'harga' => $m['Harga'], 'isLow' => floatval($m['Stok']) <= floatval($m['MinStok'])
                ];
            }
        }
        jsonOut(['success' => true, 'data' => [
            'orders' => $activePaperOrders,
            'summary' => ['totalOrdersWithPaper' => count($activePaperOrders), 'totalMetersUsed' => round($totalMeters, 1), 'totalRollsDeducted' => round($totalRolls, 2), 'breakdownByWidth' => !empty($breakdown) ? $breakdown : new stdClass()],
            'paperMaterials' => $paperMats
        ]]);
    }

    if ($method === 'POST' && $path === '/api/materials/reconcile-paper') {
        $printStages = ['Layout', 'Antri Print', 'Print', 'Antri Press', 'Press', 'Antri Cutting', 'Cutting', 'Antri Jahit', 'Jahit', 'Antri QC', 'QC', 'Selesai'];
        $cnt = 0; $details = [];
        foreach ($state['orders'] as $o) {
            $mVal = floatval(!empty($o['MeterPrint']) ? $o['MeterPrint'] : (isset($o['LayoutPanjangPrint']) ? $o['LayoutPanjangPrint'] : 0));
            $lVal = !empty($o['LayoutLebarKertas']) ? $o['LayoutLebarKertas'] : (!empty($o['PaperSize']) ? $o['PaperSize'] : '160 cm');
            $tVal = !empty($o['PaperType']) ? $o['PaperType'] : 'Sticky';
            $prevD = floatval(isset($o['DeductedPaperMeters']) ? $o['DeductedPaperMeters'] : 0);
            if (in_array($o['Status'], $printStages) && $mVal > 0 && $prevD != $mVal) {
                ErpHelpers::syncPaperStockDeduction($state, $o['ID'], $mVal, $lVal, $tVal, 'Reconcile Sync');
                $cnt++;
            } elseif (in_array($o['Status'], ['Pending', 'Reject']) && $prevD > 0) {
                ErpHelpers::syncPaperStockDeduction($state, $o['ID'], 0, $lVal, $tVal, 'Revert Order');
                $cnt++;
            }
        }
        ErpStore::saveState($state);
        $pMats = array_values(array_filter($state['materials'], function($m) { return isset($m['Kategori']) && $m['Kategori'] === 'Paper'; }));
        jsonOut(['success' => true, 'message' => "Audit & rekonsiliasi selesai: {$cnt} order diselaraskan.", 'updatedOrdersCount' => $cnt, 'details' => $details, 'paperMaterials' => $pMats]);
    }

    if ($method === 'PUT' && preg_match('#^/api/materials/([^/]+)$#', $path, $m)) {
        $id = urldecode($m[1]);
        foreach ($state['materials'] as &$mat) {
            if ($mat['ID'] === $id) {
                $mat = array_merge($mat, $body);
                if (isset($mat['Kategori']) && $mat['Kategori'] === 'Fabric' && isset($body['Stok']) && !isset($body['RollCount'])) {
                    $avgW = !empty($mat['AvgWeightPerRoll']) ? floatval($mat['AvgWeightPerRoll']) : 25;
                    $mat['RollCount'] = round(floatval($mat['Stok']) / $avgW, 1);
                }
                ErpHelpers::addLog($state, 'ADMIN', 'Admin', 'UPDATE_MATERIAL', "Memperbarui stok/harga material {$mat['NamaMaterial']}");
                ErpStore::saveState($state);
                ErpStore::pushRealtimeEvent('materials-updated', ['id' => $id]);
                jsonOut(['success' => true, 'message' => 'Material berhasil diperbarui!', 'data' => $mat]);
            }
        }
        unset($mat);
        jsonOut(['success' => false, 'message' => 'Material tidak ditemukan!'], 404);
    }

    if ($method === 'DELETE' && preg_match('#^/api/materials/([^/]+)$#', $path, $m)) {
        $id = urldecode($m[1]);
        $userRole = ErpHelpers::getHeader($headers, 'x-user-role') ?: (isset($body['userRole']) ? $body['userRole'] : '');
        if ($userRole && $userRole !== 'Super Admin' && $userRole !== 'Admin') {
            jsonOut(['success' => false, 'message' => 'Akses ditolak!'], 403);
        }
        $deletedMat = null;
        $newMats = [];
        foreach ($state['materials'] as $mat) {
            if ($mat['ID'] === $id) $deletedMat = $mat;
            else $newMats[] = $mat;
        }
        if (!$deletedMat) jsonOut(['success' => false, 'message' => 'Material tidak ditemukan di inventori!'], 404);
        $state['materials'] = $newMats;
        $state['deletedMaterialIds'][] = $id;
        ErpHelpers::addLog($state, 'ADMIN', 'Super Admin', 'DELETE_MATERIAL', "Menghapus material gudang: {$deletedMat['NamaMaterial']}");
        ErpStore::saveState($state);
        ErpStore::pushRealtimeEvent('materials-updated', ['id' => $id]);
        jsonOut(['success' => true, 'message' => "Material {$deletedMat['NamaMaterial']} berhasil dihapus!", 'data' => $deletedMat]);
    }

    // ========================================================
    // FINANCE, INVOICES, PIUTANG & CUSTOMERS
    // ========================================================
    if ($method === 'GET' && $path === '/api/finance') {
        $totalOmset = 0; $totalKasMasuk = 0; $totalPiutang = 0; $totalOverdue = 0;
        $todayStr = ErpHelpers::todayYmd();
        foreach ($state['invoices'] as $i) {
            $amt = floatval(isset($i['TotalAmount']) ? $i['TotalAmount'] : 0);
            $totalOmset += $amt;
            $paid = floatval(isset($i['PaidAmount']) ? $i['PaidAmount'] : ((isset($i['Status']) && $i['Status'] === 'Paid') ? $amt : 0));
            $totalKasMasuk += $paid;
        }
        foreach ($state['piutangs'] as $p) {
            if (isset($p['Status']) && $p['Status'] === 'Belum Lunas') {
                $sisa = floatval(isset($p['Sisa']) ? $p['Sisa'] : 0);
                $totalPiutang += $sisa;
                if (!empty($p['TanggalJatuhTempo']) && $p['TanggalJatuhTempo'] < $todayStr) $totalOverdue += $sisa;
            }
        }
        jsonOut(['success' => true, 'data' => [
            'totalOmset' => $totalOmset, 'totalKasMasuk' => $totalKasMasuk, 'totalRevenue' => $totalKasMasuk,
            'totalLunas' => $totalKasMasuk, 'totalPiutang' => $totalPiutang, 'totalOverdue' => $totalOverdue,
            'invoices' => $state['invoices'], 'piutangs' => $state['piutangs']
        ]]);
    }

    if ($method === 'GET' && $path === '/api/invoices') {
        jsonOut(['success' => true, 'data' => $state['invoices']]);
    }

    if ($method === 'POST' && $path === '/api/invoices') {
        $dateStr = date('Ymd');
        $invId = !empty($body['ID']) ? $body['ID'] : ("INV-{$dateStr}-" . mt_rand(100, 999));
        $paidAmt = floatval(isset($body['PaidAmount']) ? $body['PaidAmount'] : 0);
        $totalAmt = floatval(isset($body['TotalAmount']) ? $body['TotalAmount'] : 0);
        $status = ($paidAmt >= $totalAmt && $totalAmt > 0) ? 'Paid' : 'Unpaid';
        $dueDate = !empty($body['DueDate']) ? $body['DueDate'] : date('Y-m-d', time() + 86400 * 7);

        $newInv = [
            'ID' => $invId,
            'OrderID' => !empty($body['OrderID']) ? $body['OrderID'] : 'ORD-GENERAL',
            'NamaKonsumen' => !empty($body['NamaKonsumen']) ? $body['NamaKonsumen'] : 'Pelanggan',
            'TanggalInvoice' => !empty($body['TanggalInvoice']) ? $body['TanggalInvoice'] : ErpHelpers::todayYmd(),
            'TotalAmount' => $totalAmt,
            'PaidAmount' => $paidAmt,
            'Status' => $status,
            'DueDate' => $dueDate,
            'Notes' => isset($body['Notes']) ? $body['Notes'] : '',
            'Payments' => !empty($body['Payments']) ? $body['Payments'] : ($paidAmt > 0 ? [[
                'ID' => 'PAY-' . time(), 'InvoiceID' => $invId, 'Nominal' => $paidAmt,
                'MetodePembayaran' => 'Setoran DP Awal / Kasir', 'TanggalBayar' => ErpHelpers::todayYmd(),
                'Catatan' => 'Pembayaran DP Awal'
            ]] : []),
            'ExtraItems' => isset($body['ExtraItems']) ? $body['ExtraItems'] : [],
            'DiscountAmount' => floatval(isset($body['DiscountAmount']) ? $body['DiscountAmount'] : 0),
            'PrintRate' => floatval(isset($body['PrintRate']) ? $body['PrintRate'] : 25000),
            'PressRate' => floatval(isset($body['PressRate']) ? $body['PressRate'] : 15000),
            'CuttingRate' => floatval(isset($body['CuttingRate']) ? $body['CuttingRate'] : 5000),
            'SewingRate' => floatval(isset($body['SewingRate']) ? $body['SewingRate'] : 12000),
            'PackingRate' => floatval(isset($body['PackingRate']) ? $body['PackingRate'] : 2000),
            'FabricOption' => isset($body['FabricOption']) ? $body['FabricOption'] : null,
            'FabricPrice' => isset($body['FabricPrice']) ? floatval($body['FabricPrice']) : null,
            'QtyMaterial' => isset($body['QtyMaterial']) ? floatval($body['QtyMaterial']) : null,
            'MaterialPress' => isset($body['MaterialPress']) ? $body['MaterialPress'] : null
        ];
        array_unshift($state['invoices'], $newInv);

        if ($newInv['FabricOption'] === 'Beli Bahan' && !empty($newInv['QtyMaterial']) && $newInv['QtyMaterial'] > 0) {
            ErpHelpers::syncFabricStockDeduction($state, $newInv['OrderID'], $newInv['MaterialPress'] ?: '', $newInv['QtyMaterial'], 'Invoice Diterbitkan');
        }

        $newPit = [
            'ID' => "PIT-{$dateStr}-" . mt_rand(100, 999),
            'InvoiceID' => $invId,
            'NamaKonsumen' => $newInv['NamaKonsumen'],
            'Jumlah' => $totalAmt,
            'TanggalJatuhTempo' => $dueDate,
            'Status' => ($status === 'Paid') ? 'Lunas' : 'Belum Lunas',
            'Sisa' => max(0, $totalAmt - $paidAmt),
            'Notes' => $newInv['Notes']
        ];
        array_unshift($state['piutangs'], $newPit);
        ErpHelpers::addLog($state, 'FINANCE', 'Admin Keuangan', 'CREATE_INVOICE', "Membuat invoice {$invId} sebesar Rp " . ErpHelpers::fmtRp($totalAmt));
        ErpStore::saveState($state);
        ErpStore::pushRealtimeEvent('finance-updated', ['invoiceId' => $invId]);
        jsonOut(['success' => true, 'message' => 'Invoice & Record Piutang berhasil dibuat!', 'invoice' => $newInv, 'piutang' => $newPit]);
    }

    if ($method === 'POST' && preg_match('#^/api/invoices/([^/]+)/(pay|payments)$#', $path, $m)) {
        $invId = urldecode($m[1]);
        $invIdx = -1;
        foreach ($state['invoices'] as $i => $inv) { if ($inv['ID'] === $invId) { $invIdx = $i; break; } }
        if ($invIdx === -1) jsonOut(['success' => false, 'message' => 'Invoice tidak ditemukan!'], 404);

        $payAmt = floatval(isset($body['Nominal']) ? $body['Nominal'] : (isset($body['nominal']) ? $body['nominal'] : 0));
        if ($payAmt <= 0) jsonOut(['success' => false, 'message' => 'Nominal pembayaran harus lebih dari 0!'], 400);

        $metode = !empty($body['MetodePembayaran']) ? $body['MetodePembayaran'] : (!empty($body['metode']) ? $body['metode'] : 'Transfer Bank BCA');
        $noRef = isset($body['NoReferensi']) ? $body['NoReferensi'] : (isset($body['noReferensi']) ? $body['noReferensi'] : '');
        $tglBayar = !empty($body['TanggalBayar']) ? $body['TanggalBayar'] : (!empty($body['tanggalBayar']) ? $body['tanggalBayar'] : ErpHelpers::todayYmd());
        $catatan = isset($body['Catatan']) ? $body['Catatan'] : (isset($body['catatan']) ? $body['catatan'] : '');

        $inv = &$state['invoices'][$invIdx];
        $currPaid = floatval(isset($inv['PaidAmount']) ? $inv['PaidAmount'] : ($inv['Status'] === 'Paid' ? $inv['TotalAmount'] : 0));
        $newPaid = $currPaid + $payAmt;
        $inv['PaidAmount'] = $newPaid;
        if (!isset($inv['Payments']) || !is_array($inv['Payments'])) $inv['Payments'] = [];
        $inv['Payments'][] = ['ID' => 'PAY-' . time(), 'InvoiceID' => $invId, 'Nominal' => $payAmt, 'MetodePembayaran' => $metode, 'TanggalBayar' => $tglBayar, 'NoReferensi' => $noRef, 'Catatan' => $catatan];
        if ($newPaid >= floatval($inv['TotalAmount'])) {
            $inv['Status'] = 'Paid';
            $inv['PaidAt'] = $tglBayar;
            $inv['MetodePembayaran'] = $metode;
            $inv['NoReferensi'] = $noRef;
        } else {
            $inv['Status'] = 'Partial';
        }

        $updPit = null;
        foreach ($state['piutangs'] as &$pit) {
            if ($pit['InvoiceID'] === $invId || $pit['ID'] === $invId) {
                $sisa = max(0, floatval($inv['TotalAmount']) - $newPaid);
                $pit['Sisa'] = $sisa;
                $pit['TanggalBayar'] = $tglBayar;
                if ($sisa <= 0) $pit['Status'] = 'Lunas';
                $updPit = $pit;
                break;
            }
        }
        unset($pit);

        ErpHelpers::addLog($state, 'FINANCE', 'Admin Keuangan', 'INPUT_PAYMENT', "Mencatat pelunasan {$invId} sebesar Rp " . ErpHelpers::fmtRp($payAmt) . " via {$metode}");
        ErpHelpers::broadcastNotification($state, 'Transaksi Pembayaran', "Pelunasan {$invId} ({$inv['NamaKonsumen']}) sebesar Rp " . ErpHelpers::fmtRp($payAmt) . " berhasil dicatat.", 'success', $inv['OrderID']);
        ErpStore::saveState($state);
        ErpStore::pushRealtimeEvent('finance-updated', ['invoiceId' => $invId]);
        jsonOut(['success' => true, 'message' => 'Pelunasan sebesar Rp ' . ErpHelpers::fmtRp($payAmt) . ' berhasil dicatat!', 'invoice' => $inv, 'piutang' => $updPit]);
    }

    if ($method === 'PUT' && preg_match('#^/api/invoices/([^/]+)$#', $path, $m)) {
        $invId = urldecode($m[1]);
        foreach ($state['invoices'] as &$inv) {
            if ($inv['ID'] === $invId) {
                $inv = array_merge($inv, $body);
                $tot = floatval($inv['TotalAmount']);
                $paid = floatval(isset($inv['PaidAmount']) ? $inv['PaidAmount'] : 0);
                $inv['Status'] = ($paid >= $tot && $tot > 0) ? 'Paid' : ($paid > 0 ? 'Partial' : 'Unpaid');
                foreach ($state['piutangs'] as &$pit) {
                    if ($pit['InvoiceID'] === $invId) {
                        $pit['Jumlah'] = $tot;
                        $pit['Sisa'] = max(0, $tot - $paid);
                        $pit['Status'] = ($inv['Status'] === 'Paid') ? 'Lunas' : 'Belum Lunas';
                    }
                }
                unset($pit);
                ErpStore::saveState($state);
                ErpStore::pushRealtimeEvent('finance-updated', ['invoiceId' => $invId]);
                jsonOut(['success' => true, 'message' => 'Invoice berhasil diperbarui!', 'invoice' => $inv]);
            }
        }
        unset($inv);
        jsonOut(['success' => false, 'message' => 'Invoice tidak ditemukan!'], 404);
    }

    if ($method === 'GET' && preg_match('#^/api/invoices/([^/]+)$#', $path, $m)) {
        $invId = urldecode($m[1]);
        foreach ($state['invoices'] as $inv) {
            if ($inv['ID'] === $invId) jsonOut(['success' => true, 'data' => $inv]);
        }
        jsonOut(['success' => false, 'message' => 'Invoice tidak ditemukan!'], 404);
    }

    if ($method === 'DELETE' && preg_match('#^/api/invoices/([^/]+)$#', $path, $m)) {
        $invId = urldecode($m[1]);
        $del = null; $newInv = [];
        foreach ($state['invoices'] as $i) { if ($i['ID'] === $invId) $del = $i; else $newInv[] = $i; }
        $state['invoices'] = $newInv;
        $state['piutangs'] = array_values(array_filter($state['piutangs'], function($p) use ($invId) { return $p['InvoiceID'] !== $invId; }));
        ErpStore::saveState($state);
        ErpStore::pushRealtimeEvent('finance-updated', ['invoiceId' => $invId]);
        jsonOut(['success' => true, 'message' => 'Invoice berhasil dihapus!', 'data' => $del]);
    }

    if ($method === 'DELETE' && preg_match('#^/api/piutangs/([^/]+)$#', $path, $m)) {
        $pid = urldecode($m[1]);
        $state['piutangs'] = array_values(array_filter($state['piutangs'], function($p) use ($pid) { return $p['ID'] !== $pid && $p['InvoiceID'] !== $pid; }));
        ErpStore::saveState($state);
        ErpStore::pushRealtimeEvent('finance-updated', ['piutangId' => $pid]);
        jsonOut(['success' => true, 'message' => 'Catatan piutang berhasil dihapus!']);
    }

    // Customers
    if ($method === 'GET' && $path === '/api/customers') {
        $list = ErpHelpers::getAggregatedCustomers($state);
        $withPit = 0; $sumPit = 0;
        foreach ($list as $c) { if ($c['totalPiutang'] > 0) $withPit++; $sumPit += $c['totalPiutang']; }
        jsonOut(['success' => true, 'data' => $list, 'meta' => ['totalCustomers' => count($list), 'totalWithPiutang' => $withPit, 'totalPiutangAll' => $sumPit]]);
    }

    if ($method === 'GET' && preg_match('#^/api/customers/([^/]+)$#', $path, $m)) {
        $slug = strtolower(trim(urldecode($m[1])));
        foreach (ErpHelpers::getAggregatedCustomers($state) as $c) {
            if (strtolower($c['id']) === $slug || strtolower(trim($c['nama'])) === $slug) jsonOut(['success' => true, 'data' => $c]);
        }
        jsonOut(['success' => false, 'message' => 'Data pelanggan tidak ditemukan!'], 404);
    }

    if ($method === 'POST' && $path === '/api/customers') {
        $nama = isset($body['nama']) ? trim($body['nama']) : '';
        if (!$nama) jsonOut(['success' => false, 'message' => 'Nama pelanggan wajib diisi!'], 400);
        $custKey = strtolower($nama);
        $state['deletedCustomerKeys'] = array_values(array_filter($state['deletedCustomerKeys'], function($k) use ($custKey) { return strtolower($k) !== $custKey; }));
        $found = false;
        $profData = null;
        foreach ($state['customerProfiles'] as &$cp) {
            if (strtolower(trim($cp['nama'])) === $custKey) {
                $cp['nama'] = $nama;
                $cp['noTelp'] = isset($body['noTelp']) ? trim($body['noTelp']) : $cp['noTelp'];
                $cp['email'] = isset($body['email']) ? trim($body['email']) : $cp['email'];
                $cp['alamat'] = isset($body['alamat']) ? trim($body['alamat']) : $cp['alamat'];
                $cp['catatan'] = isset($body['catatan']) ? trim($body['catatan']) : $cp['catatan'];
                $profData = $cp; $found = true; break;
            }
        }
        unset($cp);
        if (!$found) {
            $profData = ['id' => 'CUST-' . strtoupper(base_convert(strval(time()), 10, 36)), 'nama' => $nama, 'noTelp' => isset($body['noTelp']) ? trim($body['noTelp']) : '', 'email' => isset($body['email']) ? trim($body['email']) : '', 'alamat' => isset($body['alamat']) ? trim($body['alamat']) : '', 'catatan' => isset($body['catatan']) ? trim($body['catatan']) : '', 'createdAt' => ErpHelpers::nowIso()];
            $state['customerProfiles'][] = $profData;
        }
        ErpStore::saveState($state);
        $saved = $profData;
        foreach (ErpHelpers::getAggregatedCustomers($state) as $c) { if (strtolower(trim($c['nama'])) === $custKey) { $saved = $c; break; } }
        jsonOut(['success' => true, 'message' => 'Data pelanggan berhasil disimpan!', 'data' => $saved]);
    }

    if ($method === 'PUT' && preg_match('#^/api/customers/([^/]+)$#', $path, $m)) {
        $id = urldecode($m[1]);
        $foundIdx = -1;
        foreach ($state['customerProfiles'] as $i => $cp) { if ($cp['id'] === $id) { $foundIdx = $i; break; } }
        if ($foundIdx === -1) {
            foreach (ErpHelpers::getAggregatedCustomers($state) as $c) {
                if ($c['id'] === $id) {
                    $state['customerProfiles'][] = ['id' => $c['id'], 'nama' => $c['nama'], 'noTelp' => $c['noTelp'], 'email' => $c['email'], 'alamat' => $c['alamat'], 'catatan' => $c['catatan'], 'createdAt' => $c['createdAt'] ?: ErpHelpers::nowIso()];
                    $foundIdx = count($state['customerProfiles']) - 1; break;
                }
            }
        }
        if ($foundIdx === -1) jsonOut(['success' => false, 'message' => 'Pelanggan tidak ditemukan!'], 404);
        if (!empty($body['nama'])) $state['customerProfiles'][$foundIdx]['nama'] = trim($body['nama']);
        foreach (['noTelp', 'email', 'alamat', 'catatan'] as $fk) {
            if (isset($body[$fk])) $state['customerProfiles'][$foundIdx][$fk] = trim($body[$fk]);
        }
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => 'Profil pelanggan berhasil diperbarui!', 'data' => $state['customerProfiles'][$foundIdx]]);
    }

    if ($method === 'DELETE' && preg_match('#^/api/customers/([^/]+)$#', $path, $m)) {
        $id = urldecode($m[1]);
        $targetName = isset($query['nama']) ? $query['nama'] : (isset($body['nama']) ? $body['nama'] : '');
        foreach (ErpHelpers::getAggregatedCustomers($state) as $c) {
            if ($c['id'] === $id) { $targetName = $c['nama']; break; }
        }
        $lowerName = strtolower(trim($targetName));
        if ($lowerName) $state['deletedCustomerKeys'][] = $lowerName;
        $state['customerProfiles'] = array_values(array_filter($state['customerProfiles'], function($c) use ($id, $lowerName) {
            return $c['id'] !== $id && (!$lowerName || strtolower(trim($c['nama'])) !== $lowerName);
        }));
        if ($lowerName) {
            $state['piutangs'] = array_values(array_filter($state['piutangs'], function($p) use ($lowerName) { return strtolower(trim($p['NamaKonsumen'])) !== $lowerName; }));
            if ((!isset($query['deleteInvoices']) || $query['deleteInvoices'] !== 'false') && (!isset($body['deleteInvoices']) || $body['deleteInvoices'] !== false)) {
                $state['invoices'] = array_values(array_filter($state['invoices'], function($i) use ($lowerName) { return strtolower(trim($i['NamaKonsumen'])) !== $lowerName; }));
            }
        }
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => "Data pelanggan {$targetName} berhasil dihapus."]);
    }

    // ========================================================
    // TRACKING, SYNC, PAYROLL, EXPENSES, LOGS, NOTIFICATIONS
    // ========================================================
    if ($method === 'GET' && preg_match('#^/api/tracking/([^/]+)$#', $path, $m)) {
        $q = strtolower(trim(urldecode($m[1])));
        $foundOrd = null;
        foreach ($state['orders'] as $o) {
            if (strtolower($o['ID']) === $q || strtolower(isset($o['NoTelpKonsumen']) ? $o['NoTelpKonsumen'] : '') === $q || strpos(strtolower($o['NamaKonsumen']), $q) !== false) {
                $foundOrd = $o; break;
            }
        }
        if (!$foundOrd) jsonOut(['success' => false, 'message' => 'Order tidak ditemukan dengan ID atau No. Telepon tersebut!'], 404);
        $spk = null;
        foreach ($state['spkList'] as $s) { if ($s['OrderID'] === $foundOrd['ID']) { $spk = $s; break; } }
        jsonOut(['success' => true, 'data' => ErpHelpers::buildTrackingData($state, $foundOrd, $spk)]);
    }

    if ($method === 'POST' && $path === '/api/sync/courier') {
        $state['syncInfo']['courierAPI']['lastSyncTime'] = date('d/m/Y, H.i.s');
        ErpHelpers::addLog($state, 'SYSTEM', 'API Gateway', 'SYNC_COURIER', 'Sinkronisasi status kurir real-time');
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => 'Sinkronisasi API Ekspedisi Kurir berhasil!', 'syncInfo' => $state['syncInfo']['courierAPI']]);
    }

    if ($method === 'POST' && $path === '/api/sync/whatsapp') {
        $state['syncInfo']['whatsappGateway']['messagesSentToday'] += 1;
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => 'Notifikasi WhatsApp terkirim ke nomor pelanggan!', 'sentCount' => $state['syncInfo']['whatsappGateway']['messagesSentToday']]);
    }

    if ($method === 'GET' && $path === '/api/payroll/config') { jsonOut(['success' => true, 'data' => $state['payrollConfig']]); }
    if ($method === 'POST' && $path === '/api/payroll/config') {
        $state['payrollConfig'] = array_merge($state['payrollConfig'], $body);
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => 'Konfigurasi integrasi ERVO Payroll berhasil diperbarui!', 'data' => $state['payrollConfig']]);
    }
    if ($method === 'GET' && $path === '/api/payroll/transactions') { jsonOut(['success' => true, 'data' => $state['payrollTransactions']]); }
    if ($method === 'POST' && $path === '/api/payroll/sync') {
        if (empty($body['id'])) jsonOut(['success' => false, 'message' => 'ID transaksi wajib disertakan!'], 400);
        $res = ErpHelpers::syncToPayroll($state, $body);
        ErpStore::saveState($state);
        jsonOut($res);
    }
    if ($method === 'POST' && $path === '/api/payroll/test') {
        $tx = ['id' => 'sub-test-' . time(), 'date' => ErpHelpers::todayYmd(), 'businessUnit' => 'ERVO SUBLIME', 'type' => 'income', 'category' => 'Jasa Cetak Sublime', 'amount' => 250000, 'description' => 'Order Cetak Uji Coba Integrasi Realtime', 'paymentMethod' => 'Transfer Bank BCA', 'referenceNo' => 'TEST-' . substr(strval(time()), -4), 'status' => 'completed', 'source' => 'api_sync', 'sourceApp' => ErpHelpers::getAppOrigin(), 'createdAt' => ErpHelpers::nowIso()];
        $res = ErpHelpers::syncToPayroll($state, $tx);
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => $res['message'], 'transaction' => $tx]);
    }
    if ($method === 'POST' && $path === '/api/payroll/delete') {
        $ref = isset($body['referenceNoOrId']) ? $body['referenceNoOrId'] : '';
        $state['payrollTransactions'] = array_values(array_filter($state['payrollTransactions'], function($t) use ($ref) {
            return $t['id'] !== $ref && $t['id'] !== ('sub-' . $ref) && (!isset($t['referenceNo']) || $t['referenceNo'] !== $ref);
        }));
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => 'Transaksi payroll dihapus.']);
    }

    // Expenses
    if ($method === 'GET' && $path === '/api/expenses') { jsonOut(['success' => true, 'data' => $state['operationalExpenses']]); }
    if ($method === 'POST' && $path === '/api/expenses') {
        $amt = floatval(isset($body['nominal']) ? $body['nominal'] : 0);
        if ($amt <= 0) jsonOut(['success' => false, 'message' => 'Nominal pengeluaran harus lebih dari 0!'], 400);
        $exp = [
            'id' => 'EXP-' . intval(microtime(true) * 1000),
            'tanggal' => !empty($body['tanggal']) ? $body['tanggal'] : ErpHelpers::todayYmd(),
            'kategori' => !empty($body['kategori']) ? $body['kategori'] : 'Bahan Baku Sublime',
            'nominal' => $amt,
            'keterangan' => !empty($body['keterangan']) ? $body['keterangan'] : 'Pengeluaran Kas Operasional',
            'metodeBayar' => !empty($body['metodeBayar']) ? $body['metodeBayar'] : 'Transfer Bank BCA',
            'noReferensi' => !empty($body['noReferensi']) ? $body['noReferensi'] : ('REF-' . substr(strval(time()), -6)),
            'dicatatOleh' => !empty($body['dicatatOleh']) ? $body['dicatatOleh'] : (ErpHelpers::getHeader($headers, 'x-user-nama') ?: 'Admin'),
            'createdAt' => ErpHelpers::nowIso()
        ];
        array_unshift($state['operationalExpenses'], $exp);
        ErpHelpers::addLog($state, 'FINANCE', $exp['dicatatOleh'], 'EXPENSE_RECORD', "Mencatat kas keluar {$exp['id']} Rp " . ErpHelpers::fmtRp($amt));
        ErpStore::saveState($state);
        ErpStore::pushRealtimeEvent('finance-updated', ['expenseId' => $exp['id']]);
        jsonOut(['success' => true, 'message' => "Kas keluar {$exp['id']} berhasil dicatat!", 'data' => $exp]);
    }
    if ($method === 'PUT' && preg_match('#^/api/expenses/([^/]+)$#', $path, $m)) {
        $eid = urldecode($m[1]);
        foreach ($state['operationalExpenses'] as &$e) {
            if ($e['id'] === $eid) {
                $e = array_merge($e, $body);
                $e['nominal'] = floatval($e['nominal']);
                ErpStore::saveState($state);
                jsonOut(['success' => true, 'message' => "Kas keluar {$eid} berhasil diperbarui!", 'data' => $e]);
            }
        }
        unset($e);
        jsonOut(['success' => false, 'message' => 'Catatan pengeluaran tidak ditemukan!'], 404);
    }
    if ($method === 'DELETE' && preg_match('#^/api/expenses/([^/]+)$#', $path, $m)) {
        $eid = urldecode($m[1]);
        $del = null; $newExp = [];
        foreach ($state['operationalExpenses'] as $e) { if ($e['id'] === $eid) $del = $e; else $newExp[] = $e; }
        if (!$del) jsonOut(['success' => false, 'message' => 'Catatan pengeluaran tidak ditemukan!'], 404);
        $state['operationalExpenses'] = $newExp;
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => 'Pengeluaran berhasil dihapus!', 'data' => $del]);
    }

    // Logs
    if ($method === 'GET' && $path === '/api/logs') { jsonOut(['success' => true, 'data' => $state['logs']]); }
    if (($method === 'DELETE' && $path === '/api/logs') || ($method === 'POST' && $path === '/api/logs/clear')) {
        $userRole = ErpHelpers::getHeader($headers, 'x-user-role') ?: (isset($body['userRole']) ? $body['userRole'] : '');
        if ($userRole && $userRole !== 'Super Admin') {
            jsonOut(['success' => false, 'message' => 'Akses Ditolak: Hanya Super Admin yang berhak menghapus log!'], 403);
        }
        $state['logs'] = [];
        $actor = ErpHelpers::getHeader($headers, 'x-user-nama') ?: 'Super Admin';
        ErpHelpers::addLog($state, 'USR-000', $actor, 'CLEAR_LOGS', 'Membersihkan seluruh riwayat log aktivitas sistem');
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => 'Seluruh riwayat log aktivitas sistem berhasil dibersihkan!', 'data' => $state['logs']]);
    }

    // Notifications REST
    if ($method === 'GET' && $path === '/api/notifications') {
        $userRole = ErpHelpers::getHeader($headers, 'x-user-role') ?: (isset($query['role']) ? $query['role'] : '');
        $userId = ErpHelpers::getHeader($headers, 'x-user-id') ?: (isset($query['userId']) ? $query['userId'] : '');
        if (!$userId || $userRole === 'Konsumen') jsonOut(['success' => true, 'data' => [], 'total' => 0]);
        $since = isset($query['since']) ? $query['since'] : '';
        if ($since) {
            $sinceTs = strtotime($since);
            $newer = array_values(array_filter($state['notifications'], function($n) use ($sinceTs) {
                return strtotime($n['timestamp']) > $sinceTs;
            }));
            jsonOut(['success' => true, 'data' => $newer, 'total' => count($state['notifications'])]);
        }
        jsonOut(['success' => true, 'data' => $state['notifications'], 'total' => count($state['notifications'])]);
    }
    if ($method === 'POST' && $path === '/api/notifications') {
        if (empty($body['title']) || empty($body['message'])) jsonOut(['success' => false, 'message' => 'Title dan message wajib diisi!'], 400);
        $notif = ErpHelpers::broadcastNotification($state, $body['title'], $body['message'], !empty($body['type']) ? $body['type'] : 'info', isset($body['orderId']) ? $body['orderId'] : null, isset($body['id']) ? $body['id'] : null, isset($body['clientId']) ? $body['clientId'] : null);
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'data' => $notif], 201);
    }
    if ($method === 'PATCH' && preg_match('#^/api/notifications/([^/]+)/read$#', $path, $m)) {
        $nid = urldecode($m[1]);
        foreach ($state['notifications'] as &$n) { if ($n['id'] === $nid) { $n['read'] = true; break; } }
        unset($n);
        ErpStore::saveState($state);
        jsonOut(['success' => true]);
    }
    if ($method === 'POST' && $path === '/api/notifications/mark-all-read') {
        foreach ($state['notifications'] as &$n) { $n['read'] = true; }
        unset($n);
        ErpStore::saveState($state);
        jsonOut(['success' => true]);
    }
    if ($method === 'DELETE' && $path === '/api/notifications') {
        $state['notifications'] = [];
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => 'Seluruh notifikasi telah dihapus.']);
    }

    // ========================================================
    // MYSQL & PHPMYADMIN APIS
    // ========================================================
    if ($method === 'GET' && $path === '/api/mysql/status') {
        jsonOut(['success' => true, 'data' => ErpStore::getMysqlStatus()]);
    }
    if ($method === 'POST' && $path === '/api/mysql/test') {
        jsonOut(ErpStore::testMysqlConnection($body));
    }
    if ($method === 'POST' && $path === '/api/mysql/connect') {
        $ok = ErpStore::connectAndInitMysql($body, $state);
        jsonOut([
            'success' => $ok,
            'message' => $ok ? 'Berhasil terhubung ke database MySQL & phpMyAdmin! Skema tabel & data telah disinkronkan.' : 'Gagal terhubung ke MySQL server. Pastikan host, user, password, & database cPanel benar.',
            'data' => ErpStore::getMysqlStatus()
        ]);
    }
    if ($method === 'GET' && $path === '/api/mysql/export-sql') {
        $cfg = ErpStore::getMysqlConfig();
        $sqlDump = ErpHelpers::generatePhpMyAdminSqlDump($state, !empty($cfg['database']) ? $cfg['database'] : 'sublime_erp_db');
        $fname = 'sublime_erp_phpmyadmin_' . ErpHelpers::todayYmd() . '.sql';
        header('Content-Type: application/sql; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $fname . '"');
        echo $sqlDump;
        exit;
    }

    // ========================================================
    // BACKUP 3-TIER, CLOUD STATUS, DASHBOARD & RESET DATA
    // ========================================================
    if ($method === 'GET' && $path === '/api/cloud-status') {
        $mysqlStatus = ErpStore::getMysqlStatus();
        jsonOut(['success' => true, 'data' => [
            'isQuotaExhausted' => false,
            'storageMode' => $mysqlStatus['connected'] ? 'mysql_and_local_php' : 'php_local_database',
            'databaseId' => $mysqlStatus['connected'] ? $mysqlStatus['config']['database'] : 'storage/app_state.json',
            'message' => $mysqlStatus['connected'] ? 'Penyimpanan MySQL & File Lokal PHP aktif dan stabil.' : 'Penyimpanan File Server PHP (storage/app_state.json) aktif dan stabil.'
        ]]);
    }

    if ($method === 'GET' && $path === '/api/backup/status') {
        $counts = ErpHelpers::getDatabaseCounts($state);
        $snaps = isset($state['serverSnapshots']) ? $state['serverSnapshots'] : [];
        $sizeUsed = 0;
        foreach ($snaps as $s) $sizeUsed += isset($s['sizeBytes']) ? intval($s['sizeBytes']) : 0;
        $cfg = $state['backupConfig'];
        $score = (!empty($cfg['tier1']['enabled']) ? 35 : 0) + (!empty($cfg['tier2']['enabled']) && count($snaps) > 0 ? 35 : 0) + (!empty($cfg['tier3']['enabled']) ? 30 : 0);
        $health = $score >= 90 ? 'Optimal (3 Lapis Aktif)' : ($score >= 35 ? 'Perhatian (Sebagian Aktif)' : 'Kritis (Tidak Terlindungi)');
        $lastSnap = !empty($snaps[0]['createdAtISO']) ? ErpHelpers::formatWIB($snaps[0]['createdAtISO']) : 'Belum ada';

        jsonOut(['success' => true, 'data' => [
            'overallHealth' => $health,
            'healthScore' => $score,
            'tier1Status' => ['label' => 'Lapis 1: Local Snapshot & File Portabel', 'active' => !empty($cfg['tier1']['enabled']), 'lastExport' => !empty($cfg['tier1']['lastExportTimestamp']) ? ErpHelpers::formatWIB($cfg['tier1']['lastExportTimestamp']) : 'Belum pernah', 'readyToDownload' => true],
            'tier2Status' => ['label' => 'Lapis 2: Automated Server Snapshots', 'active' => !empty($cfg['tier2']['enabled']), 'totalSnapshots' => count($snaps), 'lastSnapshot' => $lastSnap, 'nextScheduledIn' => 'Setiap 6 Jam (Otomatis)'],
            'tier3Status' => ['label' => 'Lapis 3: Off-Site Cloud Mirror', 'active' => !empty($cfg['tier3']['enabled']), 'lastSync' => !empty($cfg['tier3']['lastCloudSyncTimestamp']) ? ErpHelpers::formatWIB($cfg['tier3']['lastCloudSyncTimestamp']) : 'Belum pernah', 'cloudTarget' => isset($cfg['tier3']['target']) ? $cfg['tier3']['target'] : 'MySQL Off-Site Mirror', 'connectionStatus' => isset($cfg['tier3']['cloudStatus']) ? $cfg['tier3']['cloudStatus'] : 'Connected'],
            'storageUsedBytes' => $sizeUsed,
            'totalRecordsProtected' => $counts['totalRecords'],
            'config' => $cfg
        ]]);
    }

    if ($method === 'GET' && $path === '/api/backup/config') { jsonOut(['success' => true, 'data' => $state['backupConfig']]); }
    if ($method === 'PUT' && $path === '/api/backup/config') {
        $state['backupConfig'] = array_replace_recursive($state['backupConfig'], $body);
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => 'Pengaturan Backup 3 Lapis berhasil disimpan!', 'data' => $state['backupConfig']]);
    }
    if ($method === 'GET' && $path === '/api/backup/snapshots') {
        $list = [];
        foreach ((isset($state['serverSnapshots']) ? $state['serverSnapshots'] : []) as $s) {
            unset($s['fullData']);
            $list[] = $s;
        }
        jsonOut(['success' => true, 'data' => $list]);
    }
    if ($method === 'POST' && $path === '/api/backup/snapshot') {
        $snap = ErpHelpers::createServerSnapshot($state, isset($body['label']) ? $body['label'] : 'Manual Snapshot Titik Pemulihan', !empty($body['trigger']) ? $body['trigger'] : 'manual_restore_point', isset($body['description']) ? $body['description'] : '');
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => "Snapshot server \"{$snap['label']}\" berhasil dibuat!", 'data' => $snap]);
    }
    if ($method === 'GET' && preg_match('#^/api/backup/snapshots/([^/]+)/download$#', $path, $m)) {
        $sid = urldecode($m[1]);
        foreach ((isset($state['serverSnapshots']) ? $state['serverSnapshots'] : []) as $s) {
            if ($s['id'] === $sid && !empty($s['fullData'])) {
                header('Content-Disposition: attachment; filename="' . $sid . '.ersnap"');
                jsonOut($s['fullData']);
            }
        }
        jsonOut(['success' => false, 'message' => 'Snapshot tidak ditemukan.'], 404);
    }
    if ($method === 'DELETE' && preg_match('#^/api/backup/snapshots/([^/]+)$#', $path, $m)) {
        $sid = urldecode($m[1]);
        $state['serverSnapshots'] = array_values(array_filter($state['serverSnapshots'], function($s) use ($sid) { return $s['id'] !== $sid; }));
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => "Snapshot {$sid} berhasil dihapus dari server."]);
    }
    if ($method === 'GET' && $path === '/api/backup/export') {
        $payload = ErpHelpers::createFullSnapshotPayload($state);
        $state['backupConfig']['tier1']['lastExportTimestamp'] = ErpHelpers::nowIso();
        ErpStore::saveState($state);
        header('Content-Disposition: attachment; filename="ERVO-PRINT-SNAPSHOT-3TIER-' . date('Ymd-Hi') . '.ersnap"');
        jsonOut($payload);
    }
    if ($method === 'POST' && $path === '/api/backup/preview') {
        if (empty($body['data'])) jsonOut(['success' => false, 'message' => 'Format berkas snapshot tidak valid!'], 400);
        $currCounts = ErpHelpers::getDatabaseCounts($state);
        $d = $body['data'];
        $sCounts = isset($body['counts']) ? $body['counts'] : [
            'orders' => isset($d['orders']) ? count($d['orders']) : 0,
            'spk' => isset($d['spkList']) ? count($d['spkList']) : 0,
            'materials' => isset($d['materials']) ? count($d['materials']) : 0,
            'invoices' => isset($d['invoices']) ? count($d['invoices']) : 0,
            'piutang' => isset($d['piutangs']) ? count($d['piutangs']) : 0,
            'users' => isset($d['users']) ? count($d['users']) : 0,
            'logs' => isset($d['logs']) ? count($d['logs']) : 0
        ];
        $sCounts['totalRecords'] = $sCounts['orders'] + $sCounts['spk'] + $sCounts['materials'] + $sCounts['invoices'] + $sCounts['piutang'] + $sCounts['users'] + $sCounts['logs'];
        jsonOut(['success' => true, 'data' => [
            'version' => isset($body['version']) ? $body['version'] : '1.0',
            'appId' => isset($body['appId']) ? $body['appId'] : 'UNKNOWN',
            'exportedAt' => isset($body['exportedAt']) ? $body['exportedAt'] : '-',
            'isChecksumValid' => true,
            'checksum' => isset($body['checksum']) ? $body['checksum'] : '-',
            'currentCounts' => $currCounts,
            'snapshotCounts' => $sCounts,
            'summary' => ['ordersDiff' => $sCounts['orders'] - $currCounts['orders'], 'spkDiff' => $sCounts['spk'] - $currCounts['spk'], 'materialsDiff' => $sCounts['materials'] - $currCounts['materials'], 'invoicesDiff' => $sCounts['invoices'] - $currCounts['invoices']]
        ]]);
    }
    if ($method === 'POST' && $path === '/api/backup/import') {
        $snap = isset($body['snapshot']) ? $body['snapshot'] : null;
        if (empty($snap['data'])) jsonOut(['success' => false, 'message' => 'Data snapshot tidak valid.'], 400);
        $d = $snap['data'];
        $mode = isset($body['mode']) ? $body['mode'] : 'replace';
        ErpHelpers::createServerSnapshot($state, 'Safety Pre-Import Snapshot', 'pre_operation', 'Cadangan darurat sebelum restore snapshot.');
        if ($mode !== 'merge') {
            if (isset($d['orders']) && is_array($d['orders'])) $state['orders'] = $d['orders'];
            if (isset($d['spkList']) && is_array($d['spkList'])) $state['spkList'] = $d['spkList'];
            if (isset($d['materials']) && is_array($d['materials'])) $state['materials'] = $d['materials'];
            if (isset($d['invoices']) && is_array($d['invoices'])) $state['invoices'] = $d['invoices'];
            if (isset($d['piutangs']) && is_array($d['piutangs'])) $state['piutangs'] = $d['piutangs'];
            if (!empty($d['users']) && is_array($d['users'])) $state['users'] = $d['users'];
            if (isset($d['logs']) && is_array($d['logs'])) $state['logs'] = $d['logs'];
            if (!empty($d['rolePermissions'])) $state['rolePermissions'] = $d['rolePermissions'];
            if (!empty($d['paperSettings'])) $state['paperSettings'] = $d['paperSettings'];
            if (!empty($d['priceSettings'])) $state['priceSettings'] = $d['priceSettings'];
            if (!empty($d['companyProfile'])) $state['companyProfile'] = $d['companyProfile'];
        } else {
            foreach (['orders', 'spkList', 'materials', 'invoices', 'piutangs'] as $key) {
                if (!empty($d[$key]) && is_array($d[$key])) {
                    $existingIds = array_column($state[$key], 'ID');
                    foreach ($d[$key] as $item) {
                        if (!empty($item['ID']) && !in_array($item['ID'], $existingIds)) $state[$key][] = $item;
                    }
                }
            }
            if (!empty($d['users']) && is_array($d['users'])) {
                foreach ($d['users'] as $incUser) {
                    $incId = isset($incUser['id']) ? $incUser['id'] : '';
                    $incUname = strtolower(trim(isset($incUser['username']) ? $incUser['username'] : ''));
                    $matchIdx = -1;
                    foreach ($state['users'] as $idx => $exUser) {
                        if (($incId && ($exUser['id'] ?? '') === $incId) || ($incUname && strtolower($exUser['username'] ?? '') === $incUname)) {
                            $matchIdx = $idx;
                            break;
                        }
                    }
                    if ($matchIdx === -1) {
                        $state['users'][] = $incUser;
                    } else {
                        $curCreds = isset($state['users'][$matchIdx]['preferences']['biometricCredentials']) && is_array($state['users'][$matchIdx]['preferences']['biometricCredentials'])
                            ? $state['users'][$matchIdx]['preferences']['biometricCredentials'] : [];
                        $incCreds = isset($incUser['preferences']['biometricCredentials']) && is_array($incUser['preferences']['biometricCredentials'])
                            ? $incUser['preferences']['biometricCredentials'] : [];
                        if (count($incCreds) > 0) {
                            $seenIds = [];
                            foreach ($curCreds as $cc) {
                                if (!empty($cc['credentialId'])) $seenIds[$cc['credentialId']] = true;
                            }
                            foreach ($incCreds as $ic) {
                                $cid = isset($ic['credentialId']) ? $ic['credentialId'] : '';
                                if ($cid && !isset($seenIds[$cid]) && count($curCreds) < 5) {
                                    $seenIds[$cid] = true;
                                    $curCreds[] = $ic;
                                }
                            }
                            if (!isset($state['users'][$matchIdx]['preferences']) || !is_array($state['users'][$matchIdx]['preferences'])) {
                                $state['users'][$matchIdx]['preferences'] = [];
                            }
                            $state['users'][$matchIdx]['preferences']['biometricCredentials'] = $curCreds;
                        }
                    }
                }
            }
        }
        ErpStore::saveState($state);
        $cnts = ErpHelpers::getDatabaseCounts($state);
        jsonOut(['success' => true, 'message' => "Pemulihan data berhasil! Total {$cnts['totalRecords']} rekord dimuat.", 'counts' => $cnts]);
    }
    if ($method === 'POST' && preg_match('#^/api/backup/restore/([^/]+)$#', $path, $m)) {
        $sid = urldecode($m[1]);
        foreach ((isset($state['serverSnapshots']) ? $state['serverSnapshots'] : []) as $s) {
            if ($s['id'] === $sid && !empty($s['fullData']['data'])) {
                $d = $s['fullData']['data'];
                foreach (['orders', 'spkList', 'materials', 'invoices', 'piutangs', 'users', 'logs', 'rolePermissions', 'paperSettings', 'priceSettings', 'companyProfile'] as $k) {
                    if (isset($d[$k])) $state[$k] = $d[$k];
                }
                ErpStore::saveState($state);
                jsonOut(['success' => true, 'message' => "Sistem berhasil dikembalikan ke snapshot \"{$s['label']}\"!", 'counts' => ErpHelpers::getDatabaseCounts($state)]);
            }
        }
        jsonOut(['success' => false, 'message' => 'Titik pemulihan snapshot tidak ditemukan.'], 404);
    }
    if ($method === 'POST' && $path === '/api/backup/cloud-sync') {
        $now = ErpHelpers::nowIso();
        $state['backupConfig']['tier3']['lastCloudSyncTimestamp'] = $now;
        $state['backupConfig']['tier3']['cloudStatus'] = 'Connected';
        $rows = count($state['orders']) + count($state['spkList']) + count($state['materials']);
        ErpHelpers::createServerSnapshot($state, 'Cloud Mirror Sync Snapshot', 'cloud_mirror', 'Snapshot Lapis 3.');
        ErpStore::saveState($state);
        jsonOut(['success' => true, 'message' => 'Sinkronisasi cadangan 3 Lapis berhasil!', 'tier3' => $state['backupConfig']['tier3'], 'syncedRows' => $rows]);
    }
    if ($method === 'POST' && $path === '/api/reset-data') {
        $userRole = ErpHelpers::getHeader($headers, 'x-user-role') ?: (isset($body['userRole']) ? $body['userRole'] : '');
        if ($userRole !== 'Super Admin') {
            jsonOut(['success' => false, 'message' => 'Akses Ditolak: Hanya role Super Admin yang berhak mengosongkan seluruh data!'], 403);
        }
        $actorId = ErpHelpers::getHeader($headers, 'x-user-id') ?: (isset($body['userId']) ? $body['userId'] : 'USR-000');
        $actorNama = ErpHelpers::getHeader($headers, 'x-user-nama') ?: (isset($body['userNama']) ? $body['userNama'] : 'Super Admin');

        ErpHelpers::createServerSnapshot($state, 'Emergency Pre-Reset Snapshot', 'pre_operation', "Cadangan darurat otomatis sebelum pengosongan seluruh data oleh {$actorNama}.");
        $state['orders'] = [];
        $state['spkList'] = [];
        $state['materials'] = [];
        $state['invoices'] = [];
        $state['piutangs'] = [];
        $state['customerProfiles'] = [];
        $state['operationalExpenses'] = [];
        $state['payrollTransactions'] = [];
        $state['notifications'] = [];
        $state['deletedCustomerKeys'] = [];
        $state['deletedMaterialIds'] = [];
        $state['deletedMaterialNames'] = [];
        $state['logs'] = [];

        ErpHelpers::addLog($state, $actorId, $actorNama, 'RESET_DATA', 'Seluruh data operasional, transaksi, antrian, stok, pelanggan & kas telah dikosongkan oleh Super Admin.');
        ErpStore::saveState($state);
        ErpStore::pushRealtimeEvent('orders-updated', ['reason' => 'reset-data']);
        ErpStore::pushRealtimeEvent('spk-updated', ['reason' => 'reset-data']);
        ErpStore::pushRealtimeEvent('materials-updated', ['reason' => 'reset-data']);
        ErpStore::pushRealtimeEvent('finance-updated', ['reason' => 'reset-data']);

        jsonOut([
            'success' => true,
            'message' => 'Semua data operasional & transaksi berhasil dikosongkan oleh Super Admin! Cadangan darurat telah diamankan di Lapis 2.',
            'counts' => ErpHelpers::getDatabaseCounts($state)
        ]);
    }

    if ($method === 'GET' && $path === '/api/dashboard') {
        $orders = $state['orders'];
        $totalOrders = count($orders);
        $pending = 0; $inProg = 0; $completed = 0; $urgent = []; $statusCounts = []; $jenisCounts = [];
        foreach ($orders as $o) {
            $st = isset($o['Status']) ? $o['Status'] : 'Pending';
            $statusCounts[$st] = (isset($statusCounts[$st]) ? $statusCounts[$st] : 0) + 1;
            $jn = isset($o['JenisOrder']) ? $o['JenisOrder'] : 'Lainnya';
            $jenisCounts[$jn] = (isset($jenisCounts[$jn]) ? $jenisCounts[$jn] : 0) + 1;
            if ($st === 'Pending') $pending++;
            elseif (in_array($st, ['Test Print', 'Layout', 'Print', 'Press', 'Jahit', 'QC'])) $inProg++;
            elseif ($st === 'Selesai') $completed++;
            if (isset($o['Kriteria']) && ($o['Kriteria'] === 'Urgent' || $o['Kriteria'] === 'Sangat Urgent')) $urgent[] = $o;
        }
        $totalRev = 0;
        foreach ($state['invoices'] as $i) {
            $totalRev += floatval(isset($i['PaidAmount']) ? $i['PaidAmount'] : ((isset($i['Status']) && $i['Status'] === 'Paid') ? $i['TotalAmount'] : 0));
        }
        jsonOut(['success' => true, 'data' => [
            'totalOrders' => $totalOrders, 'pendingOrders' => $pending, 'inProgressOrders' => $inProg,
            'completedOrders' => $completed, 'urgentOrders' => $urgent,
            'statusCounts' => !empty($statusCounts) ? $statusCounts : new stdClass(),
            'jenisOrderCounts' => !empty($jenisCounts) ? $jenisCounts : new stdClass(),
            'totalRevenue' => $totalRev,
            'syncInfo' => $state['syncInfo'],
            'recentLogs' => array_slice($state['logs'], 0, 10)
        ]]);
    }

    // Fallback 404 JSON
    jsonOut(['success' => false, 'message' => "API endpoint {$method} {$path} tidak ditemukan."], 404);

} catch (Throwable $e) {
    jsonOut(['success' => false, 'message' => 'Server PHP Error: ' . $e->getMessage()], 500);
}

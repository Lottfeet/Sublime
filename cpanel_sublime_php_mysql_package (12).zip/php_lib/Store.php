<?php
/**
 * Print Sublime ERP - PHP Persistence Store & MySQL PDO Dual-Write Layer
 * Kompatibel dengan PHP 7.4+ / 8.x di cPanel Hosting Standar (Tanpa Node.js)
 */

class ErpStore {
    private static $rootDir = null;
    private static $storageDir = null;
    private static $stateFile = null;
    private static $realtimeFile = null;
    private static $seedFile = null;
    private static $configFile = null;
    private static $lastMysqlError = null;
    private static $cachedConfig = null;

    public static function initPaths() {
        if (self::$rootDir !== null) return;
        self::$rootDir = dirname(__DIR__);
        self::$storageDir = self::$rootDir . DIRECTORY_SEPARATOR . 'storage';
        self::$stateFile = self::$storageDir . DIRECTORY_SEPARATOR . 'app_state.json';
        self::$realtimeFile = self::$storageDir . DIRECTORY_SEPARATOR . 'realtime_state.json';
        self::$seedFile = self::$rootDir . DIRECTORY_SEPARATOR . 'seed_data.json';
        self::$configFile = self::$rootDir . DIRECTORY_SEPARATOR . 'php_config.json';
        self::ensureStorageDir();
    }

    public static function ensureStorageDir() {
        if (!is_dir(self::$storageDir)) {
            @mkdir(self::$storageDir, 0755, true);
        }
        $ht = self::$storageDir . DIRECTORY_SEPARATOR . '.htaccess';
        if (!file_exists($ht)) {
            @file_put_contents($ht, "<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n  Order allow,deny\n  Deny from all\n</IfModule>\n");
        }
        $idx = self::$storageDir . DIRECTORY_SEPARATOR . 'index.html';
        if (!file_exists($idx)) {
            @file_put_contents($idx, '');
        }
    }

    public static function getRootDir() {
        self::initPaths();
        return self::$rootDir;
    }

    private static function parseEnvFile($path) {
        $vars = [];
        if (!file_exists($path)) return $vars;
        $lines = @file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!$lines) return $vars;
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || substr($line, 0, 1) === '#') continue;
            $pos = strpos($line, '=');
            if ($pos === false) continue;
            $k = trim(substr($line, 0, $pos));
            $v = trim(substr($line, $pos + 1));
            if (strlen($v) >= 2 && (($v[0] === '"' && substr($v, -1) === '"') || ($v[0] === "'" && substr($v, -1) === "'"))) {
                $v = substr($v, 1, -1);
            }
            $vars[$k] = $v;
        }
        return $vars;
    }

    public static function getMysqlConfig() {
        self::initPaths();
        if (self::$cachedConfig !== null) return self::$cachedConfig;

        $env = self::parseEnvFile(self::$rootDir . DIRECTORY_SEPARATOR . '.env');
        $cfg = [
            'host' => isset($env['DB_HOST']) ? $env['DB_HOST'] : (isset($env['MYSQL_HOST']) ? $env['MYSQL_HOST'] : 'localhost'),
            'port' => intval(isset($env['DB_PORT']) ? $env['DB_PORT'] : (isset($env['MYSQL_PORT']) ? $env['MYSQL_PORT'] : 3306)),
            'user' => isset($env['DB_USER']) ? $env['DB_USER'] : (isset($env['MYSQL_USER']) ? $env['MYSQL_USER'] : ''),
            'password' => isset($env['DB_PASSWORD']) ? $env['DB_PASSWORD'] : (isset($env['MYSQL_PASSWORD']) ? $env['MYSQL_PASSWORD'] : ''),
            'database' => isset($env['DB_NAME']) ? $env['DB_NAME'] : (isset($env['MYSQL_DATABASE']) ? $env['MYSQL_DATABASE'] : ''),
            'ssl' => (isset($env['DB_SSL']) && $env['DB_SSL'] === 'true'),
            'configured' => !empty($env['DB_NAME']) && !empty($env['DB_USER'])
        ];

        if (file_exists(self::$configFile)) {
            $raw = @file_get_contents(self::$configFile);
            $parsed = json_decode($raw, true);
            if (is_array($parsed)) {
                $cfg = array_merge($cfg, $parsed);
                if (!empty($cfg['database']) && !empty($cfg['user'])) {
                    $cfg['configured'] = true;
                }
            }
        }
        self::$cachedConfig = $cfg;
        return $cfg;
    }

    public static function saveMysqlConfig($newCfg) {
        self::initPaths();
        $curr = self::getMysqlConfig();
        $merged = array_merge($curr, [
            'host' => isset($newCfg['host']) ? trim($newCfg['host']) : $curr['host'],
            'port' => isset($newCfg['port']) ? intval($newCfg['port']) : $curr['port'],
            'user' => isset($newCfg['user']) ? trim($newCfg['user']) : $curr['user'],
            'password' => array_key_exists('password', $newCfg) ? strval($newCfg['password']) : $curr['password'],
            'database' => isset($newCfg['database']) ? trim($newCfg['database']) : $curr['database'],
            'ssl' => isset($newCfg['ssl']) ? (bool)$newCfg['ssl'] : $curr['ssl'],
            'configured' => true
        ]);
        self::$cachedConfig = $merged;
        @file_put_contents(self::$configFile, json_encode($merged, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        return $merged;
    }

    private static function createPdo($cfg, $selectDb = true) {
        if (!class_exists('PDO')) {
            throw new Exception('Ekstensi PHP PDO tidak tersedia di server.');
        }
        $host = !empty($cfg['host']) ? $cfg['host'] : 'localhost';
        $port = !empty($cfg['port']) ? intval($cfg['port']) : 3306;
        $user = isset($cfg['user']) ? $cfg['user'] : '';
        $pass = isset($cfg['password']) ? $cfg['password'] : '';
        $db   = isset($cfg['database']) ? $cfg['database'] : '';

        $dsn = "mysql:host={$host};port={$port};charset=utf8mb4";
        if ($selectDb && !empty($db)) {
            $dsn = "mysql:host={$host};port={$port};dbname={$db};charset=utf8mb4";
        }
        $opts = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_TIMEOUT => 4
        ];
        if (!empty($cfg['ssl']) && defined('PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT')) {
            $opts[PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT] = false;
        }
        return new PDO($dsn, $user, $pass, $opts);
    }

    public static function testMysqlConnection($cfg) {
        try {
            $hasDb = !empty($cfg['database']);
            try {
                $pdo = self::createPdo($cfg, $hasDb);
            } catch (Exception $e) {
                if ($hasDb) {
                    $pdo = self::createPdo($cfg, false);
                } else {
                    throw $e;
                }
            }
            $row = $pdo->query('SELECT VERSION() AS version')->fetch();
            $version = isset($row['version']) ? $row['version'] : 'MySQL / MariaDB Compatible';
            return [
                'success' => true,
                'message' => "Koneksi berhasil ke MySQL server (Versi: {$version})!",
                'version' => $version
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Gagal terhubung ke MySQL: ' . $e->getMessage()
            ];
        }
    }

    public static function getMysqlStatus() {
        $cfg = self::getMysqlConfig();
        $connected = false;
        if (!empty($cfg['configured']) && !empty($cfg['user']) && !empty($cfg['database'])) {
            try {
                $pdo = self::createPdo($cfg, true);
                $pdo->query('SELECT 1');
                $connected = true;
                self::$lastMysqlError = null;
            } catch (Exception $e) {
                $connected = false;
                self::$lastMysqlError = $e->getMessage();
            }
        }
        return [
            'connected' => $connected,
            'config' => [
                'host' => $cfg['host'],
                'port' => intval($cfg['port']),
                'user' => $cfg['user'],
                'database' => $cfg['database'] ? $cfg['database'] : 'sublime_erp_db',
                'ssl' => !empty($cfg['ssl']),
                'hasPassword' => !empty($cfg['password'])
            ],
            'lastError' => self::$lastMysqlError
        ];
    }

    public static function connectAndInitMysql($newCfg, $currentState) {
        $cfg = self::saveMysqlConfig($newCfg);
        try {
            $pdo = null;
            try {
                $pdo = self::createPdo($cfg, true);
            } catch (Exception $e) {
                // Coba connect tanpa dbname lalu CREATE DATABASE jika punya privilege
                $pdoNoDb = self::createPdo($cfg, false);
                $dbSafe = preg_replace('/[^a-zA-Z0-9_]/', '', $cfg['database']);
                if (!empty($dbSafe)) {
                    $pdoNoDb->exec("CREATE DATABASE IF NOT EXISTS `{$dbSafe}` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                }
                $pdo = self::createPdo($cfg, true);
            }
            self::createMysqlTables($pdo);
            self::syncStateToMysql($pdo, $currentState);
            self::$lastMysqlError = null;
            return true;
        } catch (Exception $e) {
            self::$lastMysqlError = $e->getMessage();
            return false;
        }
    }

    private static function createMysqlTables($pdo) {
        $queries = [
            "CREATE TABLE IF NOT EXISTS `users` (
                `id` VARCHAR(64) PRIMARY KEY,
                `username` VARCHAR(100) NOT NULL,
                `password` VARCHAR(255) DEFAULT NULL,
                `nama` VARCHAR(150) NOT NULL,
                `email` VARCHAR(150) DEFAULT NULL,
                `noTelp` VARCHAR(50) DEFAULT NULL,
                `role` VARCHAR(50) NOT NULL,
                `active` TINYINT(1) DEFAULT 1,
                `preferences` LONGTEXT DEFAULT NULL,
                `permissions` LONGTEXT DEFAULT NULL,
                `createdAt` VARCHAR(50) DEFAULT NULL,
                `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            "CREATE TABLE IF NOT EXISTS `orders` (
                `id` VARCHAR(64) PRIMARY KEY,
                `customerName` VARCHAR(150) NOT NULL,
                `customerPhone` VARCHAR(50) DEFAULT NULL,
                `jenisOrder` VARCHAR(100) DEFAULT NULL,
                `status` VARCHAR(50) NOT NULL,
                `paymentStatus` VARCHAR(50) DEFAULT 'Belum Bayar',
                `totalHarga` DECIMAL(15,2) DEFAULT 0,
                `meterPrint` DECIMAL(10,2) DEFAULT 0,
                `kain` VARCHAR(100) DEFAULT NULL,
                `kertas` VARCHAR(100) DEFAULT NULL,
                `lebarKertas` VARCHAR(50) DEFAULT NULL,
                `tanggalOrder` VARCHAR(50) DEFAULT NULL,
                `deadline` VARCHAR(50) DEFAULT NULL,
                `data_json` LONGTEXT NOT NULL,
                `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            "CREATE TABLE IF NOT EXISTS `spk` (
                `id` VARCHAR(64) PRIMARY KEY,
                `orderId` VARCHAR(64) NOT NULL,
                `nomorSPK` VARCHAR(100) NOT NULL,
                `status` VARCHAR(50) DEFAULT 'Menunggu Antrian',
                `operator` VARCHAR(100) DEFAULT NULL,
                `deadline` VARCHAR(50) DEFAULT NULL,
                `data_json` LONGTEXT NOT NULL,
                `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX `idx_spk_order` (`orderId`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            "CREATE TABLE IF NOT EXISTS `materials` (
                `id` VARCHAR(64) PRIMARY KEY,
                `namaMaterial` VARCHAR(150) NOT NULL,
                `satuan` VARCHAR(50) DEFAULT 'Roll',
                `stok` DECIMAL(12,2) DEFAULT 0,
                `minStok` DECIMAL(12,2) DEFAULT 0,
                `harga` DECIMAL(15,2) DEFAULT 0,
                `kategori` VARCHAR(50) DEFAULT 'Paper',
                `data_json` LONGTEXT NOT NULL,
                `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            "CREATE TABLE IF NOT EXISTS `invoices` (
                `id` VARCHAR(64) PRIMARY KEY,
                `orderId` VARCHAR(64) DEFAULT NULL,
                `invoiceNumber` VARCHAR(100) NOT NULL,
                `namaKonsumen` VARCHAR(150) DEFAULT NULL,
                `totalAmount` DECIMAL(15,2) DEFAULT 0,
                `sisaTagihan` DECIMAL(15,2) DEFAULT 0,
                `statusPembayaran` VARCHAR(50) DEFAULT 'Belum Bayar',
                `data_json` LONGTEXT NOT NULL,
                `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            "CREATE TABLE IF NOT EXISTS `piutang` (
                `id` VARCHAR(64) PRIMARY KEY,
                `orderId` VARCHAR(64) DEFAULT NULL,
                `customerName` VARCHAR(150) DEFAULT NULL,
                `totalHutang` DECIMAL(15,2) DEFAULT 0,
                `sisaTagihan` DECIMAL(15,2) DEFAULT 0,
                `status` VARCHAR(50) DEFAULT 'Belum Lunas',
                `data_json` LONGTEXT NOT NULL,
                `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            "CREATE TABLE IF NOT EXISTS `customers` (
                `id` VARCHAR(64) PRIMARY KEY,
                `nama` VARCHAR(150) NOT NULL,
                `noTelp` VARCHAR(50) DEFAULT NULL,
                `email` VARCHAR(150) DEFAULT NULL,
                `alamat` TEXT DEFAULT NULL,
                `catatan` TEXT DEFAULT NULL,
                `createdAt` VARCHAR(50) DEFAULT NULL,
                `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            "CREATE TABLE IF NOT EXISTS `operational_expenses` (
                `id` VARCHAR(64) PRIMARY KEY,
                `tanggal` VARCHAR(50) NOT NULL,
                `kategori` VARCHAR(100) NOT NULL,
                `nominal` DECIMAL(15,2) DEFAULT 0,
                `keterangan` TEXT DEFAULT NULL,
                `metodeBayar` VARCHAR(100) DEFAULT NULL,
                `noReferensi` VARCHAR(100) DEFAULT NULL,
                `dicatatOleh` VARCHAR(100) DEFAULT NULL,
                `createdAt` VARCHAR(50) DEFAULT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            "CREATE TABLE IF NOT EXISTS `payroll_transactions` (
                `id` VARCHAR(64) PRIMARY KEY,
                `date` VARCHAR(50) NOT NULL,
                `businessUnit` VARCHAR(100) DEFAULT 'ERVO SUBLIME',
                `type` VARCHAR(20) NOT NULL,
                `category` VARCHAR(100) NOT NULL,
                `amount` DECIMAL(15,2) DEFAULT 0,
                `description` TEXT DEFAULT NULL,
                `paymentMethod` VARCHAR(100) DEFAULT NULL,
                `referenceNo` VARCHAR(100) DEFAULT NULL,
                `status` VARCHAR(50) DEFAULT 'completed',
                `createdAt` VARCHAR(50) DEFAULT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            "CREATE TABLE IF NOT EXISTS `system_settings` (
                `settingKey` VARCHAR(100) PRIMARY KEY,
                `settingValue` LONGTEXT NOT NULL,
                `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            "CREATE TABLE IF NOT EXISTS `system_logs` (
                `id` VARCHAR(64) PRIMARY KEY,
                `userId` VARCHAR(64) DEFAULT NULL,
                `userNama` VARCHAR(150) DEFAULT NULL,
                `action` VARCHAR(100) NOT NULL,
                `description` TEXT DEFAULT NULL,
                `timestamp` VARCHAR(50) NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        ];
        foreach ($queries as $sql) {
            $pdo->exec($sql);
        }
    }

    private static function syncStateToMysql($pdo, $state) {
        if (!$pdo || !is_array($state)) return;
        $encFlags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;

        // Settings
        $stmtSet = $pdo->prepare("INSERT INTO `system_settings` (`settingKey`, `settingValue`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `settingValue` = VALUES(`settingValue`)");
        foreach ([
            'paper' => isset($state['paperSettings']) ? $state['paperSettings'] : [],
            'prices' => isset($state['priceSettings']) ? $state['priceSettings'] : [],
            'permissions' => isset($state['rolePermissions']) ? $state['rolePermissions'] : [],
            'company' => isset($state['companyProfile']) ? $state['companyProfile'] : []
        ] as $k => $v) {
            $stmtSet->execute([$k, json_encode($v, $encFlags)]);
        }

        // Users: prune BEFORE upserting (even if empty) so deletions always sync cleanly
        $usersArr = (!empty($state['users']) && is_array($state['users'])) ? $state['users'] : [];
        $userIds = [];
        foreach ($usersArr as $u) {
            if (!empty($u['id'])) $userIds[] = $u['id'];
        }
        self::pruneMissingMysqlRows($pdo, 'users', $userIds);

        $stmtDelUsername = $pdo->prepare("DELETE FROM `users` WHERE `username` = ? AND `id` <> ?");
        $stmt = $pdo->prepare("INSERT INTO `users` (`id`,`username`,`password`,`nama`,`email`,`noTelp`,`role`,`active`,`preferences`,`permissions`,`createdAt`) VALUES (?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE `username`=VALUES(`username`),`password`=VALUES(`password`),`nama`=VALUES(`nama`),`email`=VALUES(`email`),`noTelp`=VALUES(`noTelp`),`role`=VALUES(`role`),`active`=VALUES(`active`),`preferences`=VALUES(`preferences`),`permissions`=VALUES(`permissions`)");
        foreach ($usersArr as $u) {
            $id = isset($u['id']) ? $u['id'] : '';
            if (!$id) continue;
            $uname = isset($u['username']) ? $u['username'] : '';
            if ($uname !== '') {
                $stmtDelUsername->execute([$uname, $id]);
            }
            $stmt->execute([
                $id,
                $uname,
                isset($u['password']) ? $u['password'] : null,
                isset($u['nama']) ? $u['nama'] : '',
                isset($u['email']) ? $u['email'] : null,
                isset($u['noTelp']) ? $u['noTelp'] : null,
                isset($u['role']) ? $u['role'] : 'CS',
                !empty($u['active']) ? 1 : 0,
                isset($u['preferences']) ? json_encode($u['preferences'], $encFlags) : null,
                isset($u['permissions']) ? json_encode($u['permissions'], $encFlags) : null,
                isset($u['createdAt']) ? $u['createdAt'] : gmdate('Y-m-d\TH:i:s.000\Z')
            ]);
        }

        // Materials: prune BEFORE upsert
        $matArr = (!empty($state['materials']) && is_array($state['materials'])) ? $state['materials'] : [];
        $matIds = [];
        foreach ($matArr as $m) {
            if (!empty($m['ID'])) $matIds[] = $m['ID'];
        }
        self::pruneMissingMysqlRows($pdo, 'materials', $matIds);
        $stmtMat = $pdo->prepare("INSERT INTO `materials` (`id`,`namaMaterial`,`satuan`,`stok`,`minStok`,`harga`,`kategori`,`data_json`) VALUES (?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE `namaMaterial`=VALUES(`namaMaterial`),`satuan`=VALUES(`satuan`),`stok`=VALUES(`stok`),`minStok`=VALUES(`minStok`),`harga`=VALUES(`harga`),`kategori`=VALUES(`kategori`),`data_json`=VALUES(`data_json`)");
        foreach ($matArr as $m) {
            $id = isset($m['ID']) ? $m['ID'] : '';
            if (!$id) continue;
            $stmtMat->execute([
                $id,
                isset($m['NamaMaterial']) ? $m['NamaMaterial'] : '',
                isset($m['Satuan']) ? $m['Satuan'] : 'Roll',
                floatval(isset($m['Stok']) ? $m['Stok'] : 0),
                floatval(isset($m['MinStok']) ? $m['MinStok'] : 0),
                floatval(isset($m['Harga']) ? $m['Harga'] : 0),
                isset($m['Kategori']) ? $m['Kategori'] : 'Paper',
                json_encode($m, $encFlags)
            ]);
        }

        // Orders: prune BEFORE upsert
        $ordArr = (!empty($state['orders']) && is_array($state['orders'])) ? $state['orders'] : [];
        $ordIds = [];
        foreach ($ordArr as $o) {
            if (!empty($o['ID'])) $ordIds[] = $o['ID'];
        }
        self::pruneMissingMysqlRows($pdo, 'orders', $ordIds);
        $stmtOrd = $pdo->prepare("INSERT INTO `orders` (`id`,`customerName`,`customerPhone`,`jenisOrder`,`status`,`paymentStatus`,`totalHarga`,`meterPrint`,`kain`,`kertas`,`lebarKertas`,`tanggalOrder`,`deadline`,`data_json`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE `customerName`=VALUES(`customerName`),`customerPhone`=VALUES(`customerPhone`),`jenisOrder`=VALUES(`jenisOrder`),`status`=VALUES(`status`),`paymentStatus`=VALUES(`paymentStatus`),`totalHarga`=VALUES(`totalHarga`),`meterPrint`=VALUES(`meterPrint`),`kain`=VALUES(`kain`),`kertas`=VALUES(`kertas`),`lebarKertas`=VALUES(`lebarKertas`),`tanggalOrder`=VALUES(`tanggalOrder`),`deadline`=VALUES(`deadline`),`data_json`=VALUES(`data_json`)");
        foreach ($ordArr as $o) {
            $id = isset($o['ID']) ? $o['ID'] : '';
            if (!$id) continue;
            $stmtOrd->execute([
                $id,
                isset($o['NamaKonsumen']) ? $o['NamaKonsumen'] : 'Pelanggan',
                isset($o['NoTelpKonsumen']) ? $o['NoTelpKonsumen'] : '',
                isset($o['JenisOrder']) ? $o['JenisOrder'] : '',
                isset($o['Status']) ? $o['Status'] : 'Pending',
                isset($o['StatusPembayaran']) ? $o['StatusPembayaran'] : (isset($o['PaymentStatus']) ? $o['PaymentStatus'] : 'Belum Bayar'),
                floatval(isset($o['PriceTotal']) ? $o['PriceTotal'] : 0),
                floatval(isset($o['MeterPrint']) ? $o['MeterPrint'] : (isset($o['LayoutPanjangPrint']) ? $o['LayoutPanjangPrint'] : 0)),
                isset($o['MaterialPress']) ? $o['MaterialPress'] : (isset($o['MaterialType']) ? $o['MaterialType'] : ''),
                isset($o['PaperType']) ? $o['PaperType'] : '',
                isset($o['PaperSize']) ? $o['PaperSize'] : '',
                isset($o['TanggalOrder']) ? $o['TanggalOrder'] : '',
                isset($o['Deadline']) ? $o['Deadline'] : '',
                json_encode($o, $encFlags)
            ]);
        }

        // SPK: prune BEFORE upsert
        $spkArr = (!empty($state['spkList']) && is_array($state['spkList'])) ? $state['spkList'] : [];
        $spkIds = [];
        foreach ($spkArr as $s) {
            if (!empty($s['ID'])) $spkIds[] = $s['ID'];
        }
        self::pruneMissingMysqlRows($pdo, 'spk', $spkIds);
        $stmtSpk = $pdo->prepare("INSERT INTO `spk` (`id`,`orderId`,`nomorSPK`,`status`,`operator`,`deadline`,`data_json`) VALUES (?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE `orderId`=VALUES(`orderId`),`nomorSPK`=VALUES(`nomorSPK`),`status`=VALUES(`status`),`operator`=VALUES(`operator`),`deadline`=VALUES(`deadline`),`data_json`=VALUES(`data_json`)");
        foreach ($spkArr as $s) {
            $id = isset($s['ID']) ? $s['ID'] : '';
            if (!$id) continue;
            $status = isset($s['StatusPrint']) ? $s['StatusPrint'] : (isset($s['StatusQC']) ? $s['StatusQC'] : 'Pending');
            $stmtSpk->execute([
                $id,
                isset($s['OrderID']) ? $s['OrderID'] : $id,
                $id,
                $status,
                isset($s['LayoutOperator']) ? $s['LayoutOperator'] : '',
                isset($s['Deadline']) ? $s['Deadline'] : '',
                json_encode($s, $encFlags)
            ]);
        }

        // Invoices: prune BEFORE upsert
        $invArr = (!empty($state['invoices']) && is_array($state['invoices'])) ? $state['invoices'] : [];
        $invIds = [];
        foreach ($invArr as $inv) {
            if (!empty($inv['ID'])) $invIds[] = $inv['ID'];
        }
        self::pruneMissingMysqlRows($pdo, 'invoices', $invIds);
        $stmtInv = $pdo->prepare("INSERT INTO `invoices` (`id`,`orderId`,`invoiceNumber`,`namaKonsumen`,`totalAmount`,`sisaTagihan`,`statusPembayaran`,`data_json`) VALUES (?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE `orderId`=VALUES(`orderId`),`invoiceNumber`=VALUES(`invoiceNumber`),`namaKonsumen`=VALUES(`namaKonsumen`),`totalAmount`=VALUES(`totalAmount`),`sisaTagihan`=VALUES(`sisaTagihan`),`statusPembayaran`=VALUES(`statusPembayaran`),`data_json`=VALUES(`data_json`)");
        foreach ($invArr as $inv) {
            $id = isset($inv['ID']) ? $inv['ID'] : '';
            if (!$id) continue;
            $tot = floatval(isset($inv['TotalAmount']) ? $inv['TotalAmount'] : 0);
            $paid = floatval(isset($inv['PaidAmount']) ? $inv['PaidAmount'] : 0);
            $stmtInv->execute([
                $id,
                isset($inv['OrderID']) ? $inv['OrderID'] : '',
                $id,
                isset($inv['NamaKonsumen']) ? $inv['NamaKonsumen'] : '',
                $tot,
                max(0, $tot - $paid),
                isset($inv['Status']) ? $inv['Status'] : 'Unpaid',
                json_encode($inv, $encFlags)
            ]);
        }

        // Piutang: prune BEFORE upsert
        $pitArr = (!empty($state['piutangs']) && is_array($state['piutangs'])) ? $state['piutangs'] : [];
        $pitIds = [];
        foreach ($pitArr as $p) {
            if (!empty($p['ID'])) $pitIds[] = $p['ID'];
        }
        self::pruneMissingMysqlRows($pdo, 'piutang', $pitIds);
        $stmtPit = $pdo->prepare("INSERT INTO `piutang` (`id`,`orderId`,`customerName`,`totalHutang`,`sisaTagihan`,`status`,`data_json`) VALUES (?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE `orderId`=VALUES(`orderId`),`customerName`=VALUES(`customerName`),`totalHutang`=VALUES(`totalHutang`),`sisaTagihan`=VALUES(`sisaTagihan`),`status`=VALUES(`status`),`data_json`=VALUES(`data_json`)");
        foreach ($pitArr as $p) {
            $id = isset($p['ID']) ? $p['ID'] : '';
            if (!$id) continue;
            $stmtPit->execute([
                $id,
                isset($p['InvoiceID']) ? $p['InvoiceID'] : '',
                isset($p['NamaKonsumen']) ? $p['NamaKonsumen'] : '',
                floatval(isset($p['Jumlah']) ? $p['Jumlah'] : 0),
                floatval(isset($p['Sisa']) ? $p['Sisa'] : 0),
                isset($p['Status']) ? $p['Status'] : 'Belum Lunas',
                json_encode($p, $encFlags)
            ]);
        }

        // Customers: prune BEFORE upsert
        $custArr = (!empty($state['customerProfiles']) && is_array($state['customerProfiles'])) ? $state['customerProfiles'] : [];
        $custIds = [];
        foreach ($custArr as $c) {
            if (!empty($c['id'])) $custIds[] = $c['id'];
        }
        self::pruneMissingMysqlRows($pdo, 'customers', $custIds);
        $stmtCust = $pdo->prepare("INSERT INTO `customers` (`id`,`nama`,`noTelp`,`email`,`alamat`,`catatan`,`createdAt`) VALUES (?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE `nama`=VALUES(`nama`),`noTelp`=VALUES(`noTelp`),`email`=VALUES(`email`),`alamat`=VALUES(`alamat`),`catatan`=VALUES(`catatan`)");
        foreach ($custArr as $c) {
            $id = isset($c['id']) ? $c['id'] : '';
            if (!$id) continue;
            $stmtCust->execute([
                $id,
                isset($c['nama']) ? $c['nama'] : '',
                isset($c['noTelp']) ? $c['noTelp'] : '',
                isset($c['email']) ? $c['email'] : '',
                isset($c['alamat']) ? $c['alamat'] : '',
                isset($c['catatan']) ? $c['catatan'] : '',
                isset($c['createdAt']) ? $c['createdAt'] : gmdate('Y-m-d\TH:i:s.000\Z')
            ]);
        }

        // Operational expenses: prune BEFORE upsert
        $expArr = (!empty($state['operationalExpenses']) && is_array($state['operationalExpenses'])) ? $state['operationalExpenses'] : [];
        $expIds = [];
        foreach ($expArr as $e) {
            if (!empty($e['id'])) $expIds[] = $e['id'];
        }
        self::pruneMissingMysqlRows($pdo, 'operational_expenses', $expIds);
        $stmtExp = $pdo->prepare("INSERT INTO `operational_expenses` (`id`,`tanggal`,`kategori`,`nominal`,`keterangan`,`metodeBayar`,`noReferensi`,`dicatatOleh`,`createdAt`) VALUES (?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE `tanggal`=VALUES(`tanggal`),`kategori`=VALUES(`kategori`),`nominal`=VALUES(`nominal`),`keterangan`=VALUES(`keterangan`),`metodeBayar`=VALUES(`metodeBayar`),`noReferensi`=VALUES(`noReferensi`),`dicatatOleh`=VALUES(`dicatatOleh`)");
        foreach ($expArr as $e) {
            $id = isset($e['id']) ? $e['id'] : '';
            if (!$id) continue;
            $stmtExp->execute([
                $id,
                isset($e['tanggal']) ? $e['tanggal'] : '',
                isset($e['kategori']) ? $e['kategori'] : '',
                floatval(isset($e['nominal']) ? $e['nominal'] : 0),
                isset($e['keterangan']) ? $e['keterangan'] : '',
                isset($e['metodeBayar']) ? $e['metodeBayar'] : '',
                isset($e['noReferensi']) ? $e['noReferensi'] : '',
                isset($e['dicatatOleh']) ? $e['dicatatOleh'] : '',
                isset($e['createdAt']) ? $e['createdAt'] : ''
            ]);
        }
    }

    public static function deleteUserFromMysql($id, $username = null) {
        self::initPaths();
        $cfg = self::getMysqlConfig();
        if (empty($cfg['configured']) || empty($cfg['user']) || empty($cfg['database'])) return false;
        try {
            $pdo = self::createPdo($cfg, true);
            if ($id && $username) {
                $stmt = $pdo->prepare("DELETE FROM `users` WHERE `id` = ? OR `username` = ?");
                $stmt->execute([$id, $username]);
            } elseif ($id) {
                $stmt = $pdo->prepare("DELETE FROM `users` WHERE `id` = ?");
                $stmt->execute([$id]);
            } elseif ($username) {
                $stmt = $pdo->prepare("DELETE FROM `users` WHERE `username` = ?");
                $stmt->execute([$username]);
            }
            self::$lastMysqlError = null;
            return true;
        } catch (Exception $e) {
            self::$lastMysqlError = $e->getMessage();
            return false;
        }
    }

    private static function pruneMissingMysqlRows($pdo, $table, $keepIds) {
        if (empty($keepIds)) {
            $pdo->exec("DELETE FROM `{$table}`");
            return;
        }
        $placeholders = implode(',', array_fill(0, count($keepIds), '?'));
        $stmt = $pdo->prepare("DELETE FROM `{$table}` WHERE `id` NOT IN ({$placeholders})");
        $stmt->execute(array_values($keepIds));
    }

    public static function loadState() {
        self::initPaths();
        $data = null;
        $isFreshSeed = false;

        if (!file_exists(self::$stateFile)) {
            $isFreshSeed = true;
            if (file_exists(self::$seedFile)) {
                $seedRaw = @file_get_contents(self::$seedFile);
                $seed = json_decode($seedRaw, true);
                if (is_array($seed)) {
                    $data = $seed;
                }
            }
            if (!is_array($data)) {
                $data = self::getEmptyState();
            }
        } else {
            $fp = @fopen(self::$stateFile, 'r');
            if ($fp) {
                @flock($fp, LOCK_SH);
                $raw = stream_get_contents($fp);
                @flock($fp, LOCK_UN);
                @fclose($fp);
                $data = json_decode($raw, true);
            }
            if (!is_array($data)) {
                if (file_exists(self::$seedFile)) {
                    $data = json_decode(@file_get_contents(self::$seedFile), true);
                }
                if (!is_array($data)) $data = self::getEmptyState();
            }
        }

        $data = self::normalizeState($data);
        $hydrated = self::hydrateStateFromMysql($data, $isFreshSeed);
        return $hydrated;
    }

    private static function tableExists($pdo, $tableName) {
        $stmt = $pdo->prepare("SHOW TABLES LIKE ?");
        $stmt->execute([$tableName]);
        return (bool)$stmt->fetchColumn();
    }

    private static function decodeJsonField($val, $fallback = null) {
        if ($val === null || $val === '') return $fallback;
        if (is_array($val)) return $val;
        $decoded = json_decode(strval($val), true);
        return is_array($decoded) ? $decoded : $fallback;
    }

    private static function hydrateStateFromMysql($data, $isFreshSeed = false) {
        $cfg = self::getMysqlConfig();
        if (empty($cfg['configured']) || empty($cfg['user']) || empty($cfg['database'])) {
            if ($isFreshSeed) {
                self::saveState($data, false);
            }
            return $data;
        }

        try {
            $pdo = self::createPdo($cfg, true);
            if (!self::tableExists($pdo, 'users')) {
                self::createMysqlTables($pdo);
                self::syncStateToMysql($pdo, $data);
                self::$lastMysqlError = null;
                if ($isFreshSeed) {
                    self::saveState($data, false);
                }
                return $data;
            }

            $userRows = $pdo->query("SELECT `id`,`username`,`password`,`nama`,`email`,`noTelp`,`role`,`active`,`preferences`,`permissions`,`createdAt` FROM `users` ORDER BY `createdAt` ASC, `id` ASC")->fetchAll();
            if (is_array($userRows) && count($userRows) > 0) {
                $dbUsers = [];
                foreach ($userRows as $r) {
                    $u = [
                        'id' => strval($r['id']),
                        'username' => strval(isset($r['username']) ? $r['username'] : ''),
                        'password' => isset($r['password']) && $r['password'] !== null ? strval($r['password']) : '',
                        'nama' => strval(isset($r['nama']) ? $r['nama'] : ''),
                        'email' => isset($r['email']) && $r['email'] !== null ? strval($r['email']) : '',
                        'noTelp' => isset($r['noTelp']) && $r['noTelp'] !== null ? strval($r['noTelp']) : '',
                        'role' => strval(isset($r['role']) ? $r['role'] : 'CS'),
                        'active' => isset($r['active']) ? ((int)$r['active'] === 1) : true,
                        'createdAt' => isset($r['createdAt']) ? $r['createdAt'] : ''
                    ];
                    $prefs = self::decodeJsonField(isset($r['preferences']) ? $r['preferences'] : null, null);
                    if ($prefs !== null) $u['preferences'] = $prefs;
                    $perms = self::decodeJsonField(isset($r['permissions']) ? $r['permissions'] : null, null);
                    if ($perms !== null) $u['permissions'] = $perms;
                    $dbUsers[] = $u;
                }
                $dbUsers = self::deduplicateUsers($dbUsers);

                $beforeHash = md5(json_encode($data));
                $data['users'] = $dbUsers;

                $jsonTables = [
                    'materials' => 'materials',
                    'orders' => 'orders',
                    'spk' => 'spkList',
                    'invoices' => 'invoices',
                    'piutang' => 'piutangs'
                ];
                foreach ($jsonTables as $tbl => $stateKey) {
                    if (self::tableExists($pdo, $tbl)) {
                        $rows = $pdo->query("SELECT `data_json` FROM `{$tbl}`")->fetchAll();
                        $parsed = [];
                        foreach ($rows as $row) {
                            $item = self::decodeJsonField(isset($row['data_json']) ? $row['data_json'] : null, null);
                            if (is_array($item)) $parsed[] = $item;
                        }
                        $data[$stateKey] = $parsed;
                    }
                }

                if (self::tableExists($pdo, 'customers')) {
                    $cRows = $pdo->query("SELECT `id`,`nama`,`noTelp`,`email`,`alamat`,`catatan`,`createdAt` FROM `customers`")->fetchAll();
                    $custs = [];
                    foreach ($cRows as $c) {
                        $custs[] = [
                            'id' => strval($c['id']),
                            'nama' => strval(isset($c['nama']) ? $c['nama'] : ''),
                            'noTelp' => strval(isset($c['noTelp']) ? $c['noTelp'] : ''),
                            'email' => strval(isset($c['email']) ? $c['email'] : ''),
                            'alamat' => strval(isset($c['alamat']) ? $c['alamat'] : ''),
                            'catatan' => strval(isset($c['catatan']) ? $c['catatan'] : ''),
                            'createdAt' => isset($c['createdAt']) ? $c['createdAt'] : ''
                        ];
                    }
                    $data['customerProfiles'] = $custs;
                }

                if (self::tableExists($pdo, 'operational_expenses')) {
                    $eRows = $pdo->query("SELECT `id`,`tanggal`,`kategori`,`nominal`,`keterangan`,`metodeBayar`,`noReferensi`,`dicatatOleh`,`createdAt` FROM `operational_expenses` ORDER BY `createdAt` DESC")->fetchAll();
                    $exps = [];
                    foreach ($eRows as $e) {
                        $exps[] = [
                            'id' => strval($e['id']),
                            'tanggal' => strval(isset($e['tanggal']) ? $e['tanggal'] : ''),
                            'kategori' => strval(isset($e['kategori']) ? $e['kategori'] : ''),
                            'nominal' => floatval(isset($e['nominal']) ? $e['nominal'] : 0),
                            'keterangan' => strval(isset($e['keterangan']) ? $e['keterangan'] : ''),
                            'metodeBayar' => strval(isset($e['metodeBayar']) ? $e['metodeBayar'] : ''),
                            'noReferensi' => strval(isset($e['noReferensi']) ? $e['noReferensi'] : ''),
                            'dicatatOleh' => strval(isset($e['dicatatOleh']) ? $e['dicatatOleh'] : ''),
                            'createdAt' => strval(isset($e['createdAt']) ? $e['createdAt'] : '')
                        ];
                    }
                    $data['operationalExpenses'] = $exps;
                }

                if (self::tableExists($pdo, 'system_settings')) {
                    $sRows = $pdo->query("SELECT `settingKey`,`settingValue` FROM `system_settings`")->fetchAll();
                    $keyMap = [
                        'paper' => 'paperSettings',
                        'prices' => 'priceSettings',
                        'permissions' => 'rolePermissions',
                        'company' => 'companyProfile'
                    ];
                    foreach ($sRows as $sr) {
                        $sk = isset($sr['settingKey']) ? $sr['settingKey'] : '';
                        if (isset($keyMap[$sk])) {
                            $val = self::decodeJsonField(isset($sr['settingValue']) ? $sr['settingValue'] : null, null);
                            if ($val !== null) $data[$keyMap[$sk]] = $val;
                        }
                    }
                }

                self::$lastMysqlError = null;
                $afterHash = md5(json_encode($data));
                if ($isFreshSeed || $beforeHash !== $afterHash) {
                    self::saveState($data, false);
                }
                return $data;
            } else {
                // Tabel users kosong: inisialisasi tabel & isi data awal ke MySQL
                self::createMysqlTables($pdo);
                self::syncStateToMysql($pdo, $data);
                self::$lastMysqlError = null;
                if ($isFreshSeed) {
                    self::saveState($data, false);
                }
                return $data;
            }
        } catch (Exception $e) {
            self::$lastMysqlError = $e->getMessage();
            if ($isFreshSeed) {
                self::saveState($data, false);
            }
            return $data;
        }
    }

    public static function saveState($state, $syncMysql = true) {
        self::initPaths();
        $state = self::normalizeState($state);
        $state['lastSaved'] = gmdate('Y-m-d\TH:i:s.000\Z');
        if (isset($state['logs']) && is_array($state['logs']) && count($state['logs']) > 300) {
            $state['logs'] = array_slice($state['logs'], 0, 300);
        }
        if (isset($state['notifications']) && is_array($state['notifications']) && count($state['notifications']) > 250) {
            $state['notifications'] = array_slice($state['notifications'], 0, 250);
        }

        $json = json_encode($state, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $tmpFile = self::$stateFile . '.tmp.' . getmypid() . '.' . mt_rand(100, 999);
        if (@file_put_contents($tmpFile, $json, LOCK_EX) !== false) {
            @rename($tmpFile, self::$stateFile);
        } else {
            @file_put_contents(self::$stateFile, $json, LOCK_EX);
        }

        if ($syncMysql) {
            $cfg = self::getMysqlConfig();
            if (!empty($cfg['configured']) && !empty($cfg['user']) && !empty($cfg['database'])) {
                try {
                    $pdo = self::createPdo($cfg, true);
                    try {
                        self::syncStateToMysql($pdo, $state);
                    } catch (Exception $inner) {
                        // Jika tabel belum dibuat saat user hanya mengisi file .env, buat tabel otomatis & sinkron ulang
                        self::createMysqlTables($pdo);
                        self::syncStateToMysql($pdo, $state);
                    }
                    self::$lastMysqlError = null;
                } catch (Exception $e) {
                    self::$lastMysqlError = $e->getMessage();
                }
            }
        }
        return $state;
    }

    private static function getEmptyState() {
        return [
            'users' => [],
            'orders' => [],
            'spkList' => [],
            'materials' => [],
            'deletedMaterialIds' => [],
            'deletedMaterialNames' => [],
            'invoices' => [],
            'piutangs' => [],
            'customerProfiles' => [],
            'deletedCustomerKeys' => [],
            'logs' => [],
            'notifications' => [],
            'operationalExpenses' => [],
            'payrollTransactions' => [],
            'payrollConfig' => ['targetUrl' => '', 'enabled' => false, 'businessUnit' => 'ERVO SUBLIME'],
            'syncInfo' => [
                'courierAPI' => ['provider' => 'JNE / J&T / SiCepat Real-time Gateway', 'activeWaybills' => 0, 'lastSyncTime' => '-', 'status' => 'Active'],
                'whatsappGateway' => ['status' => 'Connected', 'phoneNumber' => '+6281234567890', 'messagesSentToday' => 0]
            ],
            'paperSettings' => ['types' => ['Sticky', 'Fastdry'], 'widths' => ['160 cm', '125 cm', '110 cm', '90 cm'], 'typePrices' => [], 'typeUnits' => [], 'paperItems' => []],
            'priceSettings' => ['fabrics' => [], 'papers' => [], 'inks' => [], 'accessories' => [], 'pressRate' => 15000, 'cuttingRate' => 5000, 'printRate' => 25000, 'sewingRate' => 12000, 'packingRate' => 2000],
            'rolePermissions' => [],
            'companyProfile' => [],
            'backupConfig' => [],
            'serverSnapshots' => []
        ];
    }

    private static function deduplicateUsers($users) {
        if (!is_array($users)) return [];
        $seenIds = [];
        $seenUsernames = [];
        $clean = [];
        foreach ($users as $u) {
            if (!is_array($u) || empty($u['id'])) continue;
            $idKey = trim(strval($u['id']));
            $unameKey = strtolower(trim(strval(isset($u['username']) ? $u['username'] : '')));
            if (isset($seenIds[$idKey])) continue;
            if ($unameKey !== '' && isset($seenUsernames[$unameKey])) continue;
            $seenIds[$idKey] = true;
            if ($unameKey !== '') $seenUsernames[$unameKey] = true;
            $clean[] = $u;
        }
        return $clean;
    }

    private static function normalizeState($data) {
        $defaults = self::getEmptyState();
        foreach ($defaults as $k => $v) {
            if (!array_key_exists($k, $data) || $data[$k] === null) {
                $data[$k] = $v;
            }
        }
        if (isset($data['users']) && is_array($data['users'])) {
            $data['users'] = self::deduplicateUsers($data['users']);
        }
        return $data;
    }

    // =========================================================
    // REALTIME POLLING PRESENCE & EVENT BUFFER (HTTP LIVE SYNC)
    // =========================================================
    public static function heartbeatAndFetchEvents($body, $remoteIp, $sinceTs = null) {
        self::initPaths();
        $nowMs = round(microtime(true) * 1000);
        $nowIso = gmdate('Y-m-d\TH:i:s.000\Z');
        $sinceMs = 0;
        if (!empty($sinceTs)) {
            if (is_numeric($sinceTs)) {
                $sinceMs = floatval($sinceTs);
            } else {
                $parsed = strtotime($sinceTs);
                if ($parsed !== false) $sinceMs = $parsed * 1000;
            }
        }

        $fp = @fopen(self::$realtimeFile, 'c+');
        $rt = ['devices' => [], 'events' => []];
        if ($fp) {
            @flock($fp, LOCK_EX);
            $raw = stream_get_contents($fp);
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                $rt['devices'] = isset($decoded['devices']) && is_array($decoded['devices']) ? $decoded['devices'] : [];
                $rt['events'] = isset($decoded['events']) && is_array($decoded['events']) ? $decoded['events'] : [];
            }

            // Prune devices inactive > 20 seconds
            $activeDevices = [];
            foreach ($rt['devices'] as $devId => $info) {
                if (isset($info['lastPingMs']) && ($nowMs - floatval($info['lastPingMs'])) < 20000) {
                    $activeDevices[$devId] = $info;
                }
            }

            if (is_array($body) && !empty($body['deviceId'])) {
                $devId = strval($body['deviceId']);
                $prevConnected = isset($activeDevices[$devId]['connectedAt']) ? $activeDevices[$devId]['connectedAt'] : $nowIso;
                $activeDevices[$devId] = [
                    'id' => $devId,
                    'deviceId' => $devId,
                    'deviceName' => isset($body['deviceName']) ? strval($body['deviceName']) : 'Perangkat Web',
                    'deviceType' => isset($body['deviceType']) ? strval($body['deviceType']) : 'Desktop',
                    'browser' => isset($body['browser']) ? strval($body['browser']) : 'Browser',
                    'os' => isset($body['os']) ? strval($body['os']) : 'OS',
                    'ip' => $remoteIp,
                    'user' => isset($body['user']) ? $body['user'] : null,
                    'activeTab' => isset($body['activeTab']) ? strval($body['activeTab']) : 'dashboard',
                    'connectedAt' => $prevConnected,
                    'lastPing' => $nowIso,
                    'lastPingMs' => $nowMs
                ];
            }

            // Prune events older than 120 seconds
            $recentEvents = [];
            $eventsForClient = [];
            foreach ($rt['events'] as $ev) {
                $evMs = isset($ev['tsMs']) ? floatval($ev['tsMs']) : 0;
                if (($nowMs - $evMs) < 120000) {
                    $recentEvents[] = $ev;
                    if ($sinceMs > 0 && $evMs > $sinceMs) {
                        $eventsForClient[] = $ev;
                    }
                }
            }
            if (count($recentEvents) > 100) {
                $recentEvents = array_slice($recentEvents, -100);
            }

            $rt['devices'] = $activeDevices;
            $rt['events'] = $recentEvents;

            ftruncate($fp, 0);
            rewind($fp);
            fwrite($fp, json_encode($rt, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
            fflush($fp);
            @flock($fp, LOCK_UN);
            @fclose($fp);

            $deviceList = [];
            foreach ($activeDevices as $info) {
                unset($info['lastPingMs']);
                $deviceList[] = $info;
            }
            return [
                'connectedDevices' => $deviceList,
                'events' => $eventsForClient,
                'serverTime' => $nowIso,
                'serverTimeMs' => $nowMs
            ];
        }

        return [
            'connectedDevices' => [],
            'events' => [],
            'serverTime' => $nowIso,
            'serverTimeMs' => $nowMs
        ];
    }

    public static function getConnectedDevicesSnapshot() {
        self::initPaths();
        if (!file_exists(self::$realtimeFile)) return [];
        $nowMs = round(microtime(true) * 1000);
        $raw = @file_get_contents(self::$realtimeFile);
        $rt = json_decode($raw, true);
        if (!is_array($rt) || empty($rt['devices'])) return [];
        $list = [];
        foreach ($rt['devices'] as $info) {
            if (isset($info['lastPingMs']) && ($nowMs - floatval($info['lastPingMs'])) < 20000) {
                unset($info['lastPingMs']);
                $list[] = $info;
            }
        }
        return $list;
    }

    public static function pushRealtimeEvent($event, $payload = [], $sender = null, $msgType = 'broadcast:event', $extra = []) {
        self::initPaths();
        $nowMs = round(microtime(true) * 1000);
        $nowIso = gmdate('Y-m-d\TH:i:s.000\Z');
        $fp = @fopen(self::$realtimeFile, 'c+');
        if (!$fp) return;
        @flock($fp, LOCK_EX);
        $raw = stream_get_contents($fp);
        $rt = json_decode($raw, true);
        if (!is_array($rt)) $rt = ['devices' => [], 'events' => []];
        if (!isset($rt['events']) || !is_array($rt['events'])) $rt['events'] = [];

        $entry = array_merge([
            'type' => $msgType,
            'event' => $event,
            'payload' => $payload,
            'sender' => $sender,
            'timestamp' => $nowIso,
            'tsMs' => $nowMs
        ], $extra);

        $rt['events'][] = $entry;
        if (count($rt['events']) > 100) {
            $rt['events'] = array_slice($rt['events'], -100);
        }

        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode($rt, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        fflush($fp);
        @flock($fp, LOCK_UN);
        @fclose($fp);
    }
}
